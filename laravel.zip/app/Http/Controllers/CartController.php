<?php

namespace App\Http\Controllers;

use App\Barg;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;
use mysql_xdevapi\Exception;

class CartController extends Controller
{
    public $id = 0;

    public function addCart($p_id, Request $request)
    {
        $data = array();
        Session::push('cart.id', $p_id);
        Session::save();
        if (Session::has('cart')) {

            $data = Session::get('cart.id');
            if (is_array($data))
                $data = array_unique($data);
            else
                $data = array($data);

        }


        return view('baskets', ['data' => $data]);

    }
    public function changeQuantity($id,Request $request)
    {
        $bargID=(int)$id;
        $count=$request->parameters;
        $price=Barg::find($bargID)->F_Fee;
        $off=Barg::find($bargID)->F_Off;
        $off_price=($price-(($price/100)*$off))*$count;
        return ['price'=>$off_price];
    }
    public function removeItem($id)
    {
        $this->id = $id;
        $data = array();
        if (Session::has('cart')) {
            $data = Session::get('cart.id');
            if (is_array($data))
                $data = array_unique($data);
            else
                $data = array($data);
        }

        $collection = collect($data);

        $filtered = $collection->filter(function ($value, $key) {
            $id = $this->id;
            return $value != $id;
        });

        Session::forget('cart');
        if ($filtered->isNotEmpty()) {
            foreach ($filtered->all() as $id) {
                Session::push('cart.id', $id);
            }


            Session::save();
            $data = Session::get('cart.id');
            if (is_array($data))
                $data = array_unique($data);
            else
                $data = array($data);
        } else
            $data = array();

        //return Redirect::back()->with('data',$data);
       return view('baskets', ['data' => $data]);

    }

    public function showCart(Request $request)
    {
        $data = array();
        if (Session::has('cart')) {
            $data = Session::get('cart.id');
            $data = Session::get('cart.id');
            if (is_array($data))
                $data = array_unique($data);
            else
                $data = array($data);
        }


        return view('baskets', ['data' => $data]);

    }

    public function removeAllCart(Request $request)
    {
        $data = array();

        if (Session::has('cart')) {

            Session::forget('cart');
        }

        return view('baskets', ['data' => $data]);

    }

    public function pay_order()
    {


        $MerchantID = 'b7c7dd52-8cdd-11e9-96ce-000c29344814'; //Required
        $Amount = 2000;
        $Description = 'سفارش خرید '; // Required
        $Email = 'UserEmail@Mail.Com'; // Optional
        $Mobile = '09172914763'; // Optional
        $CallbackURL = url('verify');

        $client = new \SoapClient('https://sandbox.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);


        $result = $client->PaymentRequest(
            [
                'MerchantID' => $MerchantID,
                'Amount' => $Amount,
                'Description' => $Description,
                'Email' => $Email,
                'Mobile' => $Mobile,
                'CallbackURL' => $CallbackURL,
            ]
        );
        //dd($result);
        if ($result->Status == 100) {
            //  Header('Location: https://www.zarinpal.com/pg/StartPay/' . $result->Authority . '/ZarinGate');
            return redirect('https://sandbox.zarinpal.com/pg/StartPay/' . $result->Authority . '/ZarinGate');
        } else {
            return redirect(url('baskets/order/1'));

        }

    }

    public function back_order($order_id)
    {
        return view('baskets.back');

    }

    public function verify_order()
    {

        $MerchantID = 'b7c7dd52-8cdd-11e9-96ce-000c29344814';
        $Amount = 2000;
        $Authority = $_GET['Authority'];

        if ($_GET['Status'] == 'OK') {

            $client = new \SoapClient('https://sandbox.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);

            $result = $client->PaymentVerification(
                ['MerchantID' => $MerchantID,
                    'Authority' => $Authority,
                    'Amount' => $Amount]
            );

            if ($result->Status == 100) {
                return redirect(url('baskets/order/1'));
            } else {
                return redirect(url('baskets/order/1'));
            }
        } else {
            return redirect(url('baskets/order/1'));
        }

    }

}
