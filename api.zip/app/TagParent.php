<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TagParent extends Model
{
    //
}
