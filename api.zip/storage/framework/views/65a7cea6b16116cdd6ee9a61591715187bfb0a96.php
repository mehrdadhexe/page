<div class="col-lg-1 col-md-1 hidden-sm hidden-xs right-aside sticky-aside">
    <div id="nava" class="affix-top" style="">
        <div class="float-cat">
            <ul>
                <?php $__currentLoopData = \App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($cat->F_Root==1): ?>
                        <a href="<?php echo e(url('/')); ?>/<?php echo e(\App\Setting::getCity()); ?>/category/<?php echo e($cat->F_CategoryID); ?>/<?php echo e($cat->F_Name); ?>" class="float-cat-todaydeal">
                            <li>
                                <i><i class="icon <?php echo e($cat->F_Icon); ?>"></i></i><span><?php echo e($cat->F_Name); ?></span>
                            </li>
                        </a>

                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </ul>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\resources\views/component/float_cat.blade.php ENDPATH**/ ?>