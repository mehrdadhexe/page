<?php

function ok()
    {
        return " ok ok ok ";
    }
