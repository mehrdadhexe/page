<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main>
        <div class="page-index">
            <div class="wrapper-2">
                <div class="container-fluid">
                    <div class="row h-position">

                        <?php echo $__env->make('component.float_cat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                        <div class="col-lg-22 col-md-22 col-sm-24 col-xs-24 padd-0-xs clearfix">
                            <article class="cat-deal-color main-cat clearfix">
                                <header class="section-header today-netbarg">
                                    <h3 class="hx"><span class="icon icon icon-Logo-fill"></span><span id="searchFor"
                                                                                                       class="article-h3">نتیجه جستجو برای <?php echo e($s); ?> </span>
                                    </h3>
                                </header>

                                <div class="main-cat-deal-list clearfix main-row general-row-deal grd">

                                    <?php $__currentLoopData = $bargs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <div class="col-lg-24 col-md-24 col-sm-24">
                                            <div class="list-items ">
                                                <a href="<?php echo e(url("/")); ?>/<?php echo e(\App\Setting::getCity()); ?>/off/<?php echo e($item->F_BargID); ?>/<?php echo e($item->F_Title); ?>"
                                                   class="figure clearfix"
                                                   style="background-image: url(<?php echo e($item->F_Pic); ?>); background-size: cover;">
                                                    <div class="overlay"></div>
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                    </ul>
                                                    <img
                                                        data-src="<?php echo e($item->F_Pic); ?>"
                                                        alt="<?php echo e($item->F_Title); ?>" data-type="lazy"
                                                        class="sr-only"
                                                        src="<?php echo e($item->F_Pic); ?>">
                                                </a>
                                                <div class="list-deal-details">
                                                    <div class="top-panel">


                                                        <span>
                                                        <a href="<?php echo e(url("/")); ?>/<?php echo e(\App\Setting::getCity()); ?>/off/<?php echo e($item->F_BargID); ?>/<?php echo e($item->F_Title); ?>">
                                                        <h3><?php echo e($item->F_Title); ?></h3>
                                                        </a>
                                                        </span>
                                                    </div>
                                                    <div class="middle-panel clearfix">
                                                        <a href="<?php echo e(url("/")); ?>/<?php echo e(\App\Setting::getCity()); ?>/off/<?php echo e($item->F_BargID); ?>/<?php echo e($item->F_Title); ?>"
                                                           class="deal-desc">
                                                            <span class="hidden-xs"><?php echo e($item->F_Text); ?></span>
                                                            <span
                                                                class="visible-xs"><?php echo e($item->F_Text); ?></span>
                                                        </a></div>

                                                    <div class="bottom-panel">
                                                        <div class="top-bp clearfix">
                                                                    <span class="time-rem">

                                                                        <span></span>
                                                                    </span>
                                                        </div>
                                                        <div class="bottom-bp">
                                                                    <span class="address">
                                                                        <a href="<?php echo e(url("/")); ?>/<?php echo e(\App\Setting::getCity()); ?>/off/<?php echo e($item->F_BargID); ?>/<?php echo e($item->F_Title); ?>">
                                                                            <i class="icon icon-location74"></i>
                                                                            <?php echo e($item->F_Mohale); ?>


                                                                                                                                                  </a>
                                                                    </span>
                                                            <span class="deal-sell">
                                                                        <i class="icon icon-shopping-cart_L"></i>
                                                                        <?php echo e($item->paycount); ?>                                                                           خرید
                                                                    </span>
                                                        </div>
                                                    </div>


                                                </div>
                                                <div class="list-deal-cp">
                                                    <div class="list-discount-tag">
                                                        ٪<?php echo e($item->F_Off); ?>

                                                    </div>
                                                    <div class="cp-holder">
                                                        <a href=""
                                                           class="cdbf-location truncate visible-xs">
                                                            <span class="ir">
                                                                <i class="icon icon-location74"></i>
                                                            </span>
                                                            <span class="cdbfl-address">
                                                            انقلاب                                                            </span>
                                                        </a>
                                                        <span class="cp-price-float clearfix">
                                                            <span class="discount">
                                                                <del><?php echo e($item->F_Fee); ?></del>
                                                            </span>
                                                            <span class="full-price">
                                                                <span class="full-price-s"><?php echo e($item->full_price); ?></span>
                                                                <span class="full-price-s irr"> تومان</span>
                                                            </span>
                                                        </span>
                                                        <a href="<?php echo e(url("/")); ?>/<?php echo e(\App\Setting::getCity()); ?>/off/<?php echo e($item->F_BargID); ?>/<?php echo e($item->F_Title); ?>"
                                                           class="nb-btn nb-btn-icon nb-btn-success">مشاهده و خرید
                                                            <i class="icon icon-shopping-cart2"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>

                            </article>
                            <div class="col-md-1"></div>
                        </div>

                        <?php echo $__env->make('component.support', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/page/search.blade.php ENDPATH**/ ?>