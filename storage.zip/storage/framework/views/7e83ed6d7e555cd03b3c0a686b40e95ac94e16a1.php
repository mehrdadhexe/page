<?php $__env->startSection('content'); ?>
    <main>
<?php
  //  F_URL
    //dd(\App\Barg::find(1)->with('Media')->get());
?>
        <div class="page-index page-home">
            <div class="wrapper-1">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-1 col-md-1 hidden-sm hidden-xs"></div>

                        <div class="col-lg-3 hidden-md hidden-sm hidden-xs">
                            <nav>
                                <ul class="side-cat" itemscope=""
                                    itemtype="http://www.schema.org/SiteNavigationElement">


                                    <?php $__currentLoopData = \App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($cat->F_Root==1): ?>
                                            <li class="li-home"><a href="/tehran/c:todaydeals/"
                                                                   style="height: 39.3333px; line-height: 38.3333px;"><i><i
                                                                class="icon <?php echo e($cat->F_Icon); ?>"></i></i><span><?php echo e($cat->F_Name); ?></span></a>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </nav>
                        </div>
                        <div class="col-lg-19 col-md-22">
                            <div class="slider-full clearfix ">
                                <div class="overlay"></div>
                                <div id="carousel_2" data-ride="carousel" class="carousel carousel-2 slide nb-carousel">
                                    <!-- Indicators-->
                                    <!-- <ol class="carousel-indicators">
                                                    <li data-target="#carousel_2" data-slide-to=""
                                            class=" ">
                                            <i class="icon"></i>
                                        </li>
                                            </ol> -->
                                    <!-- Wrapper for slides-->
                                    <div role="listbox" class="carousel-inner">
                                        <?php
                                            $i=1;
                                        ?>
                                        <?php $__currentLoopData = \App\Slider::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <div class="item <?php if($i==1)echo'active';?>">
                                                <ul class="deal-tag list-unstyled">
                                                </ul>
                                                <a href="">
                                                    <img src="<?php echo e($slider->img); ?>" alt="<?php echo e($slider->alt); ?>"> </a>
                                            </div>
                                            <?php
                                                $i++;
                                            ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>
                                    <!-- Controls--><a href="#carousel_2" role="button" data-slide="prev"
                                                       class="left carousel-control"><span aria-hidden="true"
                                                                                           class="icon icon-arrow-left"></span><span
                                                class="sr-only">Previous</span></a><a href="#carousel_2" role="button"
                                                                                      data-slide="next"
                                                                                      class="right carousel-control"><span
                                                aria-hidden="true" class="icon icon-arrow-right"></span><span
                                                class="sr-only">Next</span></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-1 col-md-1 hidden-sm hidden-xs"></div>
                    </div>
                    <div class="row">
                        <div class="col-lg-1 col-md-1 hidden-sm hidden-xs"></div>
                        <div class="col-lg-22 col-md-22">
                            <div class="row under-slider-banner">
                                <div class="col-lg-8 col-md-8 col-sm-8">
                                    <a target="_blank"
                                       href="http://netbarg.com/trend/%D9%85%DB%8C%DA%A9%D8%B1%D9%88%D8%AF%D8%B1%D9%85/"
                                       class="figure m-b">
                                        <img src="http://static.netbarg.com/img/banner/banners/rightSmallBanner/93/50f40701.jpg"
                                             alt="netbarg"> </a>
                                </div>
                                <div class="col-lg-8 col-md-8 col-sm-8">
                                    <a target="_blank"
                                       href="http://netbarg.com/trend/%D9%87%D8%AA%D9%84-%D9%85%D8%B4%D9%87%D8%AF/"
                                       class="figure m-b">
                                        <img src="http://static.netbarg.com/img/banner/banners/centerSmallBanner/91/59010762.jpg"
                                             alt="netbarg"> </a>
                                </div>
                                <div class="col-lg-8 col-md-8 col-sm-8">
                                    <a target="_blank"
                                       href="http://netbarg.com/trend/%D8%A7%D8%B3%D8%AA%D8%AE%D8%B1%D9%87%D8%A7%DB%8C-%D8%BA%D8%B1%D8%A8-%D8%AA%D9%87%D8%B1%D8%A7%D9%86/"
                                       class="figure m-b">
                                        <img src="http://static.netbarg.com/img/banner/banners/leftSmallBanner/89/47f7068c.jpg"
                                             alt="netbarg"> </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-1 col-md-1 hidden-sm hidden-xs"></div>
                    </div>
                </div>
            </div>
            <div class="wrapper-2">
                <div class="container-fluid">
                    <div class="row h-position">
                        <div class="col-lg-1 col-md-1 hidden-sm hidden-xs right-aside sticky-aside">
                            <div id="nava" class="affix-top" style="">
                                <div class="float-cat">
                                    <ul>
                                        <?php $__currentLoopData = \App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($cat->F_Root==1): ?>
                                                <a href="/tehran/c:todaydeals/" class="float-cat-todaydeal">
                                                    <li>
                                                        <i><i class="icon <?php echo e($cat->F_Icon); ?>"></i></i><span><?php echo e($cat->F_Name); ?></span>
                                                    </li>
                                                </a>

                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-22 col-md-22 col-sm-24 col-xs-24 padd-0-xs clearfix">
                            <section class="related cat-deal-color main-cat around-me clearfix">
                                <header class="section-header">
                                    <h6 class="hx"><span class="icon icon-special-user-offer"></span><span
                                                class="article-h3">پیشنهادات ویژه نت برگ</span></h6>
                                </header>
                                <div class="main-cat-deal-thumbnail clearfix main-row">

                                    <?php $__currentLoopData = \App\Suggestions::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-6 col-md-12 col-sm-12 col-xs-24 cds-item  ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href=""
                                                   class="figure"
                                                   style="background-image: url(<?php echo e(\App\Barg::find($offer_item->F_BargID)->F_Pic); ?>); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="<?php echo e(\App\Barg::find($offer_item->F_BargID)->F_Pic); ?>"
                                                         alt="جشنواره سرزمین فکر بازیا در باغ کتاب" data-type="lazy"
                                                         class="sr-only"
                                                         src="<?php echo e(\App\Barg::find($offer_item->F_BargID)->F_Pic); ?>">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title">
                                                        <a href="<?php echo e(url('/bandar/off')); ?>/<?php echo e(\App\Barg::find($offer_item->F_BargID)->F_BargID); ?>/<?php echo e(\App\Barg::find($offer_item->F_BargID)->F_Title); ?>"
                                                           itemprop="url" class="truncate">
                                                            <?php echo e(\App\Barg::find($offer_item->F_BargID)->F_Title); ?>

                                                             </a>
                                                    </h4>
                                                    <span class="cdbm-total-buy">
                                <span class="ir">
                                    <i class="icon icon-shopping-cart hidden-xs"></i>
                                    <i class="icon icon-shopping-cart_L visible-xs"></i>
                                </span>
                                <span class="cdbm-tb-total">

                                    <?php echo e(\App\OrderDetail::where("F_BargID","=",$offer_item->F_BargID)->count()); ?>

                                                                   </span>
                            </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix">
                                                    <a href="/area/اتوبان حقانی/" class="cdbf-location truncate">
                                <span class="ir">
                                    <i class="icon icon-location74"></i>
                                </span>
                                                        <span class="cdbfl-address">
                                                            <?php echo e(\App\Barg::find($offer_item->F_BargID)->F_Adress); ?>


                                                                   </span>
                                                    </a>
                                                    <span class="cdbf-takhfif">
                                <span class="cdbft-shape">
                                    <span class="cdbft-shape-text">
                                        %<?php echo e(\App\Barg::find($offer_item->F_BargID)->F_Off); ?>                                    </span>
                                </span>
                            </span>
                                                    <span class="cdbf-price">
                                <ins class="cdbf-netbarg-price">
                                    <span itemprop="price" content="280000">
                                        <?php echo e(number_format(\App\Barg::find($offer_item->F_BargID)->F_Fee)); ?>                                 </span>
                                    <span itemprop="priceCurrency" content="IRR"> تومان</span>
                                </ins>
                            </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </section>

                            <section class="cat-big-small">

<?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <article id="float-cat-restaurant" class="cat-deal-color color-rescoffee">
                                    <header class="section-header"><a href="/tehran/c:restaurant/"
                                                                      class="visible-xs">بیشتر</a>
                                        <h3 class="hx"><span class="ir"><i class="icon <?php echo e($item["F_Category"]->F_Icon); ?>"></i></span><a
                                                    href="/tehran/c:restaurant/" class="article-h3">
                                                <?php echo e($item["F_Category"]->F_Name); ?>



                                            </a>
                                        </h3>
                                    </header>

                                    <div class="main-row clearfix">
                                        <?php if(count($item["F_Barg"])>=1): ?>
                                        <div itemscope="" itemtype="http://schema.org/Offer"
                                             class="col-lg-12 col-md-12 col-sm-24 col-xs-24 cat-deal-bigbox">
                                            <div class="cat-deal-box ">
                                                <a href="/tehran/d/c:restaurant/154389/فودکورت-پل-طبیعت-65/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_large/deals/154389/1eab03e1.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <img data-src="http://static.netbarg.com/img/responsive_large/deals/154389/1eab03e1.jpg"
                                                         alt="فودکورت پل طبیعت" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_large/deals/154389/1eab03e1.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_large/deals/154389/1eab03e1.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="<?php echo e(url('/bandar/off')); ?>/<?php echo e($item["F_Barg"][0]->F_BargID); ?>/<?php echo e($item["F_Barg"][0]->F_Title); ?>"
                                                                                              class="truncate">


                                                                <?php echo e($item["F_Barg"][0]->F_Title); ?>




                                                        </a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                6948                            </span></span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><span
                                                            class="cdbf-takhfif"><span
                                                                class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%34</span></span></span><a
                                                            href="/area/ونک/" class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">ونک</span></a><a
                                                            href="/tehran/d/c:restaurant/154389/فودکورت-پل-طبیعت-65/"
                                                            class="cdbf-buy-icon">
                                                        <button class="nb-btn nb-btn-icon nb-btn-success">مشاهده و
                                                            خرید<i
                                                                    class="icon icon-shopping-cart2"></i></button>
                                                    </a><span class="cdbf-price">
            <del class="cdbf-real-price"><span></span></del><ins class="cdbf-netbarg-price">
            <span itemprop="price" content="165000">

                    <?php echo e(number_format(\App\Barg::find($item["F_Barg"][0]->F_BargID)->F_Fee)); ?>




            </span><span itemprop="priceCurrency"
                                                                        content="IRR"> تومان</span></ins></span></div>
                                            </div>
                                        </div>
                                        <?php endif; ?>


                                        <div class="col-lg-12 col-md-12 col-sm-24 col-xs-24 cat-deal-smallbox">
                                            <div class="row">

                                                <?php if(count($item["F_Barg"])>=2): ?>

                                                <div itemscope="" itemtype="http://schema.org/Offer"
                                                     class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                    <div class="cat-deal-box"><a
                                                                href="/tehran/d/c:restaurant/159010/صبحانه-سالم-در-عمارت-خانه-پدری/"
                                                                class="figure"
                                                                style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/159010/1b4f03ab.jpg&quot;); background-size: cover;">
                                                            <ul class="deal-tag list-unstyled">
                                                                <li class="orange-label"></li>
                                                                <li class="violet-label"></li>
                                                            </ul>
                                                            <div class="overlay">
                                                                <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                            </div>
                                                            <img data-src="http://static.netbarg.com/img/responsive_small/deals/159010/1b4f03ab.jpg"
                                                                 alt="صبحانه سالم در عمارت خانه پدری" data-type="lazy"
                                                                 shema="1" itemprop="image"
                                                                 content="http://static.netbarg.com/img/responsive_small/deals/159010/1b4f03ab.jpg"
                                                                 class="sr-only"
                                                                 src="http://static.netbarg.com/img/responsive_small/deals/159010/1b4f03ab.jpg"></a>
                                                        <div class="cat-deal-box-main clearfix">
                                                            <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                                      href="/tehran/d/c:restaurant/159010/صبحانه-سالم-در-عمارت-خانه-پدری/"
                                                                                                      class="truncate">


                                                                        <?php echo e($item["F_Barg"][1]->F_Title); ?>



                                                                </a>
                                                            </h4>
                                                            <span class="cdbm-total-buy"><span class="ir"><i
                                                                            class="icon icon-shopping-cart hidden-xs"></i><i
                                                                            class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                        class="cdbm-tb-total">
                                            1094                                        </span></span>
                                                        </div>
                                                        <div class="cat-deal-box-footer clearfix"><a
                                                                    href="/area/هفت-تیر/"
                                                                    class="cdbf-location truncate"><span
                                                                        class="ir"><i
                                                                            class="icon icon-location74"></i></span><span
                                                                        class="cdbfl-address">هفت تیر</span></a><span
                                                                    class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                            class="cdbft-shape-text">%45</span></span></span><span
                                                                    class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۱۸,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                            itemprop="price"
                                                                            content="99000">۹,۹۰۰</span><span
                                                                            itemprop="priceCurrency"
                                                                            content="IRR"> تومان</span></ins></span>
                                                        </div>
                                                    </div>
                                                </div>

                                                <?php endif; ?>
                                                    <?php if(count($item["F_Barg"])>=3): ?>
                                                <div itemscope="" itemtype="http://schema.org/Offer"
                                                     class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                    <div class="cat-deal-box"><a
                                                                href="/tehran/d/c:restaurant/158081/بوفه-آزاد-رستوران-زیتون/"
                                                                class="figure"
                                                                style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/158081/1b5e03ab.jpg&quot;); background-size: cover;">
                                                            <ul class="deal-tag list-unstyled">
                                                                <li class="orange-label"></li>
                                                                <li class="violet-label"></li>
                                                            </ul>
                                                            <div class="overlay">
                                                                <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                            </div>
                                                            <img data-src="http://static.netbarg.com/img/responsive_small/deals/158081/1b5e03ab.jpg"
                                                                 alt="بوفه آزاد رستوران زیتون" data-type="lazy"
                                                                 shema="1"
                                                                 itemprop="image"
                                                                 content="http://static.netbarg.com/img/responsive_small/deals/158081/1b5e03ab.jpg"
                                                                 class="sr-only"
                                                                 src="http://static.netbarg.com/img/responsive_small/deals/158081/1b5e03ab.jpg"></a>
                                                        <div class="cat-deal-box-main clearfix">
                                                            <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                                      href="/tehran/d/c:restaurant/158081/بوفه-آزاد-رستوران-زیتون/"
                                                                                                      class="truncate">

                                                                        <?php echo e($item["F_Barg"][2]->F_Title); ?>



                                                                </a>
                                                            </h4>
                                                            <span class="cdbm-total-buy"><span class="ir"><i
                                                                            class="icon icon-shopping-cart hidden-xs"></i><i
                                                                            class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                        class="cdbm-tb-total">
                                            1470                                        </span></span>
                                                        </div>
                                                        <div class="cat-deal-box-footer clearfix"><a
                                                                    href="/area/پارک-وی/"
                                                                    class="cdbf-location truncate"><span
                                                                        class="ir"><i
                                                                            class="icon icon-location74"></i></span><span
                                                                        class="cdbfl-address">پارک وی</span></a><span
                                                                    class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                            class="cdbft-shape-text">%<?php echo e(number_format(\App\Barg::find($item["F_Barg"][2]->F_BargID)->F_Off)); ?></span></span></span><span
                                                                    class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۱۲۵,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                            itemprop="price"
                                                                            content="625000">۶۲,۵۰۰</span><span
                                                                            itemprop="priceCurrency"
                                                                            content="IRR"> تومان</span></ins></span>
                                                        </div>
                                                    </div>
                                                </div>
                                                    <?php endif; ?>

                                                    <?php if(count($item["F_Barg"])>=4): ?>
                                                <div itemscope="" itemtype="http://schema.org/Offer"
                                                     class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                    <div class="cat-deal-box"><a
                                                                href="/tehran/d/c:restaurant/157579/پیتزا-خوراک-و-برگر-در-رستوران-ایتالیایی-آوا-پلاس/"
                                                                class="figure"
                                                                style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/157579/1ef603e0.jpg&quot;); background-size: cover;">
                                                            <ul class="deal-tag list-unstyled">
                                                                <li class="orange-label"></li>
                                                                <li class="violet-label"></li>
                                                            </ul>
                                                            <div class="overlay">
                                                                <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                            </div>
                                                            <img data-src="http://static.netbarg.com/img/responsive_small/deals/157579/1ef603e0.jpg"
                                                                 alt="پیتزا ، خوراک و برگر در رستوران ایتالیایی آوا پلاس"
                                                                 data-type="lazy" shema="1" itemprop="image"
                                                                 content="http://static.netbarg.com/img/responsive_small/deals/157579/1ef603e0.jpg"
                                                                 class="sr-only"
                                                                 src="http://static.netbarg.com/img/responsive_small/deals/157579/1ef603e0.jpg"></a>
                                                        <div class="cat-deal-box-main clearfix">
                                                            <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                                      href="/tehran/d/c:restaurant/157579/پیتزا-خوراک-و-برگر-در-رستوران-ایتالیایی-آوا-پلاس/"
                                                                                                      class="truncate">

                                                                    <?php if(count($item["F_Barg"])>=4): ?>
                                                                        <?php echo e($item["F_Barg"][3]->F_Title); ?>


                                                                    <?php endif; ?>
                                                                </a>
                                                            </h4>
                                                            <span class="cdbm-total-buy"><span class="ir"><i
                                                                            class="icon icon-shopping-cart hidden-xs"></i><i
                                                                            class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                        class="cdbm-tb-total">
                                            1173                                        </span></span>
                                                        </div>
                                                        <div class="cat-deal-box-footer clearfix"><a
                                                                    href="/area/نیاوران/"
                                                                    class="cdbf-location truncate"><span
                                                                        class="ir"><i
                                                                            class="icon icon-location74"></i></span><span
                                                                        class="cdbfl-address">نیاوران</span></a><span
                                                                    class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                            class="cdbft-shape-text">%49</span></span></span><span
                                                                    class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۳۹,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                            itemprop="price"
                                                                            content="198900">۱۹,۸۹۰</span><span
                                                                            itemprop="priceCurrency"
                                                                            content="IRR"> تومان</span></ins></span>
                                                        </div>
                                                    </div>
                                                </div>
                                                    <?php endif; ?>

                                                <div class="col-lg-12 col-md-12 col-sm-24 cds-item hidden-xs done">
                                                    <div class="cds-all-view-box"><span class="ir"><i
                                                                    class="icon icon-burger"></i></span>
                                                        <h4 class="cds-title"><?php echo e(\App\Barg::where('F_CategoryID',$item["F_Category"]->F_CategoryID)->count()); ?> پیشنهاد رستوران و کافی شاپ</h4>
                                                        <a href="/tehran/c:restaurant/">
                                                            <button class="nb-btn nb-btn-success">مشاهده همه</button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                </article>
                                <figure class="figure-ads-baner hidden-xs visible-lg">
                                    <a href="http://netbarg.com/trend/%D8%B3%D9%81%D8%B1%D9%87-%D8%AE%D8%A7%D9%86%D9%87/"
                                       target="_blank">
                                        <img src="http://static.netbarg.com/img/banner/banners/restaurantBanner/77/c6d90dc9.jpg"
                                             alt="رستوران و کافی شاپ"> </a>
                                </figure>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </section>
                            <article class="cat-deal-color main-cat">
                                <header class="section-header today-netbarg">
                                    <h3 class="hx"><span class="icon icon icon-Logo-fill"></span><span
                                                class="article-h3">نت‌برگ‌های امروز</span>
                                    </h3><span class="pull-left deals-filter"><span class="clearfix gender-selector">
        </span></span></header>
                                <div class="main-cat-deal-thumbnail clearfix main-row">
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:restaurant/159166/رستوران-بین-المللیvip-با-منو-غذاهای-ایرانی-و-فرنگی/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159166/1b2b03a9.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159166/1b2b03a9.jpg"
                                                         alt="رستوران بین المللیVIP با منو غذاهای ایرانی و فرنگی"
                                                         data-type="lazy" shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159166/1b2b03a9.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159166/1b2b03a9.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:restaurant/159166/رستوران-بین-المللیvip-با-منو-غذاهای-ایرانی-و-فرنگی/"
                                                                                              class="truncate">رستوران
                                                            بین
                                                            المللیVIP با منو غذاهای ایرانی و فرنگی</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy isempty"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            0                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/شهرک-غرب/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">شهرک غرب</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%33            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۷۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="469000"
                                                                           class="cdbf-netbarg-price">
                            <span>۴۶,۹۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:entertainment/159243/پرواز-با-پاراگلایدر-توسط-خلبان-باقری/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159243/1d4b03ec.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159243/1d4b03ec.jpg"
                                                         alt="پرواز با پاراگلایدر توسط خلبان باقری" data-type="lazy"
                                                         shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159243/1d4b03ec.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159243/1d4b03ec.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:entertainment/159243/پرواز-با-پاراگلایدر-توسط-خلبان-باقری/"
                                                                                              class="truncate">پرواز با
                                                            پاراگلایدر توسط خلبان باقری</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            336                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/بلوار وردآورد/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">بلوار وردآورد</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%40            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۴۵۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="2700000"
                                                                           class="cdbf-netbarg-price">
                            <span>۲۷۰,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:restaurant/156024/بوفه-شام-رستوران-شهربانو-68/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/156024/216d0405.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/156024/216d0405.jpg"
                                                         alt="بوفه شام رستوران شهربانو" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/156024/216d0405.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/156024/216d0405.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:restaurant/156024/بوفه-شام-رستوران-شهربانو-68/"
                                                                                              class="truncate">بوفه شام
                                                            رستوران شهربانو</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            18233                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/شهرک-غرب/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">شهرک غرب</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%40            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۱۳۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="780000"
                                                                           class="cdbf-netbarg-price">
                            <span>۷۸,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:restaurant/159207/پکیج-غذاهای-ایرانی-در-رستوران-هتل-سیمرغ/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159207/36a50571.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159207/36a50571.jpg"
                                                         alt="پکیج غذاهای ایرانی در رستوران هتل سیمرغ" data-type="lazy"
                                                         shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159207/36a50571.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159207/36a50571.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:restaurant/159207/پکیج-غذاهای-ایرانی-در-رستوران-هتل-سیمرغ/"
                                                                                              class="truncate">پکیج
                                                            غذاهای
                                                            ایرانی در رستوران هتل سیمرغ</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy isempty"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            0                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/ولیعصر-ساعی-1/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">ولیعصر-ساعی</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%25            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۸۹,۳۰۰</span></del>
                                                                              <ins itemprop="price" content="669750"
                                                                                   class="cdbf-netbarg-price"><span>۶۶,۹۷۵</span><span
                                                                                          itemprop="priceCurrency"
                                                                                          content="IRR"> تومان</span></ins></span>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:entertainment/159240/آفرود-در-تهران-با-آفرود-باقری/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159240/22dc042d.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159240/22dc042d.jpg"
                                                         alt="آفرود در تهران با آفرود باقری" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159240/22dc042d.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159240/22dc042d.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:entertainment/159240/آفرود-در-تهران-با-آفرود-باقری/"
                                                                                              class="truncate">آفرود در
                                                            تهران با آفرود باقری</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            30                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/وردآورد/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">وردآورد</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%50            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۲۵۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="1250000"
                                                                           class="cdbf-netbarg-price">
                            <span>۱۲۵,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:restaurant/159200/انواع-سرویس-چای-سنتی-در-سفره-خانه-سنتی-کوهستان/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159200/1bae03b1.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159200/1bae03b1.jpg"
                                                         alt="انواع سرویس چای سنتی در سفره خانه سنتی کوهستان"
                                                         data-type="lazy" shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159200/1bae03b1.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159200/1bae03b1.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:restaurant/159200/انواع-سرویس-چای-سنتی-در-سفره-خانه-سنتی-کوهستان/"
                                                                                              class="truncate">انواع
                                                            سرویس
                                                            چای سنتی در سفره خانه سنتی کوهستان</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            68                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/خیابان-هنگام/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">خیابان هنگام </span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%55            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۳۵,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="157500"
                                                                           class="cdbf-netbarg-price">
                            <span>۱۵,۷۵۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:beauty/159169/کراتینه-مو-در-آرایشگاه-و-آموزشگاه-سوسن/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159169/1f6703f5.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159169/1f6703f5.jpg"
                                                         alt="کراتینه مو در آرایشگاه و آموزشگاه سوسن" data-type="lazy"
                                                         shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159169/1f6703f5.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159169/1f6703f5.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:beauty/159169/کراتینه-مو-در-آرایشگاه-و-آموزشگاه-سوسن/"
                                                                                              class="truncate">کراتینه
                                                            مو در
                                                            آرایشگاه و آموزشگاه سوسن</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy isempty"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            0                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/ستاری/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">ستاری</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%70            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۲۸۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="840000"
                                                                           class="cdbf-netbarg-price">
                            <span>۸۴,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:health/159187/تزریق-ژل-در-مطب-دکتر-کیوان/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159187/1f2d03f0.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159187/1f2d03f0.jpg"
                                                         alt="تزریق ژل در مطب دکتر کیوان" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159187/1f2d03f0.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159187/1f2d03f0.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:health/159187/تزریق-ژل-در-مطب-دکتر-کیوان/"
                                                                                              class="truncate">تزریق ژل
                                                            در
                                                            مطب دکتر کیوان</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy isempty"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            0                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/خیابان-ظفر/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">خیابان ظفر</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%70            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۱۵۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="450000"
                                                                           class="cdbf-netbarg-price">
                            <span>۴۵,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:education/159155/آموزش-زبان-ترکی-استانبولی-در-موسسه-اکسیر/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159155/1f5803f3.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159155/1f5803f3.jpg"
                                                         alt="آموزش زبان ترکی استانبولی در موسسه اکسیر" data-type="lazy"
                                                         shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159155/1f5803f3.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159155/1f5803f3.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:education/159155/آموزش-زبان-ترکی-استانبولی-در-موسسه-اکسیر/"
                                                                                              class="truncate">آموزش
                                                            زبان
                                                            ترکی استانبولی در موسسه اکسیر</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            1                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/توحید/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">توحید</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%90            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۳۰۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="300000"
                                                                           class="cdbf-netbarg-price">
                            <span>۳۰,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:health/159190/کامپوزیت-دندان-توسط-دکتر-خانچی/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159190/1e5003dd.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159190/1e5003dd.jpg"
                                                         alt="کامپوزیت دندان توسط دکتر خانچی" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159190/1e5003dd.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159190/1e5003dd.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:health/159190/کامپوزیت-دندان-توسط-دکتر-خانچی/"
                                                                                              class="truncate">کامپوزیت
                                                            دندان توسط دکتر خانچی</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            548                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/سعادت-آباد/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">سعادت آباد</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%61            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۵۰۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="1950000"
                                                                           class="cdbf-netbarg-price">
                            <span>۱۹۵,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:education/159175/دوره-های-آموزشی-ویژه-کودکان-در-مهد-کودک-نوید-شادی/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159175/373e0573.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159175/373e0573.jpg"
                                                         alt="دوره های آموزشی ویژه کودکان در مهد کودک نوید شادی"
                                                         data-type="lazy" shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159175/373e0573.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159175/373e0573.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:education/159175/دوره-های-آموزشی-ویژه-کودکان-در-مهد-کودک-نوید-شادی/"
                                                                                              class="truncate">دوره های
                                                            آموزشی ویژه کودکان در مهد کودک نوید شادی</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            1                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/نارمک/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">نارمک</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%90            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۲۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="20000"
                                                                           class="cdbf-netbarg-price">
                            <span>۲,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:health/159196/پلاسما-جت-در-مطب-دکتر-خاکپور/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159196/1e1b03d1.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159196/1e1b03d1.jpg"
                                                         alt="پلاسما جت در مطب دکتر خاکپور" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159196/1e1b03d1.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159196/1e1b03d1.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:health/159196/پلاسما-جت-در-مطب-دکتر-خاکپور/"
                                                                                              class="truncate">پلاسما جت
                                                            در
                                                            مطب دکتر خاکپور</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy isempty"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            0                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a
                                                            href="/area/ولیعصر-پارک-ملت-1/"
                                                            class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">ولیعصر- پارک ملت</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%57            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۳۰۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="1290000"
                                                                           class="cdbf-netbarg-price">
                            <span>۱۲۹,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:health/159183/پاکسازی-صورت-و-لیفتینگ-صورت-توسط-دکتر-کلانتری/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159183/18390378.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159183/18390378.jpg"
                                                         alt="پاکسازی صورت و لیفتینگ صورت توسط دکتر کلانتری"
                                                         data-type="lazy" shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159183/18390378.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159183/18390378.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:health/159183/پاکسازی-صورت-و-لیفتینگ-صورت-توسط-دکتر-کلانتری/"
                                                                                              class="truncate">پاکسازی
                                                            صورت
                                                            و لیفتینگ صورت توسط دکتر کلانتری</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            8                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/ستارخان/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">ستارخان</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%80            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۴۵,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="90000"
                                                                           class="cdbf-netbarg-price">
                            <span>۹,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:entertainment/159235/تور-رفتینگ-زاینده-رود-1-5-روزه-34/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159235/3ca3062b.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159235/3ca3062b.jpg"
                                                         alt="تور رفتینگ زاینده رود 1/5 روزه" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159235/3ca3062b.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159235/3ca3062b.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:entertainment/159235/تور-رفتینگ-زاینده-رود-1-5-روزه-34/"
                                                                                              class="truncate">تور
                                                            رفتینگ
                                                            زاینده رود 1/5 روزه</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy isempty"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            0                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/تور-گردشگری/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">تور گردشگری</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%32            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۲۸۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="1904000"
                                                                           class="cdbf-netbarg-price">
                            <span>۱۹۰,۴۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:beauty/159164/اپیلاسیون-بدن-در-آرایشگاه-نیکان/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159164/26ce045f.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159164/26ce045f.jpg"
                                                         alt="اپیلاسیون بدن در آرایشگاه نیکان" data-type="lazy"
                                                         shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159164/26ce045f.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159164/26ce045f.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:beauty/159164/اپیلاسیون-بدن-در-آرایشگاه-نیکان/"
                                                                                              class="truncate">اپیلاسیون
                                                            بدن
                                                            در آرایشگاه نیکان</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy isempty"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            0                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/نارمك/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">نارمك</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%67            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۲,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="6600"
                                                                           class="cdbf-netbarg-price">
                            <span>۶۶۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:beauty/159177/جوانسازی-پوست-در-آرایشگاه-و-آموزشگاه-سوسن/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159177/1f6703f5.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159177/1f6703f5.jpg"
                                                         alt="جوانسازی پوست در آرایشگاه و آموزشگاه سوسن"
                                                         data-type="lazy"
                                                         shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159177/1f6703f5.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159177/1f6703f5.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:beauty/159177/جوانسازی-پوست-در-آرایشگاه-و-آموزشگاه-سوسن/"
                                                                                              class="truncate">جوانسازی
                                                            پوست
                                                            در آرایشگاه و آموزشگاه سوسن</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy isempty"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            0                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/ستاری/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">ستاری</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%75            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۷۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="175000"
                                                                           class="cdbf-netbarg-price">
                            <span>۱۷,۵۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:health/159188/تزریق-بوتاکس-با-دکتر-کیوان/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159188/1b7503ad.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159188/1b7503ad.jpg"
                                                         alt="تزریق بوتاکس با دکتر کیوان" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159188/1b7503ad.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159188/1b7503ad.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:health/159188/تزریق-بوتاکس-با-دکتر-کیوان/"
                                                                                              class="truncate">تزریق
                                                            بوتاکس
                                                            با دکتر کیوان</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            3                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/خیابان-ظفر/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">خیابان ظفر</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%71            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۱۰۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="290000"
                                                                           class="cdbf-netbarg-price">
                            <span>۲۹,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:art/159165/ثبت-خاطرات-به-یادماندنی-در-آتلیه-رویال-آس/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159165/1b4003a9.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159165/1b4003a9.jpg"
                                                         alt="ثبت خاطرات به یادماندنی در آتلیه رویال آس"
                                                         data-type="lazy"
                                                         shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159165/1b4003a9.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159165/1b4003a9.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:art/159165/ثبت-خاطرات-به-یادماندنی-در-آتلیه-رویال-آس/"
                                                                                              class="truncate">ثبت
                                                            خاطرات به
                                                            یادماندنی در آتلیه رویال آس</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            66                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a
                                                            href="/area/فلکه-اول-تهرانپارس/"
                                                            class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">فلکه اول تهرانپارس</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%85            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۳۵,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="52500"
                                                                           class="cdbf-netbarg-price">
                            <span>۵,۲۵۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:health/159193/میکرونیدلینگ-پوست-توسط-دکتر-خدامی/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159193/1c2b03bf.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159193/1c2b03bf.jpg"
                                                         alt="میکرونیدلینگ پوست توسط دکتر خدامی" data-type="lazy"
                                                         shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159193/1c2b03bf.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159193/1c2b03bf.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:health/159193/میکرونیدلینگ-پوست-توسط-دکتر-خدامی/"
                                                                                              class="truncate">میکرونیدلینگ
                                                            پوست توسط دکتر خدامی</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy isempty"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            0                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/مترو-شریعتی/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">مترو شریعتی</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%87            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۱۵۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="195000"
                                                                           class="cdbf-netbarg-price">
                            <span>۱۹,۵۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:health/159180/میکرودرم-در-مطب-دکتر-ملکیاری/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159180/1ed803e9.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159180/1ed803e9.jpg"
                                                         alt="میکرودرم در مطب دکتر ملکیاری" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159180/1ed803e9.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159180/1ed803e9.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:health/159180/میکرودرم-در-مطب-دکتر-ملکیاری/"
                                                                                              class="truncate">میکرودرم
                                                            در
                                                            مطب دکتر ملکیاری</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            2                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a
                                                            href="/area/روبروی مترو قلهک/"
                                                            class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">روبروی مترو قلهک</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%91            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۸۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="72000"
                                                                           class="cdbf-netbarg-price">
                            <span>۷,۲۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:health/159184/تقویت-و-آبرسانی-مو-توسط-دکتر-کلانتری/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159184/4.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159184/4.jpg"
                                                         alt="تقویت و آبرسانی مو توسط دکتر کلانتری" data-type="lazy"
                                                         shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159184/4.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159184/4.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:health/159184/تقویت-و-آبرسانی-مو-توسط-دکتر-کلانتری/"
                                                                                              class="truncate">تقویت و
                                                            آبرسانی مو توسط دکتر کلانتری</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            8                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/ستارخان/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">ستارخان</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%80            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۴۵,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="90000"
                                                                           class="cdbf-netbarg-price">
                            <span>۹,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:entertainment/159231/تور-آبشار-دارنو-جنگل-فراخین-و-ساحل-نوشهر-یکروزه/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159231/33d5058d.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159231/33d5058d.jpg"
                                                         alt="تور آبشار دارنو ، جنگل فراخین و ساحل نوشهر یکروزه"
                                                         data-type="lazy" shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159231/33d5058d.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159231/33d5058d.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:entertainment/159231/تور-آبشار-دارنو-جنگل-فراخین-و-ساحل-نوشهر-یکروزه/"
                                                                                              class="truncate">تور آبشار
                                                            دارنو ، جنگل فراخین و ساحل نوشهر یکروزه</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy isempty"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            0                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/تور-گردشگری/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">تور گردشگری</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%23            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۸۵,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="654500"
                                                                           class="cdbf-netbarg-price">
                            <span>۶۵,۴۵۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:health/159152/لیزر-موهای-زائد-الکساندرایت-در-مطب-دکتر-خدامی/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159152/1c2403c0.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159152/1c2403c0.jpg"
                                                         alt="لیزر موهای زائد الکساندرایت در مطب دکتر خدامی"
                                                         data-type="lazy" shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159152/1c2403c0.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159152/1c2403c0.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:health/159152/لیزر-موهای-زائد-الکساندرایت-در-مطب-دکتر-خدامی/"
                                                                                              class="truncate">لیزر
                                                            موهای
                                                            زائد الکساندرایت در مطب دکتر خدامی</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy isempty"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            0                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/مترو-شریعتی/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">مترو شریعتی</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%80            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۲۰,۰۰۰</span></del>
                                                                              <ins itemprop="price" content="40000"
                                                                                   class="cdbf-netbarg-price"><span>۴,۰۰۰</span><span
                                                                                          itemprop="priceCurrency"
                                                                                          content="IRR"> تومان</span></ins></span>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:beauty/159239/کاشت-ناخن-و-ترمیم-ناخن-در-آرایشگاه-صدف/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159239/1b5803ad.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159239/1b5803ad.jpg"
                                                         alt="کاشت ناخن و ترمیم ناخن در آرایشگاه صدف" data-type="lazy"
                                                         shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159239/1b5803ad.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159239/1b5803ad.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:beauty/159239/کاشت-ناخن-و-ترمیم-ناخن-در-آرایشگاه-صدف/"
                                                                                              class="truncate">کاشت ناخن
                                                            و
                                                            ترمیم ناخن در آرایشگاه صدف</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            1                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a
                                                            href="/area/جنت-آباد-مرکزی/"
                                                            class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">جنت آباد مرکزی</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%78            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۶۰,۰۰۰</span></del>
                                                                              <ins itemprop="price" content="132000"
                                                                                   class="cdbf-netbarg-price"><span>۱۳,۲۰۰</span><span
                                                                                          itemprop="priceCurrency"
                                                                                          content="IRR"> تومان</span></ins></span>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:entertainment/159228/هتل-قصر-خورشید-مشهد-با-اقامت-تک/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159228/1b2e03a5.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159228/1b2e03a5.jpg"
                                                         alt="هتل قصر خورشید مشهد با اقامت تک" data-type="lazy"
                                                         shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159228/1b2e03a5.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159228/1b2e03a5.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:entertainment/159228/هتل-قصر-خورشید-مشهد-با-اقامت-تک/"
                                                                                              class="truncate">هتل قصر
                                                            خورشید مشهد با اقامت تک</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            82                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/شیرودی/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">شیرودی</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%40            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۸۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="480000"
                                                                           class="cdbf-netbarg-price">
                            <span>۴۸,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:entertainment/159168/هتل-آپارتمان-ارمغان-مشهد/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159168/10b50306.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159168/10b50306.jpg"
                                                         alt="هتل آپارتمان ارمغان مشهد" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159168/10b50306.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159168/10b50306.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:entertainment/159168/هتل-آپارتمان-ارمغان-مشهد/"
                                                                                              class="truncate">هتل
                                                            آپارتمان
                                                            ارمغان مشهد</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            329                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/امام-رضا-16/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">امام رضا 16</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%30            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۹۰,۰۰۰</span></del>
                                                                              <ins itemprop="price" content="630000"
                                                                                   class="cdbf-netbarg-price"><span>۶۳,۰۰۰</span><span
                                                                                          itemprop="priceCurrency"
                                                                                          content="IRR"> تومان</span></ins></span>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:entertainment/159218/هتل-آپارتمان-فاخر-مشهد/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159218/113b0318.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159218/113b0318.jpg"
                                                         alt="هتل آپارتمان فاخر مشهد" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159218/113b0318.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159218/113b0318.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:entertainment/159218/هتل-آپارتمان-فاخر-مشهد/"
                                                                                              class="truncate">هتل
                                                            آپارتمان
                                                            فاخر مشهد</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            6                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a
                                                            href="/area/خیابان-امام-رضا/"
                                                            class="cdbf-location truncate"><span
                                                                class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">خیابان امام رضا</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%30            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۱۲۰,۰۰۰</span></del>
                                                                              <ins itemprop="price" content="840000"
                                                                                   class="cdbf-netbarg-price"><span>۸۴,۰۰۰</span><span
                                                                                          itemprop="priceCurrency"
                                                                                          content="IRR"> تومان</span></ins></span>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </article>
                            <div class="app-action">
                                <div class="main-row">
                                    <div class="row">
                                        <article class="main-content col-lg-13 col-md-16 col-sm-19">
                                            <div class="row">
                                                <div class="col-lg-24">
                                                    <h4 class="app-action-header"><span>با اپلیکیشن </span><img
                                                                src="/assets/site/img/app-logo.png" alt="لوگو نت برگ">
                                                    </h4>
                                                    <h2 class="app-action-header-2"><span>جـدیدتـرین&nbsp;</span><span>تـخـفـیـف‌ها&nbsp;</span><span>هـمـیشه در جـیـب شـماسـت!</span>
                                                    </h2>
                                                </div>
                                                <div class="col-lg-24">
                                                    <div class="dl-app-box">
                                                        <div class="links">
                                                            <a href="https://play.google.com/store/apps/details?id=com.IranModernBusinesses.Netbarg&amp;hl=en"
                                                               target="_blank" class="dl-link"><img
                                                                        src="/assets/site/img/dl-gplayer.png"
                                                                        class="icon">
                                                                دانلود از گوگل پلی</a>
                                                            <a href="https://cafebazaar.ir/app/com.IranModernBusinesses.Netbarg/?l=en"
                                                               target="_blank" class="dl-link"><img
                                                                        src="/assets/site/img/dl-bazar.png"
                                                                        class="icon">
                                                                دانلود از بازار</a>
                                                        </div>
                                                    </div>
                                                    <div class="dl-app-box">
                                                        <div class="links">
                                                            <a href="/page/appleStoreDirectLink/" target="_blank"
                                                               class="dl-link">
                                                                <img src="/assets/site/img/dl-ios-white.png"
                                                                     class="icon">
                                                                دانلود مستقیم</a>
                                                            <a href="https://new.sibapp.com/applications/netbarg-نت-برگ"
                                                               target="_blank" class="dl-link">
                                                                <img src="/assets/site/img/dl-sibapp.png" class="icon">
                                                                دانلود از سیپ‌اپ</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </article>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-1"></div>
                        </div>

                        <div class="col-lg-1 col-md-1 hidden-sm hidden-xs left-aside sticky-aside">
                            <div id="nava2" class="affix-top" style="">
                                <div class="float-left-button">
                                    <ul>
                                        <a href="javascript:void(0)">
                                            <li>
                                                <i><i class="icon icon-support"></i></i><span>۰۲۱-۴۱۰۹۶۱۰۰ : پشتیبانی</span>
                                            </li>
                                        </a>
                                        <a href="javascript:void(0)">
                                            <li>
                                                <i><i class="icon icon-home-phone"></i></i><span>۰۲۱-۴۲۰۹۱۰۰۰ : شرکت</span>
                                            </li>
                                        </a>
                                        <a href="/page/buy-netbarg/">
                                            <li>
                                                <i><i class="icon icon-lifebuoy"></i></i><span>راهنمای خرید نت برگ</span>
                                            </li>
                                        </a>
                                        <a href="javascript:void(0)" class="backtotop">
                                            <li><i><i class="icon icon-arrow-up"></i></i></li>
                                        </a>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>






















































































































































    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bitaniki/api/resources/views/page/home.blade.php ENDPATH**/ ?>