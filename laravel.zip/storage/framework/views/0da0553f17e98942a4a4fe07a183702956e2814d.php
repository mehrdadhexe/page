<?php $__env->startSection('content'); ?>
    <main>
        <div class="page-index page-home">
            <div class="wrapper-1">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-1 col-md-1 hidden-sm hidden-xs"></div>

                        <div class="col-lg-3 hidden-md hidden-sm hidden-xs">
                            <nav>
                                <ul class="side-cat" itemscope="" itemtype="http://www.schema.org/SiteNavigationElement">
                                    <li class="li-home"><a href="/tehran/c:todaydeals/"
                                                           style="height: 39.3333px; line-height: 38.3333px;"><i><i
                                                        class="icon icon-logo_e"></i></i><span>نت برگ های امروز</span></a>
                                    </li>


                                    <li class="li-restaurant">

                                        <a itemprop="url" href="/tehran/c:restaurant/" data-toggle="collapse"
                                           data-target="#sub-menu-8" style="height: 39.3333px; line-height: 38.3333px;">

                                            <i>
                                                <i class="icon icon-burger"></i>
                                            </i>
                                            <span itemprop="name">رستوران و فست فود</span>
                                        </a>
                                        <ul class="clearfix step2">
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=31">
                                                <a itemprop="url" href="/tehran/c:traditionalrestaurants/">
                                                    غذای ايرانی و سنتی </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=34">
                                                <a itemprop="url" href="/tehran/c:italianrestaurants/">
                                                    غذای ایتالیایی و ملل </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=37">
                                                <a itemprop="url" href="/tehran/c:fastfood/">
                                                    فست فود </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=40">
                                                <a itemprop="url" href="/tehran/c:sofrekhane/">
                                                    سفره خانه </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=74">
                                                <a itemprop="url" href="/tehran/c:buffet/">
                                                    بوفه </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=75">
                                                <a itemprop="url" href="/tehran/c:coffeeshop/">
                                                    كافی شاپ </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=76">
                                                <a itemprop="url" href="/tehran/c:breakfast/">
                                                    صبحانه </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=433">
                                                <a itemprop="url" href="/tehran/c:catering/">
                                                    کیترینگ </a></li>
                                        </ul>
                                    </li>


                                    <li class="li-entertainment">

                                        <a itemprop="url" href="/tehran/c:entertainment/" data-toggle="collapse"
                                           data-target="#sub-menu-6" style="height: 39.3333px; line-height: 38.3333px;">

                                            <i>
                                                <i class="icon icon-basketball"></i>
                                            </i>
                                            <span itemprop="name">تفریحی و ورزشی</span>
                                        </a>
                                        <ul class="clearfix step2">
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=43">
                                                <a itemprop="url" href="/tehran/c:traveltours/">
                                                    تورهای مسافرتی </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=46">
                                                <a itemprop="url" href="/tehran/c:hotels/">
                                                    هتل و اقامتگاه </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=80">
                                                <a itemprop="url" href="/tehran/c:amusementpark/">
                                                    شهربازی و مراکز تفریحی </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=81">
                                                <a itemprop="url" href="/tehran/c:groupgames/">
                                                    بازی های گروهی و زمین بازی </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=82">
                                                <a itemprop="url" href="/tehran/c:swimmingpool/">
                                                    استخر و ورزش های آبی </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=83">
                                                <a itemprop="url" href="/tehran/c:aerobics/">
                                                    ورزش های هوایی </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=84">
                                                <a itemprop="url" href="/tehran/c:sportclub/">
                                                    باشگاه ورزشی </a></li>
                                        </ul>
                                    </li>


                                    <li class="li-health">

                                        <a itemprop="url" href="/tehran/c:health/" data-toggle="collapse"
                                           data-target="#sub-menu-15" style="height: 39.3333px; line-height: 38.3333px;">

                                            <i>
                                                <i class="icon icon-car-first-aid-kit"></i>
                                            </i>
                                            <span itemprop="name">پزشکی و سلامت</span>
                                        </a>
                                        <ul class="clearfix step2">
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=52">
                                                <a itemprop="url" href="/tehran/c:laser/">
                                                    لیزر موهای زائد </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=92">
                                                <a itemprop="url" href="/tehran/c:botox/">
                                                    ژل و بوتاکس </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=93">
                                                <a itemprop="url" href="/tehran/c:fitness/">
                                                    خدمات تناسب اندام و لاغری </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=94">
                                                <a itemprop="url" href="/tehran/c:massage/">
                                                    ماساژ </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=95">
                                                <a itemprop="url" href="/tehran/c:skinandbeauty/">
                                                    پوست و زیبایی </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=96">
                                                <a itemprop="url" href="/tehran/c:dental/">
                                                    خدمات دندانپزشکی </a></li>
                                        </ul>
                                    </li>


                                    <li class="li-art">

                                        <a itemprop="url" href="/tehran/c:art/" data-toggle="collapse"
                                           data-target="#sub-menu-9" style="height: 39.3333px; line-height: 38.3333px;">

                                            <i>
                                                <i class="icon icon-Theater"></i>
                                            </i>
                                            <span itemprop="name">هنر و تئاتر</span>
                                        </a>
                                        <ul class="clearfix step2">
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=58">
                                                <a itemprop="url" href="/tehran/c:performance/">
                                                    نمایشی و فرهنگی </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=61">
                                                <a itemprop="url" href="/tehran/c:atelier/">
                                                    آتلیه و خدمات چاپ </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=77">
                                                <a itemprop="url" href="/tehran/c:theater/">
                                                    تئاتر </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=78">
                                                <a itemprop="url" href="/tehran/c:concert/">
                                                    کنسرت </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=79">
                                                <a itemprop="url" href="/tehran/c:cinema/">
                                                    سینما </a></li>
                                        </ul>
                                    </li>


                                    <li class="li-education">

                                        <a itemprop="url" href="/tehran/c:education/" data-toggle="collapse"
                                           data-target="#sub-menu-16" style="height: 39.3333px; line-height: 38.3333px;">

                                            <i>
                                                <i class="icon icon-earth-globe"></i>
                                            </i>
                                            <span itemprop="name">آموزشی</span>
                                        </a>
                                        <ul class="clearfix step2">
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=64">
                                                <a itemprop="url" href="/tehran/c:computercourses/">
                                                    کامپیوتر </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=85">
                                                <a itemprop="url" href="/tehran/c:music/">
                                                    موسیقی </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=86">
                                                <a itemprop="url" href="/tehran/c:cooking/">
                                                    آشپزی </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=87">
                                                <a itemprop="url" href="/tehran/c:foreignlanguages/">
                                                    زبان های خارجی </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=88">
                                                <a itemprop="url" href="/tehran/c:conference/">
                                                    گردهمایی و همایش </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=89">
                                                <a itemprop="url" href="/tehran/c:art/">
                                                    هنر </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=90">
                                                <a itemprop="url" href="/tehran/c:accounting/">
                                                    حسابداری </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=91">
                                                <a itemprop="url" href="/tehran/c:skill/">
                                                    مهارت های فردی </a></li>
                                        </ul>
                                    </li>


                                    <li class="li-beauty">

                                        <a itemprop="url" href="/tehran/c:beauty/" data-toggle="collapse"
                                           data-target="#sub-menu-7" style="height: 39.3333px; line-height: 38.3333px;">

                                            <i>
                                                <i class="icon icon-lipstick-with-cover"></i>
                                            </i>
                                            <span itemprop="name">زیبایی و آرایشی</span>
                                        </a>
                                        <ul class="clearfix step2">
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=97">
                                                <a itemprop="url" href="/tehran/c:hairdressing/">
                                                    آرایش مو و صورت </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=98">
                                                <a itemprop="url" href="/tehran/c:nail/">
                                                    خدمات ناخن </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=99">
                                                <a itemprop="url" href="/tehran/c:skin/">
                                                    خدمات پوست </a></li>
                                            <li mj-success="successMegaMenu" class="item2"
                                                mj-target="/Categories/getDescendents?id=100">
                                                <a itemprop="url" href="/tehran/c:waxing/">
                                                    اپیلاسیون </a></li>
                                        </ul>
                                    </li>


                                    <li class="li-product">

                                        <a itemprop="url" href="/tehran/c:product/" data-toggle="collapse"
                                           data-target="#sub-menu-5" style="height: 39.3333px; line-height: 38.3333px;">

                                            <i>
                                                <i class="icon icon-shopping-bag-1"></i>
                                            </i>
                                            <span itemprop="name">کالا</span>
                                        </a>
                                        <ul class="clearfix step2">
                                            <li mj-success="successMegaMenu" class="item2 sc3" mj-type="hover"
                                                mj-target="/Categories/getDescendents?id=107">
                                                <a itemprop="url" href="/tehran/c:product/s:digitaldevices/">
                                                    کالای دیجیتال و لوازم جانبی </a>
                                            </li>
                                            <li mj-success="successMegaMenu" class="item2 sc3" mj-type="hover"
                                                mj-target="/Categories/getDescendents?id=101">
                                                <a itemprop="url" href="/tehran/c:product/s:home/">
                                                    خانه و آشپزخانه </a>
                                            </li>
                                            <li mj-success="successMegaMenu" class="item2 sc3" mj-type="hover"
                                                mj-target="/Categories/getDescendents?id=102">
                                                <a itemprop="url" href="/tehran/c:product/s:healthAndBeauty/">
                                                    آرایشی بهداشتی و پزشکی </a>
                                            </li>
                                            <li mj-success="successMegaMenu" class="item2 sc3" mj-type="hover"
                                                mj-target="/Categories/getDescendents?id=103">
                                                <a itemprop="url" href="/tehran/c:product/s:fashionAndAccessories/">
                                                    مد، پوشاک و اکسسوری </a>
                                            </li>
                                            <li mj-success="successMegaMenu" class="item2 sc3" mj-type="hover"
                                                mj-target="/Categories/getDescendents?id=105">
                                                <a itemprop="url" href="/tehran/c:product/s:juvenile/">
                                                    کودکانه و سرگرمی </a>
                                            </li>
                                            <li mj-success="successMegaMenu" class="item2 sc3" mj-type="hover"
                                                mj-target="/Categories/getDescendents?id=108">
                                                <a itemprop="url" href="/tehran/c:product/s:sports/">
                                                    ورزش و سفر </a>
                                            </li>
                                            <li mj-success="successMegaMenu" class="item2 sc3" mj-type="hover"
                                                mj-target="/Categories/getDescendents?id=106">
                                                <a itemprop="url" href="/tehran/c:product/s:culture/">
                                                    ملزومات اداری و هنر </a>
                                            </li>
                                            <li mj-success="successMegaMenu" class="item2 sc3" mj-type="hover"
                                                mj-target="/Categories/getDescendents?id=110">
                                                <a itemprop="url" href="/tehran/c:product/s:tools/">
                                                    ابزارآلات </a>
                                            </li>
                                            <li mj-success="successMegaMenu" class="item2 sc3" mj-type="hover"
                                                mj-target="/Categories/getDescendents?id=132">
                                                <a itemprop="url" href="/tehran/c:product/s:software/">
                                                    نرم افزار و بازی </a>
                                            </li>
                                        </ul>
                                    </li>


                                    <li class="li-giftcode" itemprop="name">
                                        <a itemprop="url" href="/tehran/c:giftcode/" data-toggle="collapse"
                                           data-target="#sub-menu-504" style="height: 39.3333px; line-height: 38.3333px;">
                                            <i>
                                                <i class="icon icon-couponcodes"></i>
                                            </i>
                                            <span>کد تخفیف</span>
                                        </a>
                                    </li>


                                    <li class="li-vip" itemprop="name">
                                        <a itemprop="url" href="/tehran/c:vip/" data-toggle="collapse"
                                           data-target="#sub-menu-507" style="height: 39.3333px; line-height: 38.3333px;">
                                            <i>
                                                <i class="icon icon-vip"></i>
                                            </i>
                                            <span>پیشنهادات لوکس</span>
                                            <div class="new-item">جدید</div>
                                        </a>
                                    </li>


                                    <li class="li-services" itemprop="name">
                                        <a itemprop="url" href="/tehran/c:services/" data-toggle="collapse"
                                           data-target="#sub-menu-506" style="height: 39.3333px; line-height: 38.3333px;">
                                            <i>
                                                <i class="icon icon-cleaning"></i>
                                            </i>
                                            <span>خدمات</span>
                                        </a>
                                    </li>


                                    <li class="sc li-last" itemprop="name">
                                        <a itemprop="url" href="/tehran/c:last/"
                                           style="height: 39.3333px; line-height: 38.3333px;">
                                            <i>
                                                <i class="icon icon-timer"></i>
                                            </i>
                                            <span>لحظه آخری</span>
                                        </a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                        <div class="col-lg-19 col-md-22">
                            <div class="slider-full clearfix ">
                                <div class="overlay"></div>
                                <div id="carousel_2" data-ride="carousel" class="carousel carousel-2 slide nb-carousel">
                                    <!-- Indicators-->
                                    <!-- <ol class="carousel-indicators">
                                                    <li data-target="#carousel_2" data-slide-to=""
                                            class=" ">
                                            <i class="icon"></i>
                                        </li>
                                            </ol> -->
                                    <!-- Wrapper for slides-->
                                    <div role="listbox" class="carousel-inner">
                                        <div class="item active">
                                            <ul class="deal-tag list-unstyled">
                                            </ul>
                                            <a href="http://netbarg.com/tehran/d/c:entertainment/158240/جشنواره-سرزمین-فکر-بازیا-در-باغ-کتاب/">
                                                <img src="http://static.netbarg.com/img/banner/sliders/vitrin/e9370e74.jpg"
                                                     alt=""> </a>
                                        </div>
                                        <div class="item">
                                            <ul class="deal-tag list-unstyled">
                                            </ul>
                                            <a href="http://netbarg.com/tehran/d/c:entertainment/156549/دلفیناریوم-برج-میلاد-92/">
                                                <img src="http://static.netbarg.com/img/banner/sliders/vitrin/32d910ca.jpg"
                                                     alt=""> </a>
                                        </div>
                                        <div class="item">
                                            <ul class="deal-tag list-unstyled">
                                            </ul>
                                            <a href="http://netbarg.com/trend/%D9%85%D8%AD%D8%A8%D9%88%D8%A8-%D8%AA%D8%B1%DB%8C%D9%86-%D9%BE%DB%8C%D8%B4%D9%86%D9%87%D8%A7%D8%AF%D8%A7%D8%AA-%D8%AA%D8%A6%D8%A7%D8%AA%D8%B1-%DA%A9%D9%85%D8%AF%DB%8C/">
                                                <img src="http://static.netbarg.com/img/banner/sliders/vitrin/dac716a7.jpg"
                                                     alt=""> </a>
                                        </div>
                                        <div class="item">
                                            <ul class="deal-tag list-unstyled">
                                            </ul>
                                            <a href="http://netbarg.com/tehran/c:dental/">
                                                <img src="http://static.netbarg.com/img/banner/sliders/vitrin/0e1610f0.jpg"
                                                     alt=""> </a>
                                        </div>
                                        <div class="item">
                                            <ul class="deal-tag list-unstyled">
                                            </ul>
                                            <a href="http://netbarg.com/tehran/c:foreignlanguages/">
                                                <img src="http://static.netbarg.com/img/banner/sliders/vitrin/ee090f6d.jpg"
                                                     alt=""> </a>
                                        </div>
                                        <div class="item">
                                            <ul class="deal-tag list-unstyled">
                                            </ul>
                                            <a href="http://netbarg.com/tehran/c:breakfast/">
                                                <img src="http://static.netbarg.com/img/banner/sliders/vitrin/81b70ad8.jpg"
                                                     alt=""> </a>
                                        </div>
                                        <div class="item">
                                            <ul class="deal-tag list-unstyled">
                                            </ul>
                                            <a href="http://netbarg.com/tehran/c:product/s:digitaldevices/">
                                                <img src="http://static.netbarg.com/img/banner/sliders/vitrin/106b10ab.jpg"
                                                     alt=""> </a>
                                        </div>
                                        <div class="item">
                                            <ul class="deal-tag list-unstyled">
                                            </ul>
                                            <a href="http://netbarg.com/tehran/c:coffeeshop/">
                                                <img src="http://static.netbarg.com/img/banner/sliders/vitrin/a79f0c99.jpg"
                                                     alt=""> </a>
                                        </div>
                                        <div class="item">
                                            <ul class="deal-tag list-unstyled">
                                            </ul>
                                            <a href="http://netbarg.com/trend/%D8%AA%D9%88%D8%B1-%D8%B7%D8%A8%DB%8C%D8%B9%D8%AA-%DA%AF%D8%B1%D8%AF%DB%8C/">
                                                <img src="http://static.netbarg.com/img/banner/sliders/vitrin/c6c40de9.jpg"
                                                     alt=""> </a>
                                        </div>
                                        <div class="item">
                                            <ul class="deal-tag list-unstyled">
                                            </ul>
                                            <a href="http://netbarg.com/tehran/c:accounting/">
                                                <img src="http://static.netbarg.com/img/banner/sliders/vitrin/a13a1590.jpg"
                                                     alt=""> </a>
                                        </div>
                                        <div class="item">
                                            <ul class="deal-tag list-unstyled">
                                            </ul>
                                            <a href="http://netbarg.com/tehran/c:nail/">
                                                <img src="http://static.netbarg.com/img/banner/sliders/vitrin/4b9407d1.jpg"
                                                     alt=""> </a>
                                        </div>
                                        <div class="item">
                                            <ul class="deal-tag list-unstyled">
                                            </ul>
                                            <a href="http://netbarg.com/tehran/d/c:entertainment/158943/زیپ-لاین-کماندو-77/">
                                                <img src="http://static.netbarg.com/img/banner/sliders/vitrin/a59a1540.jpg"
                                                     alt=""> </a>
                                        </div>
                                        <div class="item">
                                            <ul class="deal-tag list-unstyled">
                                            </ul>
                                            <a href="http://netbarg.com/tehran/d/c:entertainment/158917/جشنواره-تابستانی-سرزمین-عجایب/">
                                                <img src="http://static.netbarg.com/img/banner/sliders/vitrin/69c2131d.jpg"
                                                     alt=""> </a>
                                        </div>
                                        <div class="item">
                                            <ul class="deal-tag list-unstyled">
                                            </ul>
                                            <a href="http://landing.netbarg.com/extra/">
                                                <img src="http://static.netbarg.com/img/banner/sliders/vitrin/456b12c5.jpg"
                                                     alt=""> </a>
                                        </div>
                                    </div>
                                    <!-- Controls--><a href="#carousel_2" role="button" data-slide="prev"
                                                       class="left carousel-control"><span aria-hidden="true"
                                                                                           class="icon icon-arrow-left"></span><span
                                                class="sr-only">Previous</span></a><a href="#carousel_2" role="button"
                                                                                      data-slide="next"
                                                                                      class="right carousel-control"><span
                                                aria-hidden="true" class="icon icon-arrow-right"></span><span
                                                class="sr-only">Next</span></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-1 col-md-1 hidden-sm hidden-xs"></div>
                    </div>
                    <div class="row">
                        <div class="col-lg-1 col-md-1 hidden-sm hidden-xs"></div>
                        <div class="col-lg-22 col-md-22">
                            <div class="row under-slider-banner">
                                <div class="col-lg-8 col-md-8 col-sm-8">
                                    <a target="_blank"
                                       href="http://netbarg.com/trend/%D9%85%DB%8C%DA%A9%D8%B1%D9%88%D8%AF%D8%B1%D9%85/"
                                       class="figure m-b">
                                        <img src="http://static.netbarg.com/img/banner/banners/rightSmallBanner/93/50f40701.jpg"
                                             alt="netbarg"> </a>
                                </div>
                                <div class="col-lg-8 col-md-8 col-sm-8">
                                    <a target="_blank"
                                       href="http://netbarg.com/trend/%D9%87%D8%AA%D9%84-%D9%85%D8%B4%D9%87%D8%AF/"
                                       class="figure m-b">
                                        <img src="http://static.netbarg.com/img/banner/banners/centerSmallBanner/91/59010762.jpg"
                                             alt="netbarg"> </a>
                                </div>
                                <div class="col-lg-8 col-md-8 col-sm-8">
                                    <a target="_blank"
                                       href="http://netbarg.com/trend/%D8%A7%D8%B3%D8%AA%D8%AE%D8%B1%D9%87%D8%A7%DB%8C-%D8%BA%D8%B1%D8%A8-%D8%AA%D9%87%D8%B1%D8%A7%D9%86/"
                                       class="figure m-b">
                                        <img src="http://static.netbarg.com/img/banner/banners/leftSmallBanner/89/47f7068c.jpg"
                                             alt="netbarg"> </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-1 col-md-1 hidden-sm hidden-xs"></div>
                    </div>
                </div>
            </div>
            <div class="wrapper-2">
                <div class="container-fluid">
                    <div class="row h-position">
                        <div class="col-lg-1 col-md-1 hidden-sm hidden-xs right-aside sticky-aside">
                            <div id="nava" class="affix-top" style="">
                                <div class="float-cat">
                                    <ul>
                                        <a href="/tehran/c:todaydeals/" class="float-cat-todaydeal">
                                            <li>
                                                <i><i class="icon icon-logo_e"></i></i><span>نت‌برگ‌های امروز</span>
                                            </li>
                                        </a>

                                        <a href="/tehran/c:restaurant/" class="float-cat-restaurant">
                                            <li>
                                                <i>
                                                    <i class="icon icon-burger"></i>
                                                </i>
                                                <span>رستوران و فست فود</span>
                                            </li>
                                        </a>
                                        <a href="/tehran/c:entertainment/" class="float-cat-entertainment">
                                            <li>
                                                <i>
                                                    <i class="icon icon-basketball"></i>
                                                </i>
                                                <span>تفریحی و ورزشی</span>
                                            </li>
                                        </a>
                                        <a href="/tehran/c:health/" class="float-cat-health">
                                            <li>
                                                <i>
                                                    <i class="icon icon-car-first-aid-kit"></i>
                                                </i>
                                                <span>پزشکی و سلامت</span>
                                            </li>
                                        </a>
                                        <a href="/tehran/c:art/" class="float-cat-art">
                                            <li>
                                                <i>
                                                    <i class="icon icon-Theater"></i>
                                                </i>
                                                <span>هنر و تئاتر</span>
                                            </li>
                                        </a>
                                        <a href="/tehran/c:education/" class="float-cat-education">
                                            <li>
                                                <i>
                                                    <i class="icon icon-earth-globe"></i>
                                                </i>
                                                <span>آموزشی</span>
                                            </li>
                                        </a>
                                        <a href="/tehran/c:beauty/" class="float-cat-beauty">
                                            <li>
                                                <i>
                                                    <i class="icon icon-lipstick-with-cover"></i>
                                                </i>
                                                <span>زیبایی و آرایشی</span>
                                            </li>
                                        </a>
                                        <a href="/tehran/c:product/" class="float-cat-product">
                                            <li>
                                                <i>
                                                    <i class="icon icon-shopping-bag-1"></i>
                                                </i>
                                                <span>کالا</span>
                                            </li>
                                        </a>
                                        <a href="/tehran/c:giftcode/" class="float-cat-giftcode">
                                            <li>
                                                <i>
                                                    <i class="icon icon-couponcodes"></i>
                                                </i>
                                                <span>کد تخفیف</span>
                                            </li>
                                        </a>
                                        <a href="/tehran/c:vip/" class="float-cat-vip">
                                            <li>
                                                <i>
                                                    <i class="icon icon-vip"></i>
                                                </i>
                                                <span>پیشنهادات لوکس</span>
                                            </li>
                                        </a>
                                        <a href="/tehran/c:services/" class="float-cat-services">
                                            <li>
                                                <i>
                                                    <i class="icon icon-cleaning"></i>
                                                </i>
                                                <span>خدمات</span>
                                            </li>
                                        </a>
                                        <a href="/tehran/c:last/" class="float-cat-last">
                                            <li class="sc">
                                                <i>
                                                    <i class="icon icon-timer"></i>
                                                </i>
                                                <span>لحظه آخری</span>
                                            </li>
                                        </a></ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-22 col-md-22 col-sm-24 col-xs-24 padd-0-xs clearfix">
                            <section class="related cat-deal-color main-cat around-me clearfix">
                                <header class="section-header">
                                    <h6 class="hx"><span class="icon icon-special-user-offer"></span><span
                                                class="article-h3">پیشنهادات ویژه نت برگ</span></h6>
                                </header>
                                <div class="main-cat-deal-thumbnail clearfix main-row">
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-6 col-md-12 col-sm-12 col-xs-24 cds-item  ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:entertainment/158240/جشنواره-سرزمین-فکر-بازیا-در-باغ-کتاب/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/158240/21d70411.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/158240/21d70411.jpg"
                                                         alt="جشنواره سرزمین فکر بازیا در باغ کتاب" data-type="lazy"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/158240/21d70411.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title">
                                                        <a href="/tehran/d/c:entertainment/158240/جشنواره-سرزمین-فکر-بازیا-در-باغ-کتاب/"
                                                           itemprop="url" class="truncate">
                                                            جشنواره سرزمین فکر بازیا در باغ کتاب </a>
                                                    </h4>
                                                    <span class="cdbm-total-buy">
                                <span class="ir">
                                    <i class="icon icon-shopping-cart hidden-xs"></i>
                                    <i class="icon icon-shopping-cart_L visible-xs"></i>
                                </span>
                                <span class="cdbm-tb-total">
                                    2387                                </span>
                            </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix">
                                                    <a href="/area/اتوبان حقانی/" class="cdbf-location truncate">
                                <span class="ir">
                                    <i class="icon icon-location74"></i>
                                </span>
                                                        <span class="cdbfl-address">
                                    اتوبان حقانی                                </span>
                                                    </a>
                                                    <span class="cdbf-takhfif">
                                <span class="cdbft-shape">
                                    <span class="cdbft-shape-text">
                                        %60                                    </span>
                                </span>
                            </span>
                                                    <span class="cdbf-price">
                                <ins class="cdbf-netbarg-price">
                                    <span itemprop="price" content="280000">
                                        ۳۶,۰۰۰                                    </span>
                                    <span itemprop="priceCurrency" content="IRR"> تومان</span>
                                </ins>
                            </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-6 col-md-12 col-sm-12 col-xs-24 cds-item  ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:entertainment/156549/دلفیناریوم-برج-میلاد-92/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/156549/1e4c03da.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/156549/1e4c03da.jpg"
                                                         alt="دلفیناریوم برج میلاد" data-type="lazy" class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/156549/1e4c03da.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title">
                                                        <a href="/tehran/d/c:entertainment/156549/دلفیناریوم-برج-میلاد-92/"
                                                           itemprop="url" class="truncate">
                                                            دلفیناریوم برج میلاد </a>
                                                    </h4>
                                                    <span class="cdbm-total-buy">
                                <span class="ir">
                                    <i class="icon icon-shopping-cart hidden-xs"></i>
                                    <i class="icon icon-shopping-cart_L visible-xs"></i>
                                </span>
                                <span class="cdbm-tb-total">
                                    2140                                </span>
                            </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix">
                                                    <a href="/area/برج-میلاد/" class="cdbf-location truncate">
                                <span class="ir">
                                    <i class="icon icon-location74"></i>
                                </span>
                                                        <span class="cdbfl-address">
                                    برج میلاد                                </span>
                                                    </a>
                                                    <span class="cdbf-takhfif">
                                <span class="cdbft-shape">
                                    <span class="cdbft-shape-text">
                                        %63                                    </span>
                                </span>
                            </span>
                                                    <span class="cdbf-price">
                                <ins class="cdbf-netbarg-price">
                                    <span itemprop="price" content="280000">
                                        ۲۲,۲۰۰                                    </span>
                                    <span itemprop="priceCurrency" content="IRR"> تومان</span>
                                </ins>
                            </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-6 col-md-12 col-sm-12 col-xs-24 cds-item  ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:entertainment/158139/دریاچه-شهدای-خلیج-فارس-چیتگر-با-6-بازی-جذاب/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/158139/1e0103dd.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/158139/1e0103dd.jpg"
                                                         alt="دریاچه شهدای خلیج فارس (چیتگر) با 6 بازی جذاب"
                                                         data-type="lazy" class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/158139/1e0103dd.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title">
                                                        <a href="/tehran/d/c:entertainment/158139/دریاچه-شهدای-خلیج-فارس-چیتگر-با-6-بازی-جذاب/"
                                                           itemprop="url" class="truncate">
                                                            دریاچه شهدای خلیج فارس (چیتگر) با 6 بازی جذاب </a>
                                                    </h4>
                                                    <span class="cdbm-total-buy">
                                <span class="ir">
                                    <i class="icon icon-shopping-cart hidden-xs"></i>
                                    <i class="icon icon-shopping-cart_L visible-xs"></i>
                                </span>
                                <span class="cdbm-tb-total">
                                    1081                                </span>
                            </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix">
                                                    <a href="/area/دریاچه-خلیج-فارس/" class="cdbf-location truncate">
                                <span class="ir">
                                    <i class="icon icon-location74"></i>
                                </span>
                                                        <span class="cdbfl-address">
                                    دریاچه خلیج فارس                                </span>
                                                    </a>
                                                    <span class="cdbf-takhfif">
                                <span class="cdbft-shape">
                                    <span class="cdbft-shape-text">
                                        %25                                    </span>
                                </span>
                            </span>
                                                    <span class="cdbf-price">
                                <ins class="cdbf-netbarg-price">
                                    <span itemprop="price" content="280000">
                                        ۷,۵۰۰                                    </span>
                                    <span itemprop="priceCurrency" content="IRR"> تومان</span>
                                </ins>
                            </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-6 col-md-12 col-sm-12 col-xs-24 cds-item  ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:restaurant/159073/ناهار-رستوران-گردان-برج-میلاد/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159073/897.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159073/897.jpg"
                                                         alt="ناهار رستوران گردان برج میلاد" data-type="lazy"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159073/897.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title">
                                                        <a href="/tehran/d/c:restaurant/159073/ناهار-رستوران-گردان-برج-میلاد/"
                                                           itemprop="url" class="truncate">
                                                            ناهار رستوران گردان برج میلاد </a>
                                                    </h4>
                                                    <span class="cdbm-total-buy">
                                <span class="ir">
                                    <i class="icon icon-shopping-cart hidden-xs"></i>
                                    <i class="icon icon-shopping-cart_L visible-xs"></i>
                                </span>
                                <span class="cdbm-tb-total">
                                    35                                </span>
                            </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix">
                                                    <a href="/area/برج-میلاد/" class="cdbf-location truncate">
                                <span class="ir">
                                    <i class="icon icon-location74"></i>
                                </span>
                                                        <span class="cdbfl-address">
                                    برج میلاد                                </span>
                                                    </a>
                                                    <span class="cdbf-takhfif">
                                <span class="cdbft-shape">
                                    <span class="cdbft-shape-text">
                                        %31                                    </span>
                                </span>
                            </span>
                                                    <span class="cdbf-price">
                                <ins class="cdbf-netbarg-price">
                                    <span itemprop="price" content="280000">
                                        ۷۹,۳۵۰                                    </span>
                                    <span itemprop="priceCurrency" content="IRR"> تومان</span>
                                </ins>
                            </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section class="cat-big-small">
                                <article id="float-cat-restaurant" class="cat-deal-color color-rescoffee">
                                    <header class="section-header"><a href="/tehran/c:restaurant/"
                                                                      class="visible-xs">بیشتر</a>
                                        <h3 class="hx"><span class="ir"><i class="icon icon-burger"></i></span><a
                                                    href="/tehran/c:restaurant/" class="article-h3">رستوران و کافی‌شاپ</a>
                                        </h3>
                                    </header>
                                    <div class="main-row clearfix">
                                        <div itemscope="" itemtype="http://schema.org/Offer"
                                             class="col-lg-12 col-md-12 col-sm-24 col-xs-24 cat-deal-bigbox">
                                            <div class="cat-deal-box ">
                                                <a href="/tehran/d/c:restaurant/154389/فودکورت-پل-طبیعت-65/" class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_large/deals/154389/1eab03e1.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <img data-src="http://static.netbarg.com/img/responsive_large/deals/154389/1eab03e1.jpg"
                                                         alt="فودکورت پل طبیعت" data-type="lazy" shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_large/deals/154389/1eab03e1.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_large/deals/154389/1eab03e1.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:restaurant/154389/فودکورت-پل-طبیعت-65/"
                                                                                              class="truncate">فودکورت پل
                                                            طبیعت</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                6948                            </span></span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><span class="cdbf-takhfif"><span
                                                                class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%34</span></span></span><a
                                                            href="/area/ونک/" class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">ونک</span></a><a
                                                            href="/tehran/d/c:restaurant/154389/فودکورت-پل-طبیعت-65/"
                                                            class="cdbf-buy-icon">
                                                        <button class="nb-btn nb-btn-icon nb-btn-success">مشاهده و خرید<i
                                                                    class="icon icon-shopping-cart2"></i></button>
                                                    </a><span class="cdbf-price">
            <del class="cdbf-real-price"><span>۲۵,۰۰۰</span></del><ins class="cdbf-netbarg-price">
            <span itemprop="price" content="165000">۱۶,۵۰۰ </span><span itemprop="priceCurrency"
                                                                        content="IRR"> تومان</span></ins></span></div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-24 col-xs-24 cat-deal-smallbox">
                                            <div class="row">
                                                <div itemscope="" itemtype="http://schema.org/Offer"
                                                     class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                    <div class="cat-deal-box"><a
                                                                href="/tehran/d/c:restaurant/159010/صبحانه-سالم-در-عمارت-خانه-پدری/"
                                                                class="figure"
                                                                style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/159010/1b4f03ab.jpg&quot;); background-size: cover;">
                                                            <ul class="deal-tag list-unstyled">
                                                                <li class="orange-label"></li>
                                                                <li class="violet-label"></li>
                                                            </ul>
                                                            <div class="overlay">
                                                                <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                            </div>
                                                            <img data-src="http://static.netbarg.com/img/responsive_small/deals/159010/1b4f03ab.jpg"
                                                                 alt="صبحانه سالم در عمارت خانه پدری" data-type="lazy"
                                                                 shema="1" itemprop="image"
                                                                 content="http://static.netbarg.com/img/responsive_small/deals/159010/1b4f03ab.jpg"
                                                                 class="sr-only"
                                                                 src="http://static.netbarg.com/img/responsive_small/deals/159010/1b4f03ab.jpg"></a>
                                                        <div class="cat-deal-box-main clearfix">
                                                            <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                                      href="/tehran/d/c:restaurant/159010/صبحانه-سالم-در-عمارت-خانه-پدری/"
                                                                                                      class="truncate">صبحانه
                                                                    سالم در عمارت خانه پدری</a>
                                                            </h4>
                                                            <span class="cdbm-total-buy"><span class="ir"><i
                                                                            class="icon icon-shopping-cart hidden-xs"></i><i
                                                                            class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                        class="cdbm-tb-total">
                                            1094                                        </span></span>
                                                        </div>
                                                        <div class="cat-deal-box-footer clearfix"><a href="/area/هفت-تیر/"
                                                                                                     class="cdbf-location truncate"><span
                                                                        class="ir"><i
                                                                            class="icon icon-location74"></i></span><span
                                                                        class="cdbfl-address">هفت تیر</span></a><span
                                                                    class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                            class="cdbft-shape-text">%45</span></span></span><span
                                                                    class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۱۸,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                            itemprop="price"
                                                                            content="99000">۹,۹۰۰</span><span
                                                                            itemprop="priceCurrency"
                                                                            content="IRR"> تومان</span></ins></span></div>
                                                    </div>
                                                </div>
                                                <div itemscope="" itemtype="http://schema.org/Offer"
                                                     class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                    <div class="cat-deal-box"><a
                                                                href="/tehran/d/c:restaurant/158081/بوفه-آزاد-رستوران-زیتون/"
                                                                class="figure"
                                                                style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/158081/1b5e03ab.jpg&quot;); background-size: cover;">
                                                            <ul class="deal-tag list-unstyled">
                                                                <li class="orange-label"></li>
                                                                <li class="violet-label"></li>
                                                            </ul>
                                                            <div class="overlay">
                                                                <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                            </div>
                                                            <img data-src="http://static.netbarg.com/img/responsive_small/deals/158081/1b5e03ab.jpg"
                                                                 alt="بوفه آزاد رستوران زیتون" data-type="lazy" shema="1"
                                                                 itemprop="image"
                                                                 content="http://static.netbarg.com/img/responsive_small/deals/158081/1b5e03ab.jpg"
                                                                 class="sr-only"
                                                                 src="http://static.netbarg.com/img/responsive_small/deals/158081/1b5e03ab.jpg"></a>
                                                        <div class="cat-deal-box-main clearfix">
                                                            <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                                      href="/tehran/d/c:restaurant/158081/بوفه-آزاد-رستوران-زیتون/"
                                                                                                      class="truncate">بوفه
                                                                    آزاد رستوران زیتون</a>
                                                            </h4>
                                                            <span class="cdbm-total-buy"><span class="ir"><i
                                                                            class="icon icon-shopping-cart hidden-xs"></i><i
                                                                            class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                        class="cdbm-tb-total">
                                            1470                                        </span></span>
                                                        </div>
                                                        <div class="cat-deal-box-footer clearfix"><a href="/area/پارک-وی/"
                                                                                                     class="cdbf-location truncate"><span
                                                                        class="ir"><i
                                                                            class="icon icon-location74"></i></span><span
                                                                        class="cdbfl-address">پارک وی</span></a><span
                                                                    class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                            class="cdbft-shape-text">%50</span></span></span><span
                                                                    class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۱۲۵,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                            itemprop="price"
                                                                            content="625000">۶۲,۵۰۰</span><span
                                                                            itemprop="priceCurrency"
                                                                            content="IRR"> تومان</span></ins></span></div>
                                                    </div>
                                                </div>
                                                <div itemscope="" itemtype="http://schema.org/Offer"
                                                     class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                    <div class="cat-deal-box"><a
                                                                href="/tehran/d/c:restaurant/157579/پیتزا-خوراک-و-برگر-در-رستوران-ایتالیایی-آوا-پلاس/"
                                                                class="figure"
                                                                style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/157579/1ef603e0.jpg&quot;); background-size: cover;">
                                                            <ul class="deal-tag list-unstyled">
                                                                <li class="orange-label"></li>
                                                                <li class="violet-label"></li>
                                                            </ul>
                                                            <div class="overlay">
                                                                <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                            </div>
                                                            <img data-src="http://static.netbarg.com/img/responsive_small/deals/157579/1ef603e0.jpg"
                                                                 alt="پیتزا ، خوراک و برگر در رستوران ایتالیایی آوا پلاس"
                                                                 data-type="lazy" shema="1" itemprop="image"
                                                                 content="http://static.netbarg.com/img/responsive_small/deals/157579/1ef603e0.jpg"
                                                                 class="sr-only"
                                                                 src="http://static.netbarg.com/img/responsive_small/deals/157579/1ef603e0.jpg"></a>
                                                        <div class="cat-deal-box-main clearfix">
                                                            <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                                      href="/tehran/d/c:restaurant/157579/پیتزا-خوراک-و-برگر-در-رستوران-ایتالیایی-آوا-پلاس/"
                                                                                                      class="truncate">پیتزا
                                                                    ، خوراک و برگر در رستوران ایتالیایی آوا پلاس</a>
                                                            </h4>
                                                            <span class="cdbm-total-buy"><span class="ir"><i
                                                                            class="icon icon-shopping-cart hidden-xs"></i><i
                                                                            class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                        class="cdbm-tb-total">
                                            1173                                        </span></span>
                                                        </div>
                                                        <div class="cat-deal-box-footer clearfix"><a href="/area/نیاوران/"
                                                                                                     class="cdbf-location truncate"><span
                                                                        class="ir"><i
                                                                            class="icon icon-location74"></i></span><span
                                                                        class="cdbfl-address">نیاوران</span></a><span
                                                                    class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                            class="cdbft-shape-text">%49</span></span></span><span
                                                                    class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۳۹,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                            itemprop="price"
                                                                            content="198900">۱۹,۸۹۰</span><span
                                                                            itemprop="priceCurrency"
                                                                            content="IRR"> تومان</span></ins></span></div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12 col-md-12 col-sm-24 cds-item hidden-xs done">
                                                    <div class="cds-all-view-box"><span class="ir"><i
                                                                    class="icon icon-burger"></i></span>
                                                        <h4 class="cds-title">113 پیشنهاد رستوران و کافی شاپ</h4>
                                                        <a href="/tehran/c:restaurant/">
                                                            <button class="nb-btn nb-btn-success">مشاهده همه</button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </article>
                                <figure class="figure-ads-baner hidden-xs visible-lg">
                                    <a href="http://netbarg.com/trend/%D8%B3%D9%81%D8%B1%D9%87-%D8%AE%D8%A7%D9%86%D9%87/"
                                       target="_blank">
                                        <img src="http://static.netbarg.com/img/banner/banners/restaurantBanner/77/c6d90dc9.jpg"
                                             alt="رستوران و کافی شاپ"> </a>
                                </figure>
                                <article id="float-cat-entertainment" class="cat-deal-color color-inter-sport">
                                    <header class="section-header"><a href="/tehran/c:entertainment/" class="visible-xs">بیشتر</a>
                                        <h3 class="hx"><span class="ir"><i class="icon icon-basketball"></i></span><a
                                                    href="/tehran/c:entertainment/" class="article-h3">تفریحی و ورزشی</a>
                                        </h3>
                                    </header>
                                    <div class="main-row clearfix">
                                        <div itemscope="" itemtype="http://schema.org/Offer"
                                             class="col-lg-12 col-md-12 col-sm-24 col-xs-24 cat-deal-bigbox">
                                            <div class="cat-deal-box ">
                                                <a href="/tehran/d/c:entertainment/158240/جشنواره-سرزمین-فکر-بازیا-در-باغ-کتاب/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_large/deals/158240/21d70411.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                    </ul>
                                                    <img data-src="http://static.netbarg.com/img/responsive_large/deals/158240/21d70411.jpg"
                                                         alt="جشنواره سرزمین فکر بازیا در باغ کتاب" data-type="lazy"
                                                         shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_large/deals/158240/21d70411.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_large/deals/158240/21d70411.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:entertainment/158240/جشنواره-سرزمین-فکر-بازیا-در-باغ-کتاب/"
                                                                                              class="truncate">جشنواره
                                                            سرزمین فکر بازیا در باغ کتاب</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                2387                            </span></span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><span class="cdbf-takhfif"><span
                                                                class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%60</span></span></span><a
                                                            href="/area/اتوبان حقانی/" class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">اتوبان حقانی</span></a><a
                                                            href="/tehran/d/c:entertainment/158240/جشنواره-سرزمین-فکر-بازیا-در-باغ-کتاب/"
                                                            class="cdbf-buy-icon">
                                                        <button class="nb-btn nb-btn-icon nb-btn-success">مشاهده و خرید<i
                                                                    class="icon icon-shopping-cart2"></i></button>
                                                    </a><span class="cdbf-price">
            <del class="cdbf-real-price"><span>۹۰,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                    itemprop="price">۳۶,۰۰۰</span><span
                                                                    itemprop="priceCurrency"
                                                                    content="IRR"> تومان</span></ins></span></div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-24 col-xs-24 cat-deal-smallbox">
                                            <div class="row">
                                                <div itemscope="" itemtype="http://schema.org/Offer"
                                                     class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                    <div class="cat-deal-box">
                                                        <a href="/tehran/d/c:entertainment/155121/تونل-آکواریوم-انزلی/"
                                                           class="figure"
                                                           style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/155121/1bdc03bb.jpg&quot;); background-size: cover;">
                                                            <ul class="deal-tag list-unstyled">
                                                            </ul>
                                                            <div class="overlay">
                                                                <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                            </div>
                                                            <img data-src="http://static.netbarg.com/img/responsive_small/deals/155121/1bdc03bb.jpg"
                                                                 alt="تونل آکواریوم انزلی" data-type="lazy" shema="1"
                                                                 itemprop="image"
                                                                 content="http://static.netbarg.com/img/responsive_small/deals/155121/1bdc03bb.jpg"
                                                                 class="sr-only"
                                                                 src="http://static.netbarg.com/img/responsive_small/deals/155121/1bdc03bb.jpg"></a>
                                                        <div class="cat-deal-box-main clearfix">
                                                            <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                                      href="/tehran/d/c:entertainment/155121/تونل-آکواریوم-انزلی/"
                                                                                                      class="truncate">تونل
                                                                    آکواریوم انزلی</a>
                                                            </h4>
                                                            <span class="cdbm-total-buy"><span class="ir"><i
                                                                            class="icon icon-shopping-cart hidden-xs"></i><i
                                                                            class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                        class="cdbm-tb-total">
                                            4805                                        </span></span>
                                                        </div>
                                                        <div class="cat-deal-box-footer clearfix"><a
                                                                    href="/area/گیلان-منطقه آزاد انزلی/"
                                                                    class="cdbf-location truncate"><span class="ir"><i
                                                                            class="icon icon-location74"></i></span><span
                                                                        class="cdbfl-address">گیلان-منطقه آزاد انزلی</span></a><span
                                                                    class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                            class="cdbft-shape-text">%40</span></span></span><span
                                                                    class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۶۹,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                            itemprop="price"
                                                                            content="414000">۴۱,۴۰۰</span><span
                                                                            itemprop="priceCurrency"
                                                                            content="IRR"> تومان</span></ins></span></div>
                                                    </div>
                                                </div>
                                                <div itemscope="" itemtype="http://schema.org/Offer"
                                                     class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                    <div class="cat-deal-box">
                                                        <a href="/tehran/d/c:entertainment/153591/شنا-و-آب-درمانی-در-استخر-سپیدار/"
                                                           class="figure"
                                                           style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/153591/1b7203b0.jpg&quot;); background-size: cover;">
                                                            <ul class="deal-tag list-unstyled">
                                                                <li class="orange-label"></li>
                                                                <li class="violet-label"></li>
                                                            </ul>
                                                            <div class="overlay">
                                                                <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                            </div>
                                                            <img data-src="http://static.netbarg.com/img/responsive_small/deals/153591/1b7203b0.jpg"
                                                                 alt="شنا و آب درمانی در استخر سپیدار" data-type="lazy"
                                                                 shema="1" itemprop="image"
                                                                 content="http://static.netbarg.com/img/responsive_small/deals/153591/1b7203b0.jpg"
                                                                 class="sr-only"
                                                                 src="http://static.netbarg.com/img/responsive_small/deals/153591/1b7203b0.jpg"></a>
                                                        <div class="cat-deal-box-main clearfix">
                                                            <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                                      href="/tehran/d/c:entertainment/153591/شنا-و-آب-درمانی-در-استخر-سپیدار/"
                                                                                                      class="truncate">شنا و
                                                                    آب درمانی در استخر سپیدار</a>
                                                            </h4>
                                                            <span class="cdbm-total-buy"><span class="ir"><i
                                                                            class="icon icon-shopping-cart hidden-xs"></i><i
                                                                            class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                        class="cdbm-tb-total">
                                            42156                                        </span></span>
                                                        </div>
                                                        <div class="cat-deal-box-footer clearfix"><a
                                                                    href="/area/میدان-پاستور/"
                                                                    class="cdbf-location truncate"><span class="ir"><i
                                                                            class="icon icon-location74"></i></span><span
                                                                        class="cdbfl-address">میدان پاستور</span></a><span
                                                                    class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                            class="cdbft-shape-text">%35</span></span></span><span
                                                                    class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۴۰,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                            itemprop="price"
                                                                            content="260000">۲۶,۰۰۰</span><span
                                                                            itemprop="priceCurrency"
                                                                            content="IRR"> تومان</span></ins></span></div>
                                                    </div>
                                                </div>
                                                <div itemscope="" itemtype="http://schema.org/Offer"
                                                     class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                    <div class="cat-deal-box">
                                                        <a href="/tehran/d/c:entertainment/156767/تله-سیژ-دربند-گردشی-بر-فراز-طبیعت/"
                                                           class="figure"
                                                           style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/156767/222e0419.jpg&quot;); background-size: cover;">
                                                            <ul class="deal-tag list-unstyled">
                                                                <li class="orange-label"></li>
                                                                <li class="violet-label"></li>
                                                            </ul>
                                                            <div class="overlay">
                                                                <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                            </div>
                                                            <img data-src="http://static.netbarg.com/img/responsive_small/deals/156767/222e0419.jpg"
                                                                 alt="تله سیژ دربند ، گردشی بر فراز طبیعت" data-type="lazy"
                                                                 shema="1" itemprop="image"
                                                                 content="http://static.netbarg.com/img/responsive_small/deals/156767/222e0419.jpg"
                                                                 class="sr-only"
                                                                 src="http://static.netbarg.com/img/responsive_small/deals/156767/222e0419.jpg"></a>
                                                        <div class="cat-deal-box-main clearfix">
                                                            <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                                      href="/tehran/d/c:entertainment/156767/تله-سیژ-دربند-گردشی-بر-فراز-طبیعت/"
                                                                                                      class="truncate">تله
                                                                    سیژ دربند ، گردشی بر فراز طبیعت</a>
                                                            </h4>
                                                            <span class="cdbm-total-buy"><span class="ir"><i
                                                                            class="icon icon-shopping-cart hidden-xs"></i><i
                                                                            class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                        class="cdbm-tb-total">
                                            605                                        </span></span>
                                                        </div>
                                                        <div class="cat-deal-box-footer clearfix"><a href="/area/دربند/"
                                                                                                     class="cdbf-location truncate"><span
                                                                        class="ir"><i
                                                                            class="icon icon-location74"></i></span><span
                                                                        class="cdbfl-address">دربند</span></a><span
                                                                    class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                            class="cdbft-shape-text">%30</span></span></span><span
                                                                    class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۲۵,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                            itemprop="price"
                                                                            content="175000">۱۷,۵۰۰</span><span
                                                                            itemprop="priceCurrency"
                                                                            content="IRR"> تومان</span></ins></span></div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12 col-md-12 col-sm-24 cds-item hidden-xs done">
                                                    <div class="cds-all-view-box"><span class="ir"><i
                                                                    class="icon icon-basketball"></i></span>
                                                        <h4 class="cds-title">197 پیشنهاد تفریحی و ورزشی</h4>
                                                        <a href="/tehran/c:entertainment/">
                                                            <button class="nb-btn nb-btn-success">مشاهده همه</button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </article>
                                <figure class="figure-ads-baner hidden-xs visible-lg">
                                    <a href="http://netbarg.com/trend/%D8%AA%D9%88%D8%B1-%DB%8C%DA%A9-%D8%B1%D9%88%D8%B2%D9%87/"
                                       target="_blank">
                                        <img src="http://static.netbarg.com/img/banner/banners/entertainmentBanner/68/37730672.jpg"
                                             alt="تفریحی و ورزشی"> </a>
                                </figure>
                                <article id="float-cat-health" class="cat-deal-color color-health">
                                    <header class="section-header"><a href="/tehran/c:health/" class="visible-xs">بیشتر</a>
                                        <h3 class="hx"><span class="ir"><i class="icon icon-car-first-aid-kit"></i></span><a
                                                    href="/tehran/c:health/" class="article-h3">پزشکی و سلامت</a>
                                        </h3>
                                    </header>
                                    <div class="main-row clearfix">
                                        <div itemscope="" itemtype="http://schema.org/Offer"
                                             class="col-lg-12 col-md-12 col-sm-24 col-xs-24 cat-deal-bigbox">
                                            <div class="cat-deal-box ">
                                                <a href="/tehran/d/c:health/152604/لیزر-الکساندرایت-در-مطب-دکتر-سعادت-27/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_large/deals/152604/21ca0412.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <img data-src="http://static.netbarg.com/img/responsive_large/deals/152604/21ca0412.jpg"
                                                         alt="لیزر الکساندرایت در مطب دکتر سعادت" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_large/deals/152604/21ca0412.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_large/deals/152604/21ca0412.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:health/152604/لیزر-الکساندرایت-در-مطب-دکتر-سعادت-27/"
                                                                                              class="truncate">لیزر
                                                            الکساندرایت در مطب دکتر سعادت</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                6467                            </span></span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><span class="cdbf-takhfif"><span
                                                                class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%80</span></span></span><a
                                                            href="/area/مترو-شریعتی/" class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">مترو شریعتی</span></a><a
                                                            href="/tehran/d/c:health/152604/لیزر-الکساندرایت-در-مطب-دکتر-سعادت-27/"
                                                            class="cdbf-buy-icon">
                                                        <button class="nb-btn nb-btn-icon nb-btn-success">مشاهده و خرید<i
                                                                    class="icon icon-shopping-cart2"></i></button>
                                                    </a><span class="cdbf-price">
            <del class="cdbf-real-price"><span>۲۰,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                    itemprop="price">۴,۰۰۰</span><span
                                                                    itemprop="priceCurrency"
                                                                    content="IRR"> تومان</span></ins></span></div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-24 col-xs-24 cat-deal-smallbox">
                                            <div class="row">
                                                <div itemscope="" itemtype="http://schema.org/Offer"
                                                     class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                    <div class="cat-deal-box"><a
                                                                href="/tehran/d/c:health/150123/الکساندرایت-در-مطب-دکتر-قنبر-پور-31-95/"
                                                                class="figure"
                                                                style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/150123/34450569.jpg&quot;); background-size: cover;">
                                                            <ul class="deal-tag list-unstyled">
                                                                <li class="orange-label"></li>
                                                                <li class="violet-label"></li>
                                                            </ul>
                                                            <div class="overlay">
                                                                <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                            </div>
                                                            <img data-src="http://static.netbarg.com/img/responsive_small/deals/150123/34450569.jpg"
                                                                 alt="الکساندرایت در مطب دکتر قنبر پور" data-type="lazy"
                                                                 shema="1" itemprop="image"
                                                                 content="http://static.netbarg.com/img/responsive_small/deals/150123/34450569.jpg"
                                                                 class="sr-only"
                                                                 src="http://static.netbarg.com/img/responsive_small/deals/150123/34450569.jpg"></a>
                                                        <div class="cat-deal-box-main clearfix">
                                                            <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                                      href="/tehran/d/c:health/150123/الکساندرایت-در-مطب-دکتر-قنبر-پور-31-95"
                                                                                                      class="truncate">الکساندرایت
                                                                    در مطب دکتر قنبر پور</a>
                                                            </h4>
                                                            <span class="cdbm-total-buy"><span class="ir"><i
                                                                            class="icon icon-shopping-cart hidden-xs"></i><i
                                                                            class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                        class="cdbm-tb-total">
                                            1937                                        </span></span>
                                                        </div>
                                                        <div class="cat-deal-box-footer clearfix"><a
                                                                    href="/area/شهرک-راه-آهن/"
                                                                    class="cdbf-location truncate"><span class="ir"><i
                                                                            class="icon icon-location74"></i></span><span
                                                                        class="cdbfl-address">شهرک راه آهن</span></a><span
                                                                    class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                            class="cdbft-shape-text">%80</span></span></span><span
                                                                    class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۲۰,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                            itemprop="price"
                                                                            content="40000">۴,۰۰۰</span><span
                                                                            itemprop="priceCurrency"
                                                                            content="IRR"> تومان</span></ins></span></div>
                                                    </div>
                                                </div>
                                                <div itemscope="" itemtype="http://schema.org/Offer"
                                                     class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                    <div class="cat-deal-box"><a
                                                                href="/tehran/d/c:health/157542/لیزر-موهای-زائد-الکساندرایت-در-مطب-دکتر-پوراکبری/"
                                                                class="figure"
                                                                style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/157542/1b7903ac.jpg&quot;); background-size: cover;">
                                                            <ul class="deal-tag list-unstyled">
                                                                <li class="orange-label"></li>
                                                                <li class="violet-label"></li>
                                                            </ul>
                                                            <div class="overlay">
                                                                <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                            </div>
                                                            <img data-src="http://static.netbarg.com/img/responsive_small/deals/157542/1b7903ac.jpg"
                                                                 alt="لیزر موهای زائد الکساندرایت در مطب دکتر پوراکبری"
                                                                 data-type="lazy" shema="1" itemprop="image"
                                                                 content="http://static.netbarg.com/img/responsive_small/deals/157542/1b7903ac.jpg"
                                                                 class="sr-only"
                                                                 src="http://static.netbarg.com/img/responsive_small/deals/157542/1b7903ac.jpg"></a>
                                                        <div class="cat-deal-box-main clearfix">
                                                            <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                                      href="/tehran/d/c:health/157542/لیزر-موهای-زائد-الکساندرایت-در-مطب-دکتر-پوراکبری"
                                                                                                      class="truncate">لیزر
                                                                    موهای زائد الکساندرایت در مطب دکتر پوراکبری</a>
                                                            </h4>
                                                            <span class="cdbm-total-buy"><span class="ir"><i
                                                                            class="icon icon-shopping-cart hidden-xs"></i><i
                                                                            class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                        class="cdbm-tb-total">
                                            301                                        </span></span>
                                                        </div>
                                                        <div class="cat-deal-box-footer clearfix"><a href="/area/مرزداران/"
                                                                                                     class="cdbf-location truncate"><span
                                                                        class="ir"><i
                                                                            class="icon icon-location74"></i></span><span
                                                                        class="cdbfl-address">مرزداران</span></a><span
                                                                    class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                            class="cdbft-shape-text">%80</span></span></span><span
                                                                    class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۲۰,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                            itemprop="price"
                                                                            content="40000">۴,۰۰۰</span><span
                                                                            itemprop="priceCurrency"
                                                                            content="IRR"> تومان</span></ins></span></div>
                                                    </div>
                                                </div>
                                                <div itemscope="" itemtype="http://schema.org/Offer"
                                                     class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                    <div class="cat-deal-box"><a
                                                                href="/tehran/d/c:health/149395/لیزر-الکساندرایت-پلاتینیوم-2018-در-مطب-پزشک-17/"
                                                                class="figure"
                                                                style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/149395/1eab03e7.jpg&quot;); background-size: cover;">
                                                            <ul class="deal-tag list-unstyled">
                                                                <li class="orange-label"></li>
                                                                <li class="violet-label"></li>
                                                            </ul>
                                                            <div class="overlay">
                                                                <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                            </div>
                                                            <img data-src="http://static.netbarg.com/img/responsive_small/deals/149395/1eab03e7.jpg"
                                                                 alt="لیزر الکساندرایت پلاتینیوم 2018 در مطب پزشک"
                                                                 data-type="lazy" shema="1" itemprop="image"
                                                                 content="http://static.netbarg.com/img/responsive_small/deals/149395/1eab03e7.jpg"
                                                                 class="sr-only"
                                                                 src="http://static.netbarg.com/img/responsive_small/deals/149395/1eab03e7.jpg"></a>
                                                        <div class="cat-deal-box-main clearfix">
                                                            <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                                      href="/tehran/d/c:health/149395/لیزر-الکساندرایت-پلاتینیوم-2018-در-مطب-پزشک-17"
                                                                                                      class="truncate">لیزر
                                                                    الکساندرایت پلاتینیوم 2018 در مطب پزشک</a>
                                                            </h4>
                                                            <span class="cdbm-total-buy"><span class="ir"><i
                                                                            class="icon icon-shopping-cart hidden-xs"></i><i
                                                                            class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                        class="cdbm-tb-total">
                                            384                                        </span></span>
                                                        </div>
                                                        <div class="cat-deal-box-footer clearfix"><a href="/area/پاسداران/"
                                                                                                     class="cdbf-location truncate"><span
                                                                        class="ir"><i
                                                                            class="icon icon-location74"></i></span><span
                                                                        class="cdbfl-address">پاسداران</span></a><span
                                                                    class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                            class="cdbft-shape-text">%80</span></span></span><span
                                                                    class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۲۰,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                            itemprop="price"
                                                                            content="40000">۴,۰۰۰</span><span
                                                                            itemprop="priceCurrency"
                                                                            content="IRR"> تومان</span></ins></span></div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12 col-md-12 col-sm-24 cds-item hidden-xs done">
                                                    <div class="cds-all-view-box"><span class="ir"><i
                                                                    class="icon icon-car-first-aid-kit"></i></span>
                                                        <h4 class="cds-title">310 پیشنهاد پزشکی و سلامت</h4>
                                                        <a href="/tehran/c:health/">
                                                            <button class="nb-btn nb-btn-success">مشاهده همه</button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </article>
                                <figure class="figure-ads-baner hidden-xs visible-lg">
                                    <a href="http://netbarg.com/trend/%D9%84%DB%8C%D8%B2%D8%B1-%D8%B5%D9%88%D8%B1%D8%AA/"
                                       target="_blank">
                                        <img src="http://static.netbarg.com/img/banner/banners/healthBanner/74/4bc407e1.jpg"
                                             alt="پزشکی و سلامت"> </a>
                                </figure>
                                <article id="float-cat-art" class="cat-deal-color color-art">
                                    <header class="section-header"><a href="/tehran/c:art/" class="visible-xs">بیشتر</a>
                                        <h3 class="hx"><span class="ir"><i class="icon icon-Theater"></i></span><a
                                                    href="/tehran/c:art/" class="article-h3">فرهنگی و هنری</a></h3>
                                    </header>
                                    <div class="main-row clearfix">
                                        <div itemscope="" itemtype="http://schema.org/Offer"
                                             class="col-lg-12 col-md-12 col-sm-24 col-xs-24 cat-deal-bigbox">
                                            <div class="cat-deal-box ">
                                                <a href="/tehran/d/c:art/152484/نمایش-کمدی-موزیکال-و-شاد-فرحزاد-18/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_large/deals/152484/1bb703bc.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                    </ul>
                                                    <img data-src="http://static.netbarg.com/img/responsive_large/deals/152484/1bb703bc.jpg"
                                                         alt="نمایش کمدی، موزیکال و شاد فرحزاد" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_large/deals/152484/1bb703bc.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_large/deals/152484/1bb703bc.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:art/152484/نمایش-کمدی-موزیکال-و-شاد-فرحزاد-18/"
                                                                                              class="truncate">نمایش کمدی،
                                                            موزیکال و شاد فرحزاد</a>
                                                    </h4>

                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                535                            </span></span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><span class="cdbf-takhfif"><span
                                                                class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%50</span></span></span><a
                                                            href="/area/شهرک-اکباتان/" class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">شهرک اکباتان</span></a><a
                                                            href="/tehran/d/c:art/152484/نمایش-کمدی-موزیکال-و-شاد-فرحزاد-18/"
                                                            class="cdbf-buy-icon">
                                                        <button class="nb-btn nb-btn-icon nb-btn-success">مشاهده و خرید<i
                                                                    class="icon icon-shopping-cart2"></i></button>
                                                    </a><span class="cdbf-price">
            <del class="cdbf-real-price"><span>۳۰,۰۰۰</span></del><ins class="cdbf-netbarg-price">
            <span itemprop="price">۱۵,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-24 col-xs-24 cat-deal-smallbox">
                                            <div class="row">
                                                <div itemscope="" itemtype="http://schema.org/Offer"
                                                     class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                    <div class="cat-deal-box"><a
                                                                href="/tehran/d/c:art/158226/نمایش-کمدی-موزیکال-نوستالژی-25/"
                                                                class="figure"
                                                                style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/158226/1e3803dd.jpg&quot;); background-size: cover;">
                                                            <ul class="deal-tag list-unstyled">
                                                                <li class="orange-label"></li>
                                                            </ul>
                                                            <div class="overlay">
                                                                <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                            </div>
                                                            <img data-src="http://static.netbarg.com/img/responsive_small/deals/158226/1e3803dd.jpg"
                                                                 alt="نمایش کمدی موزیکال نوستالژی" data-type="lazy"
                                                                 shema="1" itemprop="image"
                                                                 content="http://static.netbarg.com/img/responsive_small/deals/158226/1e3803dd.jpg"
                                                                 class="sr-only"
                                                                 src="http://static.netbarg.com/img/responsive_small/deals/158226/1e3803dd.jpg">
                                                        </a>

                                                        <div class="cat-deal-box-main clearfix">
                                                            <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                                      href="/tehran/d/c:art/158226/نمایش-کمدی-موزیکال-نوستالژی-25/"
                                                                                                      class="truncate">نمایش
                                                                    کمدی موزیکال نوستالژی</a>
                                                            </h4>
                                                            <span class="cdbm-total-buy"><span class="ir"><i
                                                                            class="icon icon-shopping-cart hidden-xs"></i><i
                                                                            class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                        class="cdbm-tb-total">
                                            669                                        </span></span>
                                                        </div>
                                                        <div class="cat-deal-box-footer clearfix"><a
                                                                    href="/area/خیابان-دماوند/"
                                                                    class="cdbf-location truncate"><span class="ir"><i
                                                                            class="icon icon-location74"></i></span><span
                                                                        class="cdbfl-address">خیابان دماوند</span></a><span
                                                                    class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                            class="cdbft-shape-text">%50</span></span></span><span
                                                                    class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۳۰,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                            itemprop="price"
                                                                            content="150000">۱۵,۰۰۰</span><span
                                                                            itemprop="priceCurrency"
                                                                            content="IRR"> تومان</span></ins></span></div>
                                                    </div>
                                                </div>
                                                <div itemscope="" itemtype="http://schema.org/Offer"
                                                     class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                    <div class="cat-deal-box"><a
                                                                href="/tehran/d/c:art/155598/نمایش-کمدی-موزیکال-تحفه-فرنگ-83/"
                                                                class="figure"
                                                                style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/155598/1873037d.jpg&quot;); background-size: cover;">
                                                            <ul class="deal-tag list-unstyled">
                                                                <li class="orange-label"></li>
                                                            </ul>
                                                            <div class="overlay">
                                                                <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                            </div>
                                                            <img data-src="http://static.netbarg.com/img/responsive_small/deals/155598/1873037d.jpg"
                                                                 alt="نمایش کمدی موزیکال تحفه فرنگ" data-type="lazy"
                                                                 shema="1" itemprop="image"
                                                                 content="http://static.netbarg.com/img/responsive_small/deals/155598/1873037d.jpg"
                                                                 class="sr-only"
                                                                 src="http://static.netbarg.com/img/responsive_small/deals/155598/1873037d.jpg">
                                                        </a>

                                                        <div class="cat-deal-box-main clearfix">
                                                            <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                                      href="/tehran/d/c:art/155598/نمایش-کمدی-موزیکال-تحفه-فرنگ-83/"
                                                                                                      class="truncate">نمایش
                                                                    کمدی موزیکال تحفه فرنگ</a>
                                                            </h4>
                                                            <span class="cdbm-total-buy"><span class="ir"><i
                                                                            class="icon icon-shopping-cart hidden-xs"></i><i
                                                                            class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                        class="cdbm-tb-total">
                                            1322                                        </span></span>
                                                        </div>
                                                        <div class="cat-deal-box-footer clearfix"><a href="/area/تهران-نو/"
                                                                                                     class="cdbf-location truncate"><span
                                                                        class="ir"><i
                                                                            class="icon icon-location74"></i></span><span
                                                                        class="cdbfl-address">تهران نو</span></a><span
                                                                    class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                            class="cdbft-shape-text">%50</span></span></span><span
                                                                    class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۳۰,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                            itemprop="price"
                                                                            content="150000">۱۵,۰۰۰</span><span
                                                                            itemprop="priceCurrency"
                                                                            content="IRR"> تومان</span></ins></span></div>
                                                    </div>
                                                </div>
                                                <div itemscope="" itemtype="http://schema.org/Offer"
                                                     class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                    <div class="cat-deal-box"><a
                                                                href="/tehran/d/c:art/152478/نمایش-شاد-کمدی-موزیکال-دنیای-وارونه-98/"
                                                                class="figure"
                                                                style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/152478/220d040f.jpg&quot;); background-size: cover;">
                                                            <ul class="deal-tag list-unstyled">
                                                            </ul>
                                                            <div class="overlay">
                                                                <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                            </div>
                                                            <img data-src="http://static.netbarg.com/img/responsive_small/deals/152478/220d040f.jpg"
                                                                 alt="نمایش شاد کمدی موزیکال دنیای وارونه" data-type="lazy"
                                                                 shema="1" itemprop="image"
                                                                 content="http://static.netbarg.com/img/responsive_small/deals/152478/220d040f.jpg"
                                                                 class="sr-only"
                                                                 src="http://static.netbarg.com/img/responsive_small/deals/152478/220d040f.jpg">
                                                        </a>

                                                        <div class="cat-deal-box-main clearfix">
                                                            <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                                      href="/tehran/d/c:art/152478/نمایش-شاد-کمدی-موزیکال-دنیای-وارونه-98/"
                                                                                                      class="truncate">نمایش
                                                                    شاد کمدی موزیکال دنیای وارونه</a>
                                                            </h4>
                                                            <span class="cdbm-total-buy"><span class="ir"><i
                                                                            class="icon icon-shopping-cart hidden-xs"></i><i
                                                                            class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                        class="cdbm-tb-total">
                                            452                                        </span></span>
                                                        </div>
                                                        <div class="cat-deal-box-footer clearfix"><a
                                                                    href="/area/شهرک-غرب-فرحزادی/"
                                                                    class="cdbf-location truncate"><span class="ir"><i
                                                                            class="icon icon-location74"></i></span><span
                                                                        class="cdbfl-address">شهرک غرب - فرحزادی</span></a><span
                                                                    class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                            class="cdbft-shape-text">%50</span></span></span><span
                                                                    class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۴۰,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                            itemprop="price"
                                                                            content="200000">۲۰,۰۰۰</span><span
                                                                            itemprop="priceCurrency"
                                                                            content="IRR"> تومان</span></ins></span></div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12 col-md-12 col-sm-24 cds-item hidden-xs done">
                                                    <div class="cds-all-view-box"><span class="ir"><i
                                                                    class="icon icon-Theater"></i></span>
                                                        <h4 class="cds-title">47 پیشنهاد فرهنگی و هنری</h4>
                                                        <a href="/tehran/c:art/">
                                                            <button class="nb-btn nb-btn-success">مشاهده همه</button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </article>
                                <figure class="figure-ads-baner hidden-xs visible-lg">
                                    <a href="http://netbarg.com/trend/%D8%AA%D8%A6%D8%A7%D8%AA%D8%B1-%DA%A9%D9%85%D8%AF%DB%8C//"
                                       target="_blank">
                                        <img src="http://static.netbarg.com/img/banner/banners/artBanner/80/cb5a0e15.jpg"
                                             alt="فرهنگی و هنری"> </a>
                                </figure>
                                <article id="float-cat-education" class="cat-deal-color color-learning">
                                    <header class="section-header"><a href="/tehran/c:education/"
                                                                      class="visible-xs">بیشتر</a>
                                        <h3 class="hx"><span class="ir"><i class="icon icon-earth-globe"></i></span><a
                                                    href="/tehran/c:education/" class="article-h3">آموزشی</a></h3>
                                    </header>
                                    <div class="main-row clearfix">
                                        <div itemscope="" itemtype="http://schema.org/Offer"
                                             class="col-lg-12 col-md-12 col-sm-24 col-xs-24 cat-deal-bigbox">
                                            <div class="cat-deal-box ">
                                                <a href="/tehran/d/c:education/133909/آموزش-عملی-شبکه-بندی-کامپیوتری-در-ایفل-77/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_large/deals/133909/3_2.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                    </ul>
                                                    <img data-src="http://static.netbarg.com/img/responsive_large/deals/133909/3_2.jpg"
                                                         alt="آموزش عملی شبکه بندی کامپیوتری در ایفل" data-type="lazy"
                                                         shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_large/deals/133909/3_2.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_large/deals/133909/3_2.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:education/133909/آموزش-عملی-شبکه-بندی-کامپیوتری-در-ایفل-77/"
                                                                                              class="truncate">آموزش عملی
                                                            شبکه بندی کامپیوتری در ایفل</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                248                            </span></span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><span class="cdbf-takhfif"><span
                                                                class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%90</span></span></span><a
                                                            href="/area/خیابان-کریم-خان-زند/"
                                                            class="cdbf-location truncate"><span class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">خیابان کریم خان زند</span></a><a
                                                            href="/tehran/d/c:education/133909/آموزش-عملی-شبکه-بندی-کامپیوتری-در-ایفل-77/"
                                                            class="cdbf-buy-icon">
                                                        <button class="nb-btn nb-btn-icon nb-btn-success">مشاهده و خرید<i
                                                                    class="icon icon-shopping-cart2"></i></button>
                                                    </a><span class="cdbf-price">
            <del class="cdbf-real-price"><span>۱۵۰,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                    itemprop="price">۱۵,۰۰۰</span><span
                                                                    itemprop="priceCurrency"
                                                                    content="IRR"> تومان</span></ins></span></div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-24 col-xs-24 cat-deal-smallbox">
                                            <div class="row">
                                                <div itemscope="" itemtype="http://schema.org/Offer"
                                                     class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                    <div class="cat-deal-box"><a
                                                                href="/tehran/d/c:education/154529/طراحی-سایت-با-wordpress-در-خواجه-نصیر-45/"
                                                                class="figure"
                                                                style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/154529/65.jpg&quot;); background-size: cover;">
                                                            <ul class="deal-tag list-unstyled">
                                                            </ul>
                                                            <div class="overlay">
                                                                <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                            </div>
                                                            <img data-src="http://static.netbarg.com/img/responsive_small/deals/154529/65.jpg"
                                                                 alt="طراحی سایت با WordPress در خواجه نصیر"
                                                                 data-type="lazy" shema="1" itemprop="image"
                                                                 content="http://static.netbarg.com/img/responsive_small/deals/154529/65.jpg"
                                                                 class="sr-only"
                                                                 src="http://static.netbarg.com/img/responsive_small/deals/154529/65.jpg"></a>
                                                        <div class="cat-deal-box-main clearfix">
                                                            <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                                      href="/tehran/d/c:education/154529/طراحی-سایت-با-wordpress-در-خواجه-نصیر-45/"
                                                                                                      class="truncate">طراحی
                                                                    سایت با WordPress در خواجه نصیر</a>
                                                            </h4>
                                                            <span class="cdbm-total-buy"><span class="ir"><i
                                                                            class="icon icon-shopping-cart hidden-xs"></i><i
                                                                            class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                        class="cdbm-tb-total">
                                            275                                        </span></span>
                                                        </div>
                                                        <div class="cat-deal-box-footer clearfix"><a
                                                                    href="/area/خیابان-شریعتی/"
                                                                    class="cdbf-location truncate"><span class="ir"><i
                                                                            class="icon icon-location74"></i></span><span
                                                                        class="cdbfl-address">خیابان شریعتی</span></a><span
                                                                    class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                            class="cdbft-shape-text">%90</span></span></span><span
                                                                    class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۸۰۰,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                            itemprop="price"
                                                                            content="800000">۸۰,۰۰۰</span><span
                                                                            itemprop="priceCurrency"
                                                                            content="IRR"> تومان</span></ins></span></div>
                                                    </div>
                                                </div>
                                                <div itemscope="" itemtype="http://schema.org/Offer"
                                                     class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                    <div class="cat-deal-box"><a
                                                                href="/tehran/d/c:education/154008/آموزش-نرم-افزار-spss-در-آراد-علم-32/"
                                                                class="figure"
                                                                style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/154008/3777488ab9bceb52dfdb04407db74ad9471092.jpg&quot;); background-size: cover;">
                                                            <ul class="deal-tag list-unstyled">
                                                            </ul>
                                                            <div class="overlay">
                                                                <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                            </div>
                                                            <img data-src="http://static.netbarg.com/img/responsive_small/deals/154008/3777488ab9bceb52dfdb04407db74ad9471092.jpg"
                                                                 alt="آموزش نرم افزار SPSS در آراد علم" data-type="lazy"
                                                                 shema="1" itemprop="image"
                                                                 content="http://static.netbarg.com/img/responsive_small/deals/154008/3777488ab9bceb52dfdb04407db74ad9471092.jpg"
                                                                 class="sr-only"
                                                                 src="http://static.netbarg.com/img/responsive_small/deals/154008/3777488ab9bceb52dfdb04407db74ad9471092.jpg"></a>
                                                        <div class="cat-deal-box-main clearfix">
                                                            <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                                      href="/tehran/d/c:education/154008/آموزش-نرم-افزار-spss-در-آراد-علم-32/"
                                                                                                      class="truncate">آموزش
                                                                    نرم افزار SPSS در آراد علم</a>
                                                            </h4>
                                                            <span class="cdbm-total-buy"><span class="ir"><i
                                                                            class="icon icon-shopping-cart hidden-xs"></i><i
                                                                            class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                        class="cdbm-tb-total">
                                            35                                        </span></span>
                                                        </div>
                                                        <div class="cat-deal-box-footer clearfix"><a
                                                                    href="/area/فرجام-غربی/" class="cdbf-location truncate"><span
                                                                        class="ir"><i
                                                                            class="icon icon-location74"></i></span><span
                                                                        class="cdbfl-address">فرجام غربی</span></a><span
                                                                    class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                            class="cdbft-shape-text">%90</span></span></span><span
                                                                    class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۵۹۰,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                            itemprop="price"
                                                                            content="590000">۵۹,۰۰۰</span><span
                                                                            itemprop="priceCurrency"
                                                                            content="IRR"> تومان</span></ins></span></div>
                                                    </div>
                                                </div>
                                                <div itemscope="" itemtype="http://schema.org/Offer"
                                                     class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                    <div class="cat-deal-box"><a
                                                                href="/tehran/d/c:education/159079/آموزش-نرم-افزار-هلو/"
                                                                class="figure"
                                                                style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/159079/1911038b.jpg&quot;); background-size: cover;">
                                                            <ul class="deal-tag list-unstyled">
                                                            </ul>
                                                            <div class="overlay">
                                                                <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                            </div>
                                                            <img data-src="http://static.netbarg.com/img/responsive_small/deals/159079/1911038b.jpg"
                                                                 alt="آموزش نرم افزار هلو" data-type="lazy" shema="1"
                                                                 itemprop="image"
                                                                 content="http://static.netbarg.com/img/responsive_small/deals/159079/1911038b.jpg"
                                                                 class="sr-only"
                                                                 src="http://static.netbarg.com/img/responsive_small/deals/159079/1911038b.jpg"></a>
                                                        <div class="cat-deal-box-main clearfix">
                                                            <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                                      href="/tehran/d/c:education/159079/آموزش-نرم-افزار-هلو/"
                                                                                                      class="truncate">آموزش
                                                                    نرم افزار هلو</a>
                                                            </h4>
                                                            <span class="cdbm-total-buy"><span class="ir"><i
                                                                            class="icon icon-shopping-cart hidden-xs"></i><i
                                                                            class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                        class="cdbm-tb-total">
                                            2                                        </span></span>
                                                        </div>
                                                        <div class="cat-deal-box-footer clearfix"><a
                                                                    href="/area/میدان-انقلاب/"
                                                                    class="cdbf-location truncate"><span class="ir"><i
                                                                            class="icon icon-location74"></i></span><span
                                                                        class="cdbfl-address">میدان انقلاب</span></a><span
                                                                    class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                            class="cdbft-shape-text">%90</span></span></span><span
                                                                    class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۵۹۰,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                            itemprop="price"
                                                                            content="590000">۵۹,۰۰۰</span><span
                                                                            itemprop="priceCurrency"
                                                                            content="IRR"> تومان</span></ins></span></div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12 col-md-12 col-sm-24 cds-item hidden-xs done">
                                                    <div class="cds-all-view-box"><span class="ir"><i
                                                                    class="icon icon-earth-globe"></i></span>
                                                        <h4 class="cds-title">112 پیشنهاد آموزشی</h4>
                                                        <a href="/tehran/c:education/">
                                                            <button class="nb-btn nb-btn-success">مشاهده همه</button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </article>

                                <figure class="figure-ads-baner hidden-xs visible-lg">
                                    <a href="http://netbarg.com/trend/%D8%A2%D9%85%D9%88%D8%B2%D8%B4-%D9%85%D9%88%D8%B3%DB%8C%D9%82%DB%8C/"
                                       target="_blank">
                                        <img src="http://static.netbarg.com/img/banner/banners/educationalBanner/86/7f3c0ace.jpg"
                                             alt="آموزشی"> </a>
                                </figure>
                                <article id="float-cat-beauty" class="cat-deal-color color-beauty">
                                    <header class="section-header"><a href="/tehran/c:beauty/" class="visible-xs">بیشتر</a>
                                        <h3 class="hx"><span class="ir"><i class="icon icon-lipstick-with-cover"></i></span><a
                                                    href="/tehran/c:beauty/" class="article-h3">زیبایی و آرایشی</a>
                                        </h3>
                                    </header>
                                    <div class="main-row clearfix">
                                        <div itemscope="" itemtype="http://schema.org/Offer"
                                             class="col-lg-12 col-md-12 col-sm-24 col-xs-24 cat-deal-bigbox">
                                            <div class="cat-deal-box ">
                                                <a href="/tehran/d/c:beauty/156708/کاشت-ناخن-و-ترمیم-ناخن-در-آرایشگاه-لی-لی-12/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_large/deals/156708/1ea903dc.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <img data-src="http://static.netbarg.com/img/responsive_large/deals/156708/1ea903dc.jpg"
                                                         alt="کاشت ناخن و ترمیم ناخن در آرایشگاه لی لی" data-type="lazy"
                                                         shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_large/deals/156708/1ea903dc.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_large/deals/156708/1ea903dc.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:beauty/156708/کاشت-ناخن-و-ترمیم-ناخن-در-آرایشگاه-لی-لی-12/"
                                                                                              class="truncate">کاشت ناخن و
                                                            ترمیم ناخن در آرایشگاه لی لی</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                409                            </span></span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><span class="cdbf-takhfif"><span
                                                                class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%80</span></span></span><a
                                                            href="/area/بلوار-فردوس-شرق/"
                                                            class="cdbf-location truncate"><span class="ir"><i
                                                                    class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">بلوار فردوس شرق</span></a><a
                                                            href="/tehran/d/c:beauty/156708/کاشت-ناخن-و-ترمیم-ناخن-در-آرایشگاه-لی-لی-12/"
                                                            class="cdbf-buy-icon">
                                                        <button class="nb-btn nb-btn-icon nb-btn-success">مشاهده و خرید<i
                                                                    class="icon icon-shopping-cart2"></i></button>
                                                    </a><span class="cdbf-price">
            <del class="cdbf-real-price"><span>۷۰,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                    itemprop="price">۱۴,۰۰۰</span><span
                                                                    itemprop="priceCurrency"
                                                                    content="IRR"> تومان</span></ins></span></div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-24 col-xs-24 cat-deal-smallbox">
                                            <div class="row">
                                                <div itemscope="" itemtype="http://schema.org/Offer"
                                                     class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                    <div class="cat-deal-box"><a
                                                                href="/tehran/d/c:beauty/156547/ویتامینه-موی-سر-بانوان-در-آرایشگاه-بهار-زندگی/"
                                                                class="figure"
                                                                style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/156547/1ec803ea.jpg&quot;); background-size: cover;">
                                                            <ul class="deal-tag list-unstyled">
                                                                <li class="orange-label"></li>
                                                                <li class="violet-label"></li>
                                                            </ul>
                                                            <div class="overlay">
                                                                <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                            </div>
                                                            <img data-src="http://static.netbarg.com/img/responsive_small/deals/156547/1ec803ea.jpg"
                                                                 alt="ویتامینه موی سر بانوان در آرایشگاه بهار زندگی"
                                                                 data-type="lazy" shema="1" itemprop="image"
                                                                 content="http://static.netbarg.com/img/responsive_small/deals/156547/1ec803ea.jpg"
                                                                 class="sr-only"
                                                                 src="http://static.netbarg.com/img/responsive_small/deals/156547/1ec803ea.jpg"></a>
                                                        <div class="cat-deal-box-main clearfix">
                                                            <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                                      href="/tehran/d/c:beauty/156547/ویتامینه-موی-سر-بانوان-در-آرایشگاه-بهار-زندگی/"
                                                                                                      class="truncate">ویتامینه
                                                                    موی سر بانوان در آرایشگاه بهار زندگی</a>
                                                            </h4>
                                                            <span class="cdbm-total-buy"><span class="ir"><i
                                                                            class="icon icon-shopping-cart hidden-xs"></i><i
                                                                            class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                        class="cdbm-tb-total">
                                            13                                        </span></span>
                                                        </div>
                                                        <div class="cat-deal-box-footer clearfix"><a
                                                                    href="/area/خیابان-آزادی/"
                                                                    class="cdbf-location truncate"><span class="ir"><i
                                                                            class="icon icon-location74"></i></span><span
                                                                        class="cdbfl-address">خیابان آزادی</span></a><span
                                                                    class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                            class="cdbft-shape-text">%76</span></span></span><span
                                                                    class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۵۰,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                            itemprop="price"
                                                                            content="120000">۱۲,۰۰۰</span><span
                                                                            itemprop="priceCurrency"
                                                                            content="IRR"> تومان</span></ins></span></div>
                                                    </div>
                                                </div>
                                                <div itemscope="" itemtype="http://schema.org/Offer"
                                                     class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                    <div class="cat-deal-box"><a
                                                                href="/tehran/d/c:beauty/151661/لیفت-یا-لمینت-مژه-در-آموزشگاه-بانو-عامری-30/"
                                                                class="figure"
                                                                style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/151661/1c3103bd.jpg&quot;); background-size: cover;">
                                                            <ul class="deal-tag list-unstyled">
                                                                <li class="orange-label"></li>
                                                                <li class="violet-label"></li>
                                                            </ul>
                                                            <div class="overlay">
                                                                <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                            </div>
                                                            <img data-src="http://static.netbarg.com/img/responsive_small/deals/151661/1c3103bd.jpg"
                                                                 alt="لیفت یا لمینت مژه در آموزشگاه بانو عامری"
                                                                 data-type="lazy" shema="1" itemprop="image"
                                                                 content="http://static.netbarg.com/img/responsive_small/deals/151661/1c3103bd.jpg"
                                                                 class="sr-only"
                                                                 src="http://static.netbarg.com/img/responsive_small/deals/151661/1c3103bd.jpg"></a>
                                                        <div class="cat-deal-box-main clearfix">
                                                            <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                                      href="/tehran/d/c:beauty/151661/لیفت-یا-لمینت-مژه-در-آموزشگاه-بانو-عامری-30/"
                                                                                                      class="truncate">لیفت
                                                                    یا لمینت مژه در آموزشگاه بانو عامری</a>
                                                            </h4>
                                                            <span class="cdbm-total-buy"><span class="ir"><i
                                                                            class="icon icon-shopping-cart hidden-xs"></i><i
                                                                            class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                        class="cdbm-tb-total">
                                            48                                        </span></span>
                                                        </div>
                                                        <div class="cat-deal-box-footer clearfix"><a
                                                                    href="/area/پیروزی-متروی ابن سینا/"
                                                                    class="cdbf-location truncate"><span class="ir"><i
                                                                            class="icon icon-location74"></i></span><span
                                                                        class="cdbfl-address">پیروزی-متروی ابن سینا</span></a><span
                                                                    class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                            class="cdbft-shape-text">%88</span></span></span><span
                                                                    class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۳۰۰,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                            itemprop="price"
                                                                            content="360000">۳۶,۰۰۰</span><span
                                                                            itemprop="priceCurrency"
                                                                            content="IRR"> تومان</span></ins></span></div>
                                                    </div>
                                                </div>
                                                <div itemscope="" itemtype="http://schema.org/Offer"
                                                     class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                    <div class="cat-deal-box"><a
                                                                href="/tehran/d/c:beauty/148305/میکروپیگمنتیشن-چشم-در-آرایشگاه-زیباکده-مریم/"
                                                                class="figure"
                                                                style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/148305/1b5103a8.jpg&quot;); background-size: cover;">
                                                            <ul class="deal-tag list-unstyled">
                                                                <li class="violet-label"></li>
                                                            </ul>
                                                            <div class="overlay">
                                                                <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                            </div>
                                                            <img data-src="http://static.netbarg.com/img/responsive_small/deals/148305/1b5103a8.jpg"
                                                                 alt="میکروپیگمنتیشن چشم در آرایشگاه زیباکده مریم"
                                                                 data-type="lazy" shema="1" itemprop="image"
                                                                 content="http://static.netbarg.com/img/responsive_small/deals/148305/1b5103a8.jpg"
                                                                 class="sr-only"
                                                                 src="http://static.netbarg.com/img/responsive_small/deals/148305/1b5103a8.jpg"></a>
                                                        <div class="cat-deal-box-main clearfix">
                                                            <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                                      href="/tehran/d/c:beauty/148305/میکروپیگمنتیشن-چشم-در-آرایشگاه-زیباکده-مریم/"
                                                                                                      class="truncate">میکروپیگمنتیشن
                                                                    چشم در آرایشگاه زیباکده مریم</a>
                                                            </h4>
                                                            <span class="cdbm-total-buy"><span class="ir"><i
                                                                            class="icon icon-shopping-cart hidden-xs"></i><i
                                                                            class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                        class="cdbm-tb-total">
                                            18                                        </span></span>
                                                        </div>
                                                        <div class="cat-deal-box-footer clearfix"><a href="/area/فردوس-شرق/"
                                                                                                     class="cdbf-location truncate"><span
                                                                        class="ir"><i
                                                                            class="icon icon-location74"></i></span><span
                                                                        class="cdbfl-address">فردوس شرق</span></a><span
                                                                    class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                            class="cdbft-shape-text">%84</span></span></span><span
                                                                    class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۳۵۰,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                            itemprop="price"
                                                                            content="560000">۵۶,۰۰۰</span><span
                                                                            itemprop="priceCurrency"
                                                                            content="IRR"> تومان</span></ins></span></div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12 col-md-12 col-sm-24 cds-item hidden-xs done">
                                                    <div class="cds-all-view-box"><span class="ir"><i
                                                                    class="icon icon-lipstick-with-cover"></i></span>
                                                        <h4 class="cds-title">310 پیشنهاد زیبایی و آرایشی</h4>
                                                        <a href="/tehran/c:beauty/">
                                                            <button class="nb-btn nb-btn-success">مشاهده همه</button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </article>
                                <figure class="figure-ads-baner hidden-xs visible-lg">
                                    <a href="http://netbarg.com/trend/%D9%BE%D8%A7%DA%A9%D8%B3%D8%A7%D8%B2%DB%8C-%D9%BE%D9%88%D8%B3%D8%AA/"
                                       target="_blank">
                                        <img src="http://static.netbarg.com/img/banner/banners/beautyBanner/71/f1a40fb5.jpg"
                                             alt="زیبایی و آرایشی"> </a>
                                </figure>
                                <article id="float-cat-product" class="cat-deal-color color-product">
                                    <header class="section-header"><a href="/tehran/c:product/" class="visible-xs">بیشتر</a>
                                        <h3 class="hx"><span class="ir"><i class="icon icon-shopping-bag-1"></i></span><a
                                                    href="/tehran/c:product/" class="article-h3">کالا</a></h3>
                                    </header>
                                    <div class="main-row clearfix">
                                        <div itemscope="" itemtype="http://schema.org/Offer"
                                             class="col-lg-12 col-md-12 col-sm-24 col-xs-24 cat-deal-bigbox">
                                            <div class="cat-deal-box ">
                                                <a href="/tehran/d/c:product/157134/آرام-پز-کنوود-مدل-cp657/" class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_large/deals/157134/188a037a.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                    </ul>
                                                    <img data-src="http://static.netbarg.com/img/responsive_large/deals/157134/188a037a.jpg"
                                                         alt="آرام پز کنوود مدل CP657" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_large/deals/157134/188a037a.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_large/deals/157134/188a037a.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:product/157134/آرام-پز-کنوود-مدل-cp657/"
                                                                                              class="truncate">آرام پز کنوود
                                                            مدل CP657</a>
                                                    </h4>
                                                    <!-- <span class="cdbm-total-buy"><span class="ir"><i class="icon icon-shopping-cart hidden-xs"></i><i
                                            class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                        class="cdbm-tb-total">
                                                                    </span></span> -->
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><span class="cdbf-takhfif"><span
                                                                class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%24</span></span></span><a
                                                            href="/area/ارسال-رایگان/" class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">ارسال رایگان</span></a><a
                                                            href="/tehran/d/c:product/157134/آرام-پز-کنوود-مدل-cp657/"
                                                            class="cdbf-buy-icon">
                                                        <button class="nb-btn nb-btn-icon nb-btn-success">مشاهده و خرید<i
                                                                    class="icon icon-shopping-cart2"></i></button>
                                                    </a><span class="cdbf-price">
            <del class="cdbf-real-price"><span>۱,۰۰۰,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                    itemprop="price">۷۶۰,۰۰۰</span><span
                                                                    itemprop="priceCurrency"
                                                                    content="IRR"> تومان</span></ins></span></div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-24 col-xs-24 cat-deal-smallbox">
                                            <div class="row">
                                                <div itemscope="" itemtype="http://schema.org/Offer"
                                                     class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                    <div class="cat-deal-box"><a
                                                                href="/tehran/d/c:product/154424/ساعت-هوشمند-گارمین-vivomove-sport-32/"
                                                                class="figure"
                                                                style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/154424/18450376.jpg&quot;); background-size: cover;">
                                                            <ul class="deal-tag list-unstyled">
                                                            </ul>
                                                            <div class="overlay">
                                                                <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                            </div>
                                                            <img data-src="http://static.netbarg.com/img/responsive_small/deals/154424/18450376.jpg"
                                                                 alt="ساعت هوشمند گارمین vivomove sport" data-type="lazy"
                                                                 shema="1" itemprop="image"
                                                                 content="http://static.netbarg.com/img/responsive_small/deals/154424/18450376.jpg"
                                                                 class="sr-only"
                                                                 src="http://static.netbarg.com/img/responsive_small/deals/154424/18450376.jpg"></a>
                                                        <div class="cat-deal-box-main clearfix">
                                                            <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                                      href="/tehran/d/c:product/154424/ساعت-هوشمند-گارمین-vivomove-sport-32/"
                                                                                                      class="truncate">ساعت
                                                                    هوشمند گارمین vivomove sport</a>
                                                            </h4>
                                                            <!-- <span class="cdbm-total-buy"><span class="ir"><i
                                        class="icon icon-shopping-cart hidden-xs"></i><i
                                        class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                    class="cdbm-tb-total">
                                                                            </span></span> -->
                                                        </div>
                                                        <div class="cat-deal-box-footer clearfix"><a
                                                                    href="/area/گاندی-جنوبی/"
                                                                    class="cdbf-location truncate"><span class="ir"><i
                                                                            class="icon icon-location74"></i></span><span
                                                                        class="cdbfl-address">گاندی جنوبی </span></a>
                                                            <span class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                            class="cdbft-shape-text">%35</span></span></span><span
                                                                    class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۲,۵۴۰,۰۰۰</span></del><ins
                                                                        class="cdbf-netbarg-price"><span itemprop="price"
                                                                                                         content="25400000">۱,۶۵۱,۰۰۰</span><span
                                                                            itemprop="priceCurrency"
                                                                            content="IRR"> تومان</span></ins></span></div>
                                                    </div>
                                                </div>
                                                <div itemscope="" itemtype="http://schema.org/Offer"
                                                     class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                    <div class="cat-deal-box"><a
                                                                href="/tehran/d/c:product/157183/غذاساز-کنوود-مدل-fpm250/"
                                                                class="figure"
                                                                style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/157183/16280354.jpg&quot;); background-size: cover;">
                                                            <ul class="deal-tag list-unstyled">
                                                            </ul>
                                                            <div class="overlay">
                                                                <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                            </div>
                                                            <img data-src="http://static.netbarg.com/img/responsive_small/deals/157183/16280354.jpg"
                                                                 alt="غذاساز کنوود مدل FPM250" data-type="lazy" shema="1"
                                                                 itemprop="image"
                                                                 content="http://static.netbarg.com/img/responsive_small/deals/157183/16280354.jpg"
                                                                 class="sr-only"
                                                                 src="http://static.netbarg.com/img/responsive_small/deals/157183/16280354.jpg"></a>
                                                        <div class="cat-deal-box-main clearfix">
                                                            <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                                      href="/tehran/d/c:product/157183/غذاساز-کنوود-مدل-fpm250/"
                                                                                                      class="truncate">غذاساز
                                                                    کنوود مدل FPM250</a>
                                                            </h4>
                                                            <!-- <span class="cdbm-total-buy"><span class="ir"><i
                                        class="icon icon-shopping-cart hidden-xs"></i><i
                                        class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                    class="cdbm-tb-total">
                                                                            </span></span> -->
                                                        </div>
                                                        <div class="cat-deal-box-footer clearfix"><a
                                                                    href="/area/ارسال-رایگان/"
                                                                    class="cdbf-location truncate"><span class="ir"><i
                                                                            class="icon icon-location74"></i></span><span
                                                                        class="cdbfl-address">ارسال رایگان</span></a>
                                                            <span class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                            class="cdbft-shape-text">%14</span></span></span><span
                                                                    class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۱,۵۵۰,۰۰۰</span></del><ins
                                                                        class="cdbf-netbarg-price"><span itemprop="price"
                                                                                                         content="15500000">۱,۳۳۳,۰۰۰</span><span
                                                                            itemprop="priceCurrency"
                                                                            content="IRR"> تومان</span></ins></span></div>
                                                    </div>
                                                </div>
                                                <div itemscope="" itemtype="http://schema.org/Offer"
                                                     class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                    <div class="cat-deal-box"><a
                                                                href="/tehran/d/c:product/158040/سشوار-پاناسونیک/"
                                                                class="figure"
                                                                style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/158040/18b4037c.jpg&quot;); background-size: cover;">
                                                            <ul class="deal-tag list-unstyled">
                                                            </ul>
                                                            <div class="overlay">
                                                                <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                            </div>
                                                            <img data-src="http://static.netbarg.com/img/responsive_small/deals/158040/18b4037c.jpg"
                                                                 alt="سشوار پاناسونیک" data-type="lazy" shema="1"
                                                                 itemprop="image"
                                                                 content="http://static.netbarg.com/img/responsive_small/deals/158040/18b4037c.jpg"
                                                                 class="sr-only"
                                                                 src="http://static.netbarg.com/img/responsive_small/deals/158040/18b4037c.jpg"></a>
                                                        <div class="cat-deal-box-main clearfix">
                                                            <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                                      href="/tehran/d/c:product/158040/سشوار-پاناسونیک/"
                                                                                                      class="truncate">سشوار
                                                                    پاناسونیک</a>
                                                            </h4>
                                                            <!-- <span class="cdbm-total-buy"><span class="ir"><i
                                        class="icon icon-shopping-cart hidden-xs"></i><i
                                        class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                    class="cdbm-tb-total">
                                                                            </span></span> -->
                                                        </div>
                                                        <div class="cat-deal-box-footer clearfix"><a
                                                                    href="/area/خیابان-پیروزی/"
                                                                    class="cdbf-location truncate"><span class="ir"><i
                                                                            class="icon icon-location74"></i></span><span
                                                                        class="cdbfl-address">خیابان پیروزی</span></a>
                                                            <span class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                            class="cdbft-shape-text">%34</span></span></span><span
                                                                    class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۲۵۰,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                            itemprop="price"
                                                                            content="2500000">۱۶۵,۰۰۰</span><span
                                                                            itemprop="priceCurrency"
                                                                            content="IRR"> تومان</span></ins></span></div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12 col-md-12 col-sm-24 cds-item hidden-xs done">
                                                    <div class="cds-all-view-box"><span class="ir"><i
                                                                    class="icon icon-shopping-bag-1"></i></span>
                                                        <h4 class="cds-title">106 پیشنهاد کالا</h4>
                                                        <a href="/tehran/c:product/">
                                                            <button class="nb-btn nb-btn-success">مشاهده همه</button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </article>
                                <figure class="figure-ads-baner hidden-xs visible-lg">
                                    <a href="http://netbarg.com/trend/%D8%A2%D9%86%D8%AA%DB%8C-%D9%88%DB%8C%D8%B1%D9%88%D8%B3/"
                                       target="_blank">
                                        <img src="http://static.netbarg.com/img/banner/banners/productBanner/83/e92a0f3c.jpg"
                                             alt="کالا"> </a>
                                </figure>
                            </section>
                            <article class="cat-deal-color main-cat">
                                <header class="section-header today-netbarg">
                                    <h3 class="hx"><span class="icon icon icon-Logo-fill"></span><span class="article-h3">نت‌برگ‌های امروز</span>
                                    </h3><span class="pull-left deals-filter"><span class="clearfix gender-selector">
        </span></span></header>
                                <div class="main-cat-deal-thumbnail clearfix main-row">
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:restaurant/159166/رستوران-بین-المللیvip-با-منو-غذاهای-ایرانی-و-فرنگی/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159166/1b2b03a9.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159166/1b2b03a9.jpg"
                                                         alt="رستوران بین المللیVIP با منو غذاهای ایرانی و فرنگی"
                                                         data-type="lazy" shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159166/1b2b03a9.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159166/1b2b03a9.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:restaurant/159166/رستوران-بین-المللیvip-با-منو-غذاهای-ایرانی-و-فرنگی/"
                                                                                              class="truncate">رستوران بین
                                                            المللیVIP با منو غذاهای ایرانی و فرنگی</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy isempty"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            0                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/شهرک-غرب/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">شهرک غرب</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%33            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۷۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="469000"
                                                                           class="cdbf-netbarg-price">
                            <span>۴۶,۹۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:entertainment/159243/پرواز-با-پاراگلایدر-توسط-خلبان-باقری/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159243/1d4b03ec.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159243/1d4b03ec.jpg"
                                                         alt="پرواز با پاراگلایدر توسط خلبان باقری" data-type="lazy"
                                                         shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159243/1d4b03ec.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159243/1d4b03ec.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:entertainment/159243/پرواز-با-پاراگلایدر-توسط-خلبان-باقری/"
                                                                                              class="truncate">پرواز با
                                                            پاراگلایدر توسط خلبان باقری</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            336                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/بلوار وردآورد/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">بلوار وردآورد</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%40            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۴۵۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="2700000"
                                                                           class="cdbf-netbarg-price">
                            <span>۲۷۰,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:restaurant/156024/بوفه-شام-رستوران-شهربانو-68/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/156024/216d0405.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/156024/216d0405.jpg"
                                                         alt="بوفه شام رستوران شهربانو" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/156024/216d0405.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/156024/216d0405.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:restaurant/156024/بوفه-شام-رستوران-شهربانو-68/"
                                                                                              class="truncate">بوفه شام
                                                            رستوران شهربانو</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            18233                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/شهرک-غرب/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">شهرک غرب</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%40            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۱۳۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="780000"
                                                                           class="cdbf-netbarg-price">
                            <span>۷۸,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:restaurant/159207/پکیج-غذاهای-ایرانی-در-رستوران-هتل-سیمرغ/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159207/36a50571.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159207/36a50571.jpg"
                                                         alt="پکیج غذاهای ایرانی در رستوران هتل سیمرغ" data-type="lazy"
                                                         shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159207/36a50571.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159207/36a50571.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:restaurant/159207/پکیج-غذاهای-ایرانی-در-رستوران-هتل-سیمرغ/"
                                                                                              class="truncate">پکیج غذاهای
                                                            ایرانی در رستوران هتل سیمرغ</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy isempty"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            0                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/ولیعصر-ساعی-1/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">ولیعصر-ساعی</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%25            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۸۹,۳۰۰</span></del>
                                                                              <ins itemprop="price" content="669750"
                                                                                   class="cdbf-netbarg-price"><span>۶۶,۹۷۵</span><span
                                                                                          itemprop="priceCurrency"
                                                                                          content="IRR"> تومان</span></ins></span>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:entertainment/159240/آفرود-در-تهران-با-آفرود-باقری/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159240/22dc042d.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159240/22dc042d.jpg"
                                                         alt="آفرود در تهران با آفرود باقری" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159240/22dc042d.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159240/22dc042d.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:entertainment/159240/آفرود-در-تهران-با-آفرود-باقری/"
                                                                                              class="truncate">آفرود در
                                                            تهران با آفرود باقری</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            30                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/وردآورد/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">وردآورد</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%50            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۲۵۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="1250000"
                                                                           class="cdbf-netbarg-price">
                            <span>۱۲۵,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:restaurant/159200/انواع-سرویس-چای-سنتی-در-سفره-خانه-سنتی-کوهستان/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159200/1bae03b1.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159200/1bae03b1.jpg"
                                                         alt="انواع سرویس چای سنتی در سفره خانه سنتی کوهستان"
                                                         data-type="lazy" shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159200/1bae03b1.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159200/1bae03b1.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:restaurant/159200/انواع-سرویس-چای-سنتی-در-سفره-خانه-سنتی-کوهستان/"
                                                                                              class="truncate">انواع سرویس
                                                            چای سنتی در سفره خانه سنتی کوهستان</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            68                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/خیابان-هنگام/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">خیابان هنگام </span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%55            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۳۵,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="157500"
                                                                           class="cdbf-netbarg-price">
                            <span>۱۵,۷۵۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:beauty/159169/کراتینه-مو-در-آرایشگاه-و-آموزشگاه-سوسن/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159169/1f6703f5.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159169/1f6703f5.jpg"
                                                         alt="کراتینه مو در آرایشگاه و آموزشگاه سوسن" data-type="lazy"
                                                         shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159169/1f6703f5.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159169/1f6703f5.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:beauty/159169/کراتینه-مو-در-آرایشگاه-و-آموزشگاه-سوسن/"
                                                                                              class="truncate">کراتینه مو در
                                                            آرایشگاه و آموزشگاه سوسن</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy isempty"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            0                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/ستاری/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">ستاری</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%70            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۲۸۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="840000"
                                                                           class="cdbf-netbarg-price">
                            <span>۸۴,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:health/159187/تزریق-ژل-در-مطب-دکتر-کیوان/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159187/1f2d03f0.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159187/1f2d03f0.jpg"
                                                         alt="تزریق ژل در مطب دکتر کیوان" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159187/1f2d03f0.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159187/1f2d03f0.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:health/159187/تزریق-ژل-در-مطب-دکتر-کیوان/"
                                                                                              class="truncate">تزریق ژل در
                                                            مطب دکتر کیوان</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy isempty"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            0                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/خیابان-ظفر/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">خیابان ظفر</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%70            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۱۵۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="450000"
                                                                           class="cdbf-netbarg-price">
                            <span>۴۵,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:education/159155/آموزش-زبان-ترکی-استانبولی-در-موسسه-اکسیر/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159155/1f5803f3.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159155/1f5803f3.jpg"
                                                         alt="آموزش زبان ترکی استانبولی در موسسه اکسیر" data-type="lazy"
                                                         shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159155/1f5803f3.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159155/1f5803f3.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:education/159155/آموزش-زبان-ترکی-استانبولی-در-موسسه-اکسیر/"
                                                                                              class="truncate">آموزش زبان
                                                            ترکی استانبولی در موسسه اکسیر</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            1                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/توحید/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">توحید</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%90            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۳۰۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="300000"
                                                                           class="cdbf-netbarg-price">
                            <span>۳۰,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:health/159190/کامپوزیت-دندان-توسط-دکتر-خانچی/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159190/1e5003dd.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159190/1e5003dd.jpg"
                                                         alt="کامپوزیت دندان توسط دکتر خانچی" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159190/1e5003dd.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159190/1e5003dd.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:health/159190/کامپوزیت-دندان-توسط-دکتر-خانچی/"
                                                                                              class="truncate">کامپوزیت
                                                            دندان توسط دکتر خانچی</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            548                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/سعادت-آباد/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">سعادت آباد</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%61            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۵۰۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="1950000"
                                                                           class="cdbf-netbarg-price">
                            <span>۱۹۵,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:education/159175/دوره-های-آموزشی-ویژه-کودکان-در-مهد-کودک-نوید-شادی/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159175/373e0573.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159175/373e0573.jpg"
                                                         alt="دوره های آموزشی ویژه کودکان در مهد کودک نوید شادی"
                                                         data-type="lazy" shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159175/373e0573.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159175/373e0573.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:education/159175/دوره-های-آموزشی-ویژه-کودکان-در-مهد-کودک-نوید-شادی/"
                                                                                              class="truncate">دوره های
                                                            آموزشی ویژه کودکان در مهد کودک نوید شادی</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            1                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/نارمک/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">نارمک</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%90            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۲۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="20000"
                                                                           class="cdbf-netbarg-price">
                            <span>۲,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:health/159196/پلاسما-جت-در-مطب-دکتر-خاکپور/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159196/1e1b03d1.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159196/1e1b03d1.jpg"
                                                         alt="پلاسما جت در مطب دکتر خاکپور" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159196/1e1b03d1.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159196/1e1b03d1.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:health/159196/پلاسما-جت-در-مطب-دکتر-خاکپور/"
                                                                                              class="truncate">پلاسما جت در
                                                            مطب دکتر خاکپور</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy isempty"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            0                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/ولیعصر-پارک-ملت-1/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">ولیعصر- پارک ملت</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%57            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۳۰۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="1290000"
                                                                           class="cdbf-netbarg-price">
                            <span>۱۲۹,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:health/159183/پاکسازی-صورت-و-لیفتینگ-صورت-توسط-دکتر-کلانتری/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159183/18390378.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159183/18390378.jpg"
                                                         alt="پاکسازی صورت و لیفتینگ صورت توسط دکتر کلانتری"
                                                         data-type="lazy" shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159183/18390378.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159183/18390378.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:health/159183/پاکسازی-صورت-و-لیفتینگ-صورت-توسط-دکتر-کلانتری/"
                                                                                              class="truncate">پاکسازی صورت
                                                            و لیفتینگ صورت توسط دکتر کلانتری</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            8                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/ستارخان/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">ستارخان</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%80            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۴۵,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="90000"
                                                                           class="cdbf-netbarg-price">
                            <span>۹,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:entertainment/159235/تور-رفتینگ-زاینده-رود-1-5-روزه-34/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159235/3ca3062b.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159235/3ca3062b.jpg"
                                                         alt="تور رفتینگ زاینده رود 1/5 روزه" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159235/3ca3062b.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159235/3ca3062b.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:entertainment/159235/تور-رفتینگ-زاینده-رود-1-5-روزه-34/"
                                                                                              class="truncate">تور رفتینگ
                                                            زاینده رود 1/5 روزه</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy isempty"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            0                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/تور-گردشگری/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">تور گردشگری</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%32            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۲۸۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="1904000"
                                                                           class="cdbf-netbarg-price">
                            <span>۱۹۰,۴۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:beauty/159164/اپیلاسیون-بدن-در-آرایشگاه-نیکان/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159164/26ce045f.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159164/26ce045f.jpg"
                                                         alt="اپیلاسیون بدن در آرایشگاه نیکان" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159164/26ce045f.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159164/26ce045f.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:beauty/159164/اپیلاسیون-بدن-در-آرایشگاه-نیکان/"
                                                                                              class="truncate">اپیلاسیون بدن
                                                            در آرایشگاه نیکان</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy isempty"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            0                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/نارمك/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">نارمك</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%67            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۲,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="6600"
                                                                           class="cdbf-netbarg-price">
                            <span>۶۶۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:beauty/159177/جوانسازی-پوست-در-آرایشگاه-و-آموزشگاه-سوسن/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159177/1f6703f5.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159177/1f6703f5.jpg"
                                                         alt="جوانسازی پوست در آرایشگاه و آموزشگاه سوسن" data-type="lazy"
                                                         shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159177/1f6703f5.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159177/1f6703f5.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:beauty/159177/جوانسازی-پوست-در-آرایشگاه-و-آموزشگاه-سوسن/"
                                                                                              class="truncate">جوانسازی پوست
                                                            در آرایشگاه و آموزشگاه سوسن</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy isempty"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            0                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/ستاری/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">ستاری</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%75            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۷۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="175000"
                                                                           class="cdbf-netbarg-price">
                            <span>۱۷,۵۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:health/159188/تزریق-بوتاکس-با-دکتر-کیوان/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159188/1b7503ad.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159188/1b7503ad.jpg"
                                                         alt="تزریق بوتاکس با دکتر کیوان" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159188/1b7503ad.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159188/1b7503ad.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:health/159188/تزریق-بوتاکس-با-دکتر-کیوان/"
                                                                                              class="truncate">تزریق بوتاکس
                                                            با دکتر کیوان</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            3                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/خیابان-ظفر/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">خیابان ظفر</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%71            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۱۰۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="290000"
                                                                           class="cdbf-netbarg-price">
                            <span>۲۹,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:art/159165/ثبت-خاطرات-به-یادماندنی-در-آتلیه-رویال-آس/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159165/1b4003a9.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159165/1b4003a9.jpg"
                                                         alt="ثبت خاطرات به یادماندنی در آتلیه رویال آس" data-type="lazy"
                                                         shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159165/1b4003a9.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159165/1b4003a9.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:art/159165/ثبت-خاطرات-به-یادماندنی-در-آتلیه-رویال-آس/"
                                                                                              class="truncate">ثبت خاطرات به
                                                            یادماندنی در آتلیه رویال آس</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            66                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a
                                                            href="/area/فلکه-اول-تهرانپارس/" class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">فلکه اول تهرانپارس</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%85            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۳۵,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="52500"
                                                                           class="cdbf-netbarg-price">
                            <span>۵,۲۵۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:health/159193/میکرونیدلینگ-پوست-توسط-دکتر-خدامی/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159193/1c2b03bf.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159193/1c2b03bf.jpg"
                                                         alt="میکرونیدلینگ پوست توسط دکتر خدامی" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159193/1c2b03bf.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159193/1c2b03bf.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:health/159193/میکرونیدلینگ-پوست-توسط-دکتر-خدامی/"
                                                                                              class="truncate">میکرونیدلینگ
                                                            پوست توسط دکتر خدامی</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy isempty"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            0                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/مترو-شریعتی/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">مترو شریعتی</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%87            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۱۵۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="195000"
                                                                           class="cdbf-netbarg-price">
                            <span>۱۹,۵۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:health/159180/میکرودرم-در-مطب-دکتر-ملکیاری/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159180/1ed803e9.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159180/1ed803e9.jpg"
                                                         alt="میکرودرم در مطب دکتر ملکیاری" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159180/1ed803e9.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159180/1ed803e9.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:health/159180/میکرودرم-در-مطب-دکتر-ملکیاری/"
                                                                                              class="truncate">میکرودرم در
                                                            مطب دکتر ملکیاری</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            2                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/روبروی مترو قلهک/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">روبروی مترو قلهک</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%91            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۸۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="72000"
                                                                           class="cdbf-netbarg-price">
                            <span>۷,۲۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:health/159184/تقویت-و-آبرسانی-مو-توسط-دکتر-کلانتری/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159184/4.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159184/4.jpg"
                                                         alt="تقویت و آبرسانی مو توسط دکتر کلانتری" data-type="lazy"
                                                         shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159184/4.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159184/4.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:health/159184/تقویت-و-آبرسانی-مو-توسط-دکتر-کلانتری/"
                                                                                              class="truncate">تقویت و
                                                            آبرسانی مو توسط دکتر کلانتری</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            8                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/ستارخان/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">ستارخان</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%80            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۴۵,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="90000"
                                                                           class="cdbf-netbarg-price">
                            <span>۹,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:entertainment/159231/تور-آبشار-دارنو-جنگل-فراخین-و-ساحل-نوشهر-یکروزه/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159231/33d5058d.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159231/33d5058d.jpg"
                                                         alt="تور آبشار دارنو ، جنگل فراخین و ساحل نوشهر یکروزه"
                                                         data-type="lazy" shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159231/33d5058d.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159231/33d5058d.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:entertainment/159231/تور-آبشار-دارنو-جنگل-فراخین-و-ساحل-نوشهر-یکروزه/"
                                                                                              class="truncate">تور آبشار
                                                            دارنو ، جنگل فراخین و ساحل نوشهر یکروزه</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy isempty"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            0                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/تور-گردشگری/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">تور گردشگری</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%23            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۸۵,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="654500"
                                                                           class="cdbf-netbarg-price">
                            <span>۶۵,۴۵۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:health/159152/لیزر-موهای-زائد-الکساندرایت-در-مطب-دکتر-خدامی/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159152/1c2403c0.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159152/1c2403c0.jpg"
                                                         alt="لیزر موهای زائد الکساندرایت در مطب دکتر خدامی"
                                                         data-type="lazy" shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159152/1c2403c0.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159152/1c2403c0.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:health/159152/لیزر-موهای-زائد-الکساندرایت-در-مطب-دکتر-خدامی/"
                                                                                              class="truncate">لیزر موهای
                                                            زائد الکساندرایت در مطب دکتر خدامی</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy isempty"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            0                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/مترو-شریعتی/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">مترو شریعتی</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%80            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۲۰,۰۰۰</span></del>
                                                                              <ins itemprop="price" content="40000"
                                                                                   class="cdbf-netbarg-price"><span>۴,۰۰۰</span><span
                                                                                          itemprop="priceCurrency"
                                                                                          content="IRR"> تومان</span></ins></span>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:beauty/159239/کاشت-ناخن-و-ترمیم-ناخن-در-آرایشگاه-صدف/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159239/1b5803ad.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                        <li class="violet-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159239/1b5803ad.jpg"
                                                         alt="کاشت ناخن و ترمیم ناخن در آرایشگاه صدف" data-type="lazy"
                                                         shema="1" itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159239/1b5803ad.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159239/1b5803ad.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:beauty/159239/کاشت-ناخن-و-ترمیم-ناخن-در-آرایشگاه-صدف/"
                                                                                              class="truncate">کاشت ناخن و
                                                            ترمیم ناخن در آرایشگاه صدف</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            1                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/جنت-آباد-مرکزی/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">جنت آباد مرکزی</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%78            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۶۰,۰۰۰</span></del>
                                                                              <ins itemprop="price" content="132000"
                                                                                   class="cdbf-netbarg-price"><span>۱۳,۲۰۰</span><span
                                                                                          itemprop="priceCurrency"
                                                                                          content="IRR"> تومان</span></ins></span>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:entertainment/159228/هتل-قصر-خورشید-مشهد-با-اقامت-تک/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159228/1b2e03a5.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159228/1b2e03a5.jpg"
                                                         alt="هتل قصر خورشید مشهد با اقامت تک" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159228/1b2e03a5.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159228/1b2e03a5.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:entertainment/159228/هتل-قصر-خورشید-مشهد-با-اقامت-تک/"
                                                                                              class="truncate">هتل قصر
                                                            خورشید مشهد با اقامت تک</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            82                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/شیرودی/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">شیرودی</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%40            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۸۰,۰۰۰</span></del>
                                                                      <ins itemprop="price" content="480000"
                                                                           class="cdbf-netbarg-price">
                            <span>۴۸,۰۰۰</span><span itemprop="priceCurrency" content="IRR"> تومان</span></ins>
                        </span></div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:entertainment/159168/هتل-آپارتمان-ارمغان-مشهد/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159168/10b50306.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159168/10b50306.jpg"
                                                         alt="هتل آپارتمان ارمغان مشهد" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159168/10b50306.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159168/10b50306.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:entertainment/159168/هتل-آپارتمان-ارمغان-مشهد/"
                                                                                              class="truncate">هتل آپارتمان
                                                            ارمغان مشهد</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            329                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/امام-رضا-16/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">امام رضا 16</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%30            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۹۰,۰۰۰</span></del>
                                                                              <ins itemprop="price" content="630000"
                                                                                   class="cdbf-netbarg-price"><span>۶۳,۰۰۰</span><span
                                                                                          itemprop="priceCurrency"
                                                                                          content="IRR"> تومان</span></ins></span>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <div itemscope="" itemtype="http://schema.org/Offer"
                                         class="col-lg-8 col-md-12 col-sm-12 col-xs-24 cds-item ">
                                        <div class="cat-deal-smallbox">
                                            <div class="cat-deal-box">
                                                <a href="/tehran/d/c:entertainment/159218/هتل-آپارتمان-فاخر-مشهد/"
                                                   class="figure"
                                                   style="background-image: url(&quot;http://static.netbarg.com/img/responsive_medium/deals/159218/113b0318.jpg&quot;); background-size: cover;">
                                                    <ul class="deal-tag list-unstyled">
                                                        <li class="orange-label"></li>
                                                    </ul>
                                                    <div class="overlay">
                                                        <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                    </div>
                                                    <img data-src="http://static.netbarg.com/img/responsive_medium/deals/159218/113b0318.jpg"
                                                         alt="هتل آپارتمان فاخر مشهد" data-type="lazy" shema="1"
                                                         itemprop="image"
                                                         content="http://static.netbarg.com/img/responsive_medium/deals/159218/113b0318.jpg"
                                                         class="sr-only"
                                                         src="http://static.netbarg.com/img/responsive_medium/deals/159218/113b0318.jpg">
                                                </a>
                                                <div class="cat-deal-box-main clearfix">
                                                    <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                              href="/tehran/d/c:entertainment/159218/هتل-آپارتمان-فاخر-مشهد/"
                                                                                              class="truncate">هتل آپارتمان
                                                            فاخر مشهد</a>
                                                    </h4>
                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                class="cdbm-tb-total">
                                            6                                        </span>
                                    </span>
                                                </div>
                                                <div class="cat-deal-box-footer clearfix"><a href="/area/خیابان-امام-رضا/"
                                                                                             class="cdbf-location truncate"><span
                                                                class="ir"><i class="icon icon-location74"></i></span><span
                                                                class="cdbfl-address">خیابان امام رضا</span></a><span
                                                            class="cdbf-takhfif"><span class="cdbft-shape"><span
                                                                    class="cdbft-shape-text">%30            </span></span></span><span
                                                            class="cdbf-price">
                                <del class="cdbf-real-price"> <span>۱۲۰,۰۰۰</span></del>
                                                                              <ins itemprop="price" content="840000"
                                                                                   class="cdbf-netbarg-price"><span>۸۴,۰۰۰</span><span
                                                                                          itemprop="priceCurrency"
                                                                                          content="IRR"> تومان</span></ins></span>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </article>
                            <div class="app-action">
                                <div class="main-row">
                                    <div class="row">
                                        <article class="main-content col-lg-13 col-md-16 col-sm-19">
                                            <div class="row">
                                                <div class="col-lg-24">
                                                    <h4 class="app-action-header"><span>با اپلیکیشن </span><img
                                                                src="/assets/site/img/app-logo.png" alt="لوگو نت برگ"></h4>
                                                    <h2 class="app-action-header-2"><span>جـدیدتـرین&nbsp;</span><span>تـخـفـیـف‌ها&nbsp;</span><span>هـمـیشه در جـیـب شـماسـت!</span>
                                                    </h2>
                                                </div>
                                                <div class="col-lg-24">
                                                    <div class="dl-app-box">
                                                        <div class="links">
                                                            <a href="https://play.google.com/store/apps/details?id=com.IranModernBusinesses.Netbarg&amp;hl=en"
                                                               target="_blank" class="dl-link"><img
                                                                        src="/assets/site/img/dl-gplayer.png" class="icon">
                                                                دانلود از گوگل پلی</a>
                                                            <a href="https://cafebazaar.ir/app/com.IranModernBusinesses.Netbarg/?l=en"
                                                               target="_blank" class="dl-link"><img
                                                                        src="/assets/site/img/dl-bazar.png" class="icon">
                                                                دانلود از بازار</a>
                                                        </div>
                                                    </div>
                                                    <div class="dl-app-box">
                                                        <div class="links">
                                                            <a href="/page/appleStoreDirectLink/" target="_blank"
                                                               class="dl-link">
                                                                <img src="/assets/site/img/dl-ios-white.png" class="icon">
                                                                دانلود مستقیم</a>
                                                            <a href="https://new.sibapp.com/applications/netbarg-نت-برگ"
                                                               target="_blank" class="dl-link">
                                                                <img src="/assets/site/img/dl-sibapp.png" class="icon">
                                                                دانلود از سیپ‌اپ</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </article>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-1"></div>
                        </div>
                        <div class="col-lg-1 col-md-1 hidden-sm hidden-xs left-aside sticky-aside">
                            <div id="nava2" class="affix-top" style="">
                                <div class="float-left-button">
                                    <ul>
                                        <a href="javascript:void(0)">
                                            <li><i><i class="icon icon-support"></i></i><span>۰۲۱-۴۱۰۹۶۱۰۰ : پشتیبانی</span>
                                            </li>
                                        </a>
                                        <a href="javascript:void(0)">
                                            <li><i><i class="icon icon-home-phone"></i></i><span>۰۲۱-۴۲۰۹۱۰۰۰ : شرکت</span>
                                            </li>
                                        </a>
                                        <a href="/page/buy-netbarg/">
                                            <li><i><i class="icon icon-lifebuoy"></i></i><span>راهنمای خرید نت برگ</span>
                                            </li>
                                        </a>
                                        <a href="javascript:void(0)" class="backtotop">
                                            <li><i><i class="icon icon-arrow-up"></i></i></li>
                                        </a>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="subscriptionModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
             class="modal nb-modal-subscribe fade" style="display: none;">
            <div role="document" class="Discount-modal-box">
                <div class="Discount-modal-body">
                    <div class="Discount-form">
                        <div class="close-Discount-modal">
                            <button type="button" data-dismiss="modal" aria-label="Close" class="close"><i
                                        aria-hidden="true" class="icon icon-close"></i></button>
                        </div>
                        <form method="post" accept-charset="utf-8" class="search-input" mj-type="form"
                              mj-target="/subscriptions/subscribeEmail.json" mj-method="post" mj-success="subscribeEmail"
                              action="/">
                            <div style="display:none;"><input type="hidden" name="_method" value="POST"></div>
                            <div class="title-form">برای اطلاع از تخفیفهای روزانه ایمیل خود را وارد کنید</div>
                            <input name="email" type="email" placeholder="ایمیل خود را وارد کنید" class="form-item">
                            <div class="dropdown form-item">
                                <button type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                                        class="btn btn-default dropdown-toggle"><span id="city-name">تهران</span><i
                                            class="icon icon-arrow-down"></i></button>
                                <div class="dropdown-menu">
                                    <ul>
                                        <li><span data-id="42598">اراک</span></li>
                                        <li><span data-id="42575">اردبیل</span></li>
                                        <li><span data-id="42574">ارومیه</span></li>
                                        <li><span data-id="42576">اصفهان</span></li>
                                        <li><span data-id="42583">اهواز</span></li>
                                        <li><span data-id="42577">ایلام</span></li>
                                        <li><span data-id="42582">بجنورد</span></li>
                                        <li><span data-id="42578">بندر بوشهر</span></li>
                                        <li><span data-id="42599">بندرعباس</span></li>
                                        <li><span data-id="42580">بیرجند</span></li>
                                        <li><span data-id="42573">تبریز</span></li>
                                        <li><span data-id="42546">تهران</span></li>
                                        <li><span data-id="42596">خرم‌آباد</span></li>
                                        <li><span data-id="42595">رشت</span></li>
                                        <li><span data-id="42586">زاهدان</span></li>
                                        <li><span data-id="42584">زنجان</span></li>
                                        <li><span data-id="42597">ساری</span></li>
                                        <li><span data-id="42585">سمنان</span></li>
                                        <li><span data-id="42590">سنندج</span></li>
                                        <li><span data-id="42747">شهرهای شمالی</span></li>
                                        <li><span data-id="42579">شهرکرد</span></li>
                                        <li><span data-id="42587">شیراز</span></li>
                                        <li><span data-id="42588">قزوین</span></li>
                                        <li><span data-id="42589">قم</span></li>
                                        <li><span data-id="42581">مشهد</span></li>
                                        <li><span data-id="42600">همدان</span></li>
                                        <li><span data-id="42602">کرج</span></li>
                                        <li><span data-id="42591">کرمان</span></li>
                                        <li><span data-id="42592">کرمانشاه</span></li>
                                        <li><span data-id="42745">کیش</span></li>
                                        <li><span data-id="42594">گرگان</span></li>
                                        <li><span data-id="42593">یاسوج</span></li>
                                        <li><span data-id="42601">یزد</span></li>
                                    </ul>
                                </div>
                                <input type="hidden" name="city_id" id="selectCityId" value="42546">
                            </div>
                            <button type="submit" class="btn btn-warning btn-type-1">ارسال</button>
                        </form>
                        <div class="netbarg_logo"><img src="/assets/site/img/white-logo_subscription.png" alt=""></div>
                        <div class="percent-pic entertainment"><span class="num"> <span
                                        class="symbol">%</span>60</span><span class="text">تخفیف</span></div>
                        <a target="_blank"
                           href="/tehran/d/c:entertainment/158240/جشنواره-سرزمین-فکر-بازیا-در-باغ-کتاب/?utm_source=home&amp;utm_medium=banner&amp;utm_campaign=modal"
                           class="Discount-img">
                            <img src="http://static.netbarg.com/img/responsive_large/deals/158240/21d70411.jpg"
                                 alt="جشنواره سرزمین فکر بازیا در باغ کتاب">
                            <div class="on-iamge">
                                <div class="cat-title">مجموعه</div>
                                <div class="merchant-name">فکربازیا</div>
                                <button class="nb-btn nb-btn-success">مشاهده</button>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="rate-notif desktop-notif">
            <div class="main-row"><span class="border-effect"></span>
                <div class="box-notif">
                    <div class="circle-deal " id="rating-deal-img">

                    </div>
                    <div class="content-part">
                        <div class="text1"></div>
                        <div class="emoji_box">
                            <ul class="list-inline list-unstyled emoji-ratings">
                                <li>
                                    <div mj-type="single" rate-value="5" class="rating-box happy"
                                         mj-success="successNewRating"><i aria-hidden="true"
                                                                          class="icon icon-happy-face"></i>
                                        <p>راضی</p>
                                    </div>
                                </li>
                                <li>
                                    <div mj-type="single" rate-value="3" class="rating-box neutral"
                                         mj-success="successNewRating"><i aria-hidden="true"
                                                                          class="icon icon-normal-face"></i>
                                        <p>متوسط</p>
                                    </div>
                                </li>
                                <li>
                                    <div mj-type="single" rate-value="1" class="rating-box sad"
                                         mj-success="successNewRating"><i aria-hidden="true" class="icon icon-sad-face"></i>
                                        <p>ناراضی</p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="close-icon"><i class="icon icon-close"></i></div>
                    </div>
                </div>
                <div class="box-comment">
                    <form method="post" accept-charset="utf-8" mj-type="form" mj-model="model2" mj-method="post"
                          mj-success="successGiftCardNotification" mj-target="/rating/ratings/ratingProcess.json"
                          mj-before="checkRating"
                    =""="" action="/">
                    <div style="display:none;"><input type="hidden" name="_method" value="POST"></div>
                    <input type="hidden" name="rate" id="rate-value"><input type="hidden" name="notification"
                                                                            id="notification" value="1"><input type="hidden"
                                                                                                               name="deal_user_id"
                                                                                                               id="deal-user-id"
                                                                                                               value=""><input
                            type="hidden" name="user_id" id="user-id" value="d41d8cd98f00b204e9800998ecf8427e">
                    <div class="input textarea"><textarea name="opinion" placeholder="با ثبت نظر کد تخفیف بگیرید" class=""
                                                          id="opinion" rows="2"></textarea></div>
                    <button type="submit" class="nb-btn nb-btn-sm nb-btn-success btn-green">ثبت نظر</button>
                    </form>       </div>
                <div class="box-off-code active c-rotate1">
                    <div class="part3">
                        <div class="circle-off">
                            <div class="percent-num">%<span id="percent-num-notif"></span></div>
                            <div class="text">تخفیف</div>
                        </div>
                        <div class="content_part2">
                            <div class="text" id="percent-text-notif"></div>
                            <div class="code-part">کد تخفیف :<span class="num gift-rating-notification"></span></div>
                            <a href="/user/userProfiles/index#tab3" class="nb-btn nb-btn-sm nb-btn-rate">خریدهای من </a>
                            <div class="close-icon"><i class="icon icon-close"></i></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xamppp7\htdocs\laravel\resources\views/page/home.blade.php ENDPATH**/ ?>