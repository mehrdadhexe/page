<?php

namespace App\Http\Controllers;

use App\SMS;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Session;


class UserController extends Controller
{
    public $sms;

    public function __construct()
    {
        $this->sms = new SMS();

    }
    public function tab1()
    {

        $userID=Auth::user()->id;
        $user=User::find($userID);
        return view('users.tab1',["user"=>$user]);

    }
    public function tab2()
    {
        return view('users.tab2');

    }

    public function tab3()
    {
        return view('users.tab3');

    }
    public function tab4()
    {
        return view('users.tab4');

    }
    public function tab5()
    {
        return view('users.tab5');

    }
    public function tab6()
    {
        $userID=Auth::user()->id;
        $user=User::with('Like')->find($userID);

        return view('users.tab6',["Like"=>$user->Like]);

    }


    public function VerifyCode(Request $request)
    {


        $code = join('', $request->code);
        $number = $request->number;
        if(strlen($number)==10)
            $number='0'.$number;

        return $this->sms->accept($number,$code);

    }

    public function SendCode(Request $request)
    {
        $number = $request->phone;
        return $this->sms->send($number);
    }

    public function ViewLogin()
    {
        return view('users.login');
    }
}
