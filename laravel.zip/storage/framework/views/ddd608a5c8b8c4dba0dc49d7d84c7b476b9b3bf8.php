<div class="col-lg-1 col-md-1 hidden-sm hidden-xs left-aside sticky-aside">
    <div id="nava2" class="affix-top">
        <div class="float-left-button">
            <ul>
                <a href="javascript:void(0)">
                    <li><i><i class="icon icon-support"></i></i><span>076-33118 : پشتیبانی</span></li>
                </a>
                <a href="javascript:void(0)">
                    <li><i><i class="icon icon-home-phone"></i></i><span>076-33118 : شرکت</span></li>
                </a>
                <a href="">
                    <li><i><i class="icon icon-lifebuoy"></i></i><span>راهنمای خرید</span></li>
                </a>
                <a href="javascript:void(0)" class="backtotop">
                    <li><i><i class="icon icon-arrow-up"></i></i></li>
                </a>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\resources\views/component/support.blade.php ENDPATH**/ ?>