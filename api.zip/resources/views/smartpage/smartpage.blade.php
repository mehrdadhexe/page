<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,user-scalable=no">
    <meta name="theme-color" content="#000000">
    <title>SHORBY</title>
    <link href="{{url('/smartpage/css/app.css')}}" rel="stylesheet">
</head>


<body>
<noscript>You need to enable JavaScript to use SHORBY.</noscript>
<div id="root">

</div>

<script type="text/javascript" src="{{url('/js/app.js')}}"></script>
</body>
</html>
