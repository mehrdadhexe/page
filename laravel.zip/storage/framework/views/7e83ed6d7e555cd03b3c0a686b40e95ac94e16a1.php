<?php $__env->startSection('content'); ?>
    <main>
        <?php
            //  F_URL
              //dd(\App\Barg::find(1)->with('Media')->get());
        ?>
        <div class="page-index page-home">
            <div class="wrapper-1">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-1 col-md-1 hidden-sm hidden-xs"></div>

                        <div class="col-lg-3 hidden-md hidden-sm hidden-xs">
                            <nav>
                                <ul class="side-cat" itemscope=""
                                    itemtype="http://www.schema.org/SiteNavigationElement">


                                    <?php $__currentLoopData = \App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($cat->F_Root==1): ?>
                                            <li class="li-home"><a href="/tehran/c:todaydeals/"
                                                                   style="height: 39.3333px; line-height: 38.3333px;"><i><i
                                                                class="icon <?php echo e($cat->F_Icon); ?>"></i></i><span><?php echo e($cat->F_Name); ?></span></a>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </nav>
                        </div>
                        <div class="col-lg-19 col-md-22">
                            <div class="slider-full clearfix ">
                                <div class="overlay"></div>
                                <div id="carousel_2" data-ride="carousel" class="carousel carousel-2 slide nb-carousel">
                                    <!-- Indicators-->
                                    <!-- <ol class="carousel-indicators">
                                                    <li data-target="#carousel_2" data-slide-to=""
                                            class=" ">
                                            <i class="icon"></i>
                                        </li>
                                            </ol> -->
                                    <!-- Wrapper for slides-->
                                    <div role="listbox" class="carousel-inner">
                                        <?php
                                            $i=1;
                                        ?>
                                        <?php $__currentLoopData = \App\Slider::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <div class="item <?php if ($i == 1) echo 'active';?>">
                                                <ul class="deal-tag list-unstyled">
                                                </ul>
                                                <a href="">
                                                    <img src="<?php echo e($slider->img); ?>" alt="<?php echo e($slider->alt); ?>"> </a>
                                            </div>
                                            <?php
                                                $i++;
                                            ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>
                                    <!-- Controls--><a href="#carousel_2" role="button" data-slide="prev"
                                                       class="left carousel-control"><span aria-hidden="true"
                                                                                           class="icon icon-arrow-left"></span><span
                                                class="sr-only">Previous</span></a><a href="#carousel_2" role="button"
                                                                                      data-slide="next"
                                                                                      class="right carousel-control"><span
                                                aria-hidden="true" class="icon icon-arrow-right"></span><span
                                                class="sr-only">Next</span></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-1 col-md-1 hidden-sm hidden-xs"></div>
                    </div>
                    <div class="row">
                        <div class="col-lg-1 col-md-1 hidden-sm hidden-xs"></div>
                        <div class="col-lg-22 col-md-22">
                            <div class="row under-slider-banner">
                                <div class="col-lg-8 col-md-8 col-sm-8">
                                    <a target="_blank"
                                       href="http://netbarg.com/trend/%D9%85%DB%8C%DA%A9%D8%B1%D9%88%D8%AF%D8%B1%D9%85/"
                                       class="figure m-b">
                                        <img src="http://static.netbarg.com/img/banner/banners/rightSmallBanner/93/50f40701.jpg"
                                             alt="netbarg"> </a>
                                </div>
                                <div class="col-lg-8 col-md-8 col-sm-8">
                                    <a target="_blank"
                                       href="http://netbarg.com/trend/%D9%87%D8%AA%D9%84-%D9%85%D8%B4%D9%87%D8%AF/"
                                       class="figure m-b">
                                        <img src="http://static.netbarg.com/img/banner/banners/centerSmallBanner/91/59010762.jpg"
                                             alt="netbarg"> </a>
                                </div>
                                <div class="col-lg-8 col-md-8 col-sm-8">
                                    <a target="_blank"
                                       href="http://netbarg.com/trend/%D8%A7%D8%B3%D8%AA%D8%AE%D8%B1%D9%87%D8%A7%DB%8C-%D8%BA%D8%B1%D8%A8-%D8%AA%D9%87%D8%B1%D8%A7%D9%86/"
                                       class="figure m-b">
                                        <img src="http://static.netbarg.com/img/banner/banners/leftSmallBanner/89/47f7068c.jpg"
                                             alt="netbarg"> </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-1 col-md-1 hidden-sm hidden-xs"></div>
                    </div>
                </div>
            </div>
            <div class="wrapper-2">
                <div class="container-fluid">
                    <div class="row h-position">
                        <div class="col-lg-1 col-md-1 hidden-sm hidden-xs right-aside sticky-aside">
                            <div id="nava" class="affix-top" style="">
                                <div class="float-cat">
                                    <ul>
                                        <?php $__currentLoopData = \App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($cat->F_Root==1): ?>
                                                <a href="/tehran/c:todaydeals/" class="float-cat-todaydeal">
                                                    <li>
                                                        <i><i class="icon <?php echo e($cat->F_Icon); ?>"></i></i><span><?php echo e($cat->F_Name); ?></span>
                                                    </li>
                                                </a>

                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-22 col-md-22 col-sm-24 col-xs-24 padd-0-xs clearfix">
                            <section class="related cat-deal-color main-cat around-me clearfix">
                                <header class="section-header">
                                    <h6 class="hx"><span class="icon icon-special-user-offer"></span><span
                                                class="article-h3">پیشنهادات ویژه نت برگ</span></h6>
                                </header>
                                <div class="main-cat-deal-thumbnail clearfix main-row">

                                    <?php $__currentLoopData = \App\Suggestions::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <div itemscope="" itemtype="http://schema.org/Offer"
                                             class="col-lg-6 col-md-12 col-sm-12 col-xs-24 cds-item  ">
                                            <div class="cat-deal-smallbox">
                                                <div class="cat-deal-box">
                                                    <a href=""
                                                       class="figure"
                                                       style="background-image: url(<?php echo e(\App\Barg::find($offer_item->F_BargID)->F_Pic); ?>); background-size: cover;">
                                                        <ul class="deal-tag list-unstyled">
                                                        </ul>
                                                        <div class="overlay">
                                                            <div class="nb-btn nb-btn-success">مشاهده و خرید</div>
                                                        </div>
                                                        <img data-src="<?php echo e(\App\Barg::find($offer_item->F_BargID)->F_Pic); ?>"
                                                             alt="جشنواره سرزمین فکر بازیا در باغ کتاب" data-type="lazy"
                                                             class="sr-only"
                                                             src="<?php echo e(\App\Barg::find($offer_item->F_BargID)->F_Pic); ?>">
                                                    </a>
                                                    <div class="cat-deal-box-main clearfix">
                                                        <h4 itemprop="name" class="cdbm-title">
                                                            <a href="<?php echo e(url('/bandar/off')); ?>/<?php echo e(\App\Barg::find($offer_item->F_BargID)->F_BargID); ?>/<?php echo e(\App\Barg::find($offer_item->F_BargID)->F_Title); ?>"
                                                               itemprop="url" class="truncate">
                                                                <?php echo e(\App\Barg::find($offer_item->F_BargID)->F_Title); ?>

                                                            </a>
                                                        </h4>
                                                        <span class="cdbm-total-buy">
                                <span class="ir">
                                    <i class="icon icon-shopping-cart hidden-xs"></i>
                                    <i class="icon icon-shopping-cart_L visible-xs"></i>
                                </span>
                                <span class="cdbm-tb-total">
 <?php echo e(\App\Barg::find($offer_item->F_BargID)->DocumentDetail->count()); ?>

                                                                   </span>
                            </span>
                                                    </div>
                                                    <div class="cat-deal-box-footer clearfix">
                                                        <a href="/area/اتوبان حقانی/" class="cdbf-location truncate">
                                <span class="ir">
                                    <i class="icon icon-location74"></i>
                                </span>
                                                            <span class="cdbfl-address">
                                                            <?php echo e(\App\Barg::find($offer_item->F_BargID)->F_Adress); ?>


                                                                   </span>
                                                        </a>
                                                        <span class="cdbf-takhfif">
                                <span class="cdbft-shape">
                                    <span class="cdbft-shape-text">
                                        %<?php echo e(\App\Barg::find($offer_item->F_BargID)->F_Off); ?>                                    </span>
                                </span>
                            </span>
                                                        <span class="cdbf-price">
                                <ins class="cdbf-netbarg-price">
                                    <span itemprop="price" content="280000">
                                          <?php
                                              $fee=\App\Barg::find($offer_item->F_BargID)->F_Fee;
                                              $off=\App\Barg::find($offer_item->F_BargID)->F_Off;
                                              $price=($fee/100)*$off;

                                          ?>
                                        <?php echo e(number_format($price)); ?>

                                                                      </span>
                                    <span itemprop="priceCurrency" content="IRR"> تومان</span>
                                </ins>
                            </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </section>

                            <section class="cat-big-small">

                                <?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <article id="float-cat-restaurant" class="cat-deal-color color-rescoffee">
                                        <header class="section-header"><a href="/tehran/c:restaurant/"
                                                                          class="visible-xs">بیشتر</a>
                                            <h3 class="hx"><span class="ir"><i
                                                            class="icon <?php echo e($item["F_Category"]->F_Icon); ?>"></i></span><a
                                                        href="/tehran/c:restaurant/" class="article-h3">
                                                    <?php echo e($item["F_Category"]->F_Name); ?>



                                                </a>
                                            </h3>
                                        </header>

                                        <div class="main-row clearfix">
                                            <?php if(count($item["F_Barg"])>=1): ?>
                                                <div itemscope="" itemtype="http://schema.org/Offer"
                                                     class="col-lg-12 col-md-12 col-sm-24 col-xs-24 cat-deal-bigbox">
                                                    <div class="cat-deal-box ">
                                                        <a href="/tehran/d/c:restaurant/154389/فودکورت-پل-طبیعت-65/"
                                                           class="figure"
                                                           style="background-image: url(&quot;http://static.netbarg.com/img/responsive_large/deals/154389/1eab03e1.jpg&quot;); background-size: cover;">
                                                            <ul class="deal-tag list-unstyled">
                                                                <li class="violet-label"></li>
                                                            </ul>
                                                            <img data-src="<?php echo e($item["F_Barg"][0]->F_Pic); ?>"
                                                                 alt="فودکورت پل طبیعت" data-type="lazy" shema="1"
                                                                 itemprop="image"
                                                                 content="<?php echo e($item["F_Barg"][0]->F_Pic); ?>"
                                                                 class="sr-only"
                                                                 src="<?php echo e($item["F_Barg"][0]->F_Pic); ?>">
                                                        </a>
                                                        <div class="cat-deal-box-main clearfix">
                                                            <h4 itemprop="name" class="cdbm-title"><a itemprop="url"
                                                                                                      href="<?php echo e(url('/bandar/off')); ?>/<?php echo e($item["F_Barg"][0]->F_BargID); ?>/<?php echo e($item["F_Barg"][0]->F_Title); ?>"
                                                                                                      class="truncate">


                                                                    <?php echo e($item["F_Barg"][0]->F_Title); ?>



                                                                </a>
                                                            </h4>
                                                            <span class="cdbm-total-buy"><span class="ir"><i
                                                                            class="icon icon-shopping-cart hidden-xs"></i><i
                                                                            class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                        class="cdbm-tb-total">

                                                    <?php echo e($item["F_Barg"][0]->DocumentDetail->count()); ?>



                                                                </span></span>
                                                        </div>
                                                        <div class="cat-deal-box-footer clearfix"><span
                                                                    class="cdbf-takhfif"><span
                                                                        class="cdbft-shape"><span
                                                                            class="cdbft-shape-text">%<?php echo e($item["F_Barg"][0]->F_Off); ?></span></span></span><a
                                                                    href="/area/ونک/"
                                                                    class="cdbf-location truncate"><span
                                                                        class="ir"><i
                                                                            class="icon icon-location74"></i></span><span
                                                                        class="cdbfl-address"><?php echo e($item["F_Barg"][0]->F_Mohale); ?></span></a><a
                                                                    href="/tehran/d/c:restaurant/154389/فودکورت-پل-طبیعت-65/"
                                                                    class="cdbf-buy-icon">
                                                                <button class="nb-btn nb-btn-icon nb-btn-success">مشاهده
                                                                    و
                                                                    خرید<i
                                                                            class="icon icon-shopping-cart2"></i>
                                                                </button>

                                                            </a><span class="cdbf-price">
            <del class="cdbf-real-price"><span></span></del><ins class="cdbf-netbarg-price">
            <span itemprop="price" content="165000">
                <?php
                    $fee=\App\Barg::find($item["F_Barg"][0]->F_BargID)->F_Fee;
                    $off=\App\Barg::find($item["F_Barg"][0]->F_BargID)->F_Off;
                    $price=($fee/100)*$off;

                ?>
                <?php echo e(number_format($price)); ?>




            </span>


                                                                    <span itemprop="priceCurrency"
                                                                          content="IRR"> تومان</span>


                                                                </ins>


                                                            </span>




                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endif; ?>


                                            <div class="col-lg-12 col-md-12 col-sm-24 col-xs-24 cat-deal-smallbox">
                                                <div class="row">

                                                    <?php if(count($item["F_Barg"])>=2): ?>

                                                        <div itemscope="" itemtype="http://schema.org/Offer"
                                                             class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                            <div class="cat-deal-box"><a
                                                                        href="/tehran/d/c:restaurant/159010/صبحانه-سالم-در-عمارت-خانه-پدری/"
                                                                        class="figure"
                                                                        style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/159010/1b4f03ab.jpg&quot;); background-size: cover;">
                                                                    <ul class="deal-tag list-unstyled">
                                                                        <li class="orange-label"></li>
                                                                        <li class="violet-label"></li>
                                                                    </ul>
                                                                    <div class="overlay">
                                                                        <div class="nb-btn nb-btn-success">مشاهده و
                                                                            خرید
                                                                        </div>
                                                                    </div>
                                                                    <img data-src="<?php echo e($item["F_Barg"][1]->F_Pic); ?>"
                                                                         alt="صبحانه سالم در عمارت خانه پدری"
                                                                         data-type="lazy"
                                                                         shema="1" itemprop="image"
                                                                         content="<?php echo e($item["F_Barg"][1]->F_Pic); ?>"
                                                                         class="sr-only"
                                                                         src="<?php echo e($item["F_Barg"][1]->F_Pic); ?>"></a>
                                                                <div class="cat-deal-box-main clearfix">
                                                                    <h4 itemprop="name" class="cdbm-title"><a
                                                                                itemprop="url"
                                                                                href="/tehran/d/c:restaurant/159010/صبحانه-سالم-در-عمارت-خانه-پدری/"
                                                                                class="truncate">


                                                                            <?php echo e($item["F_Barg"][1]->F_Title); ?>



                                                                        </a>
                                                                    </h4>
                                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                                class="cdbm-tb-total">
                                              <?php echo e($item["F_Barg"][1]->DocumentDetail->count()); ?>                                       </span></span>
                                                                </div>
                                                                <div class="cat-deal-box-footer clearfix"><a
                                                                            href="/area/هفت-تیر/"
                                                                            class="cdbf-location truncate"><span
                                                                                class="ir"><i
                                                                                    class="icon icon-location74"></i></span><span
                                                                                class="cdbfl-address"><?php echo e($item["F_Barg"][1]->F_Mohale); ?></span></a><span
                                                                            class="cdbf-takhfif"><span
                                                                                class="cdbft-shape"><span
                                                                                    class="cdbft-shape-text">%<?php echo e($item["F_Barg"][1]->F_Off); ?></span></span></span><span
                                                                            class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۱۸,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                                    itemprop="price"
                                                                                    content="99000">
                                                                                <?php
                                                                                    $fee=\App\Barg::find($item["F_Barg"][1]->F_BargID)->F_Fee;
                                                                                    $off=\App\Barg::find($item["F_Barg"][1]->F_BargID)->F_Off;
                                                                                    $price=($fee/100)*$off;

                                                                                ?>
                                                                                <?php echo e(number_format($price)); ?>


                                                                            </span><span
                                                                                    itemprop="priceCurrency"
                                                                                    content="IRR"> تومان</span></ins></span>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    <?php endif; ?>
                                                    <?php if(count($item["F_Barg"])>=3): ?>
                                                        <div itemscope="" itemtype="http://schema.org/Offer"
                                                             class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                            <div class="cat-deal-box"><a
                                                                        href="/tehran/d/c:restaurant/158081/بوفه-آزاد-رستوران-زیتون/"
                                                                        class="figure"
                                                                        style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/158081/1b5e03ab.jpg&quot;); background-size: cover;">
                                                                    <ul class="deal-tag list-unstyled">
                                                                        <li class="orange-label"></li>
                                                                        <li class="violet-label"></li>
                                                                    </ul>
                                                                    <div class="overlay">
                                                                        <div class="nb-btn nb-btn-success">مشاهده و
                                                                            خرید
                                                                        </div>
                                                                    </div>
                                                                    <img data-src="<?php echo e($item["F_Barg"][2]->F_Pic); ?>"
                                                                         alt="بوفه آزاد رستوران زیتون" data-type="lazy"
                                                                         shema="1"
                                                                         itemprop="image"
                                                                         content="<?php echo e($item["F_Barg"][2]->F_Pic); ?>"
                                                                         class="sr-only"
                                                                         src="<?php echo e($item["F_Barg"][2]->F_Pic); ?>"></a>
                                                                <div class="cat-deal-box-main clearfix">
                                                                    <h4 itemprop="name" class="cdbm-title"><a
                                                                                itemprop="url"
                                                                                href="/tehran/d/c:restaurant/158081/بوفه-آزاد-رستوران-زیتون/"
                                                                                class="truncate">

                                                                            <?php echo e($item["F_Barg"][2]->F_Title); ?>



                                                                        </a>
                                                                    </h4>
                                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                                class="cdbm-tb-total">
                                              <?php echo e($item["F_Barg"][2]->DocumentDetail->count()); ?>                                        </span></span>
                                                                </div>
                                                                <div class="cat-deal-box-footer clearfix"><a
                                                                            href="/area/پارک-وی/"
                                                                            class="cdbf-location truncate"><span
                                                                                class="ir"><i
                                                                                    class="icon icon-location74"></i></span><span
                                                                                class="cdbfl-address"><?php echo e($item["F_Barg"][2]->F_Mohale); ?></span></a><span
                                                                            class="cdbf-takhfif"><span
                                                                                class="cdbft-shape"><span
                                                                                    class="cdbft-shape-text">%<?php echo e(number_format(\App\Barg::find($item["F_Barg"][2]->F_BargID)->F_Off)); ?></span></span></span><span
                                                                            class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۱۲۵,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                                    itemprop="price"
                                                                                    content="625000">

                                                                                 <?php
                                                                                     $fee=\App\Barg::find($item["F_Barg"][2]->F_BargID)->F_Fee;
                                                                                     $off=\App\Barg::find($item["F_Barg"][2]->F_BargID)->F_Off;
                                                                                     $price=($fee/100)*$off;

                                                                                 ?>
                                                                                <?php echo e(number_format($price)); ?>

                                                                            </span><span
                                                                                    itemprop="priceCurrency"
                                                                                    content="IRR"> تومان</span></ins></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>

                                                    <?php if(count($item["F_Barg"])>=4): ?>
                                                        <div itemscope="" itemtype="http://schema.org/Offer"
                                                             class="col-lg-12 col-md-12 col-sm-8 cds-item ">
                                                            <div class="cat-deal-box"><a
                                                                        href="/tehran/d/c:restaurant/157579/پیتزا-خوراک-و-برگر-در-رستوران-ایتالیایی-آوا-پلاس/"
                                                                        class="figure"
                                                                        style="background-image: url(&quot;http://static.netbarg.com/img/responsive_small/deals/157579/1ef603e0.jpg&quot;); background-size: cover;">
                                                                    <ul class="deal-tag list-unstyled">
                                                                        <li class="orange-label"></li>
                                                                        <li class="violet-label"></li>
                                                                    </ul>
                                                                    <div class="overlay">
                                                                        <div class="nb-btn nb-btn-success">مشاهده و
                                                                            خرید
                                                                        </div>
                                                                    </div>
                                                                    <img data-src="<?php echo e($item["F_Barg"][3]->F_Pic); ?>"
                                                                         alt="پیتزا ، خوراک و برگر در رستوران ایتالیایی آوا پلاس"
                                                                         data-type="lazy" shema="1" itemprop="image"
                                                                         content="<?php echo e($item["F_Barg"][3]->F_Pic); ?>"
                                                                         class="sr-only"
                                                                         src="<?php echo e($item["F_Barg"][3]->F_Pic); ?>"></a>
                                                                <div class="cat-deal-box-main clearfix">
                                                                    <h4 itemprop="name" class="cdbm-title"><a
                                                                                itemprop="url"
                                                                                href="/tehran/d/c:restaurant/157579/پیتزا-خوراک-و-برگر-در-رستوران-ایتالیایی-آوا-پلاس/"
                                                                                class="truncate">

                                                                            <?php if(count($item["F_Barg"])>=4): ?>
                                                                                <?php echo e($item["F_Barg"][3]->F_Title); ?>


                                                                            <?php endif; ?>
                                                                        </a>
                                                                    </h4>
                                                                    <span class="cdbm-total-buy"><span class="ir"><i
                                                                                    class="icon icon-shopping-cart hidden-xs"></i><i
                                                                                    class="icon icon-shopping-cart_L visible-xs"></i></span><span
                                                                                class="cdbm-tb-total">
                                             <?php echo e($item["F_Barg"][3]->DocumentDetail->count()); ?>                                       </span></span>
                                                                </div>
                                                                <div class="cat-deal-box-footer clearfix"><a
                                                                            href="/area/نیاوران/"
                                                                            class="cdbf-location truncate"><span
                                                                                class="ir"><i
                                                                                    class="icon icon-location74"></i></span><span
                                                                                class="cdbfl-address"><?php echo e($item["F_Barg"][3]->F_Mohale); ?></span></a><span
                                                                            class="cdbf-takhfif"><span
                                                                                class="cdbft-shape"><span
                                                                                    class="cdbft-shape-text">%<?php echo e($item["F_Barg"][3]->F_Off); ?></span></span></span><span
                                                                            class="cdbf-price">
                <del class="cdbf-real-price visible-xs"><span>۳۹,۰۰۰</span></del><ins class="cdbf-netbarg-price"><span
                                                                                    itemprop="price"
                                                                                    content="198900">
                                                                                 <?php

                                                                                     $fee=\App\Barg::find($item["F_Barg"][3]->F_BargID)->F_Fee;
                                                                                     $off=\App\Barg::find($item["F_Barg"][3]->F_BargID)->F_Off;
                                                                                     $price=($fee/100)*$off;

                                                                                 ?>
                                                                                <?php echo e(number_format($price)); ?>


                                                                            </span><span
                                                                                    itemprop="priceCurrency"
                                                                                    content="IRR"> تومان</span></ins></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>

                                                    <div class="col-lg-12 col-md-12 col-sm-24 cds-item hidden-xs done">
                                                        <div class="cds-all-view-box"><span class="ir"><i
                                                                        class="icon icon-burger"></i></span>
                                                            <h4 class="cds-title"><?php echo e(\App\Barg::where('F_CategoryID',$item["F_Category"]->F_CategoryID)->count()); ?>


                                                                <?php echo e(\App\Category::find($item["F_Category"]->F_CategoryID)->F_Name); ?>

                                                            </h4>
                                                            <a href="/tehran/c:restaurant/">
                                                                <button class="nb-btn nb-btn-success">مشاهده همه
                                                                </button>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                    </article>
                                    <figure class="figure-ads-baner hidden-xs visible-lg">
                                        <a href="http://netbarg.com/trend/%D8%B3%D9%81%D8%B1%D9%87-%D8%AE%D8%A7%D9%86%D9%87/"
                                           target="_blank">
                                            <img src="http://static.netbarg.com/img/banner/banners/restaurantBanner/77/c6d90dc9.jpg"
                                                 alt="رستوران و کافی شاپ"> </a>
                                    </figure>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </section>
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            
                            


                        </div>

                        <div class="col-lg-1 col-md-1 hidden-sm hidden-xs left-aside sticky-aside">
                            <div id="nava2" class="affix-top" style="">
                                <div class="float-left-button">
                                    <ul>
                                        <a href="javascript:void(0)">
                                            <li>
                                                <i><i class="icon icon-support"></i></i><span>۰۲۱-۴۱۰۹۶۱۰۰ : پشتیبانی</span>
                                            </li>
                                        </a>
                                        <a href="javascript:void(0)">
                                            <li>
                                                <i><i class="icon icon-home-phone"></i></i><span>۰۲۱-۴۲۰۹۱۰۰۰ : شرکت</span>
                                            </li>
                                        </a>
                                        <a href="/page/buy-netbarg/">
                                            <li>
                                                <i><i class="icon icon-lifebuoy"></i></i><span>راهنمای خرید نت برگ</span>
                                            </li>
                                        </a>
                                        <a href="javascript:void(0)" class="backtotop">
                                            <li><i><i class="icon icon-arrow-up"></i></i></li>
                                        </a>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bitaniki/api/resources/views/page/home.blade.php ENDPATH**/ ?>