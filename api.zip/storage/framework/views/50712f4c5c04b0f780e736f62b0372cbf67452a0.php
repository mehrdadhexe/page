<?php $__env->startSection('content'); ?>

    <main>

        <?php


            ?>


        <div class="container-fluid">
            <input value="<?php echo e($barg->F_BargID); ?>" type="hidden" class="F_BargID">
            <div class="row">
                <div class="nb-breadcrumb-spacer hidden-lg hidden-md hidden-sm"></div>
                <div class="nb-breadcrumb hidden-xs">
                    <div class="container-fluid limit">
                        <div class="row">
                            <div class="col-md-1"></div>
                            <div class="col-md-22">
                                <ul itemscope="" itemtype="http://schema.org/BreadcrumbList">
                                    <li itemprop="itemListElement" itemscope="itemscope"
                                        itemtype="http://schema.org/ListItem"><a href="http://netbarg.com/tehran/"
                                                                                 itemprop="item" itemscope="itemscope"
                                                                                 itemtype="http://schema.org/Thing"><span
                                                itemprop="name">خانه</span></a></li>
                                    <li itemprop="itemListElement" itemscope="itemscope"
                                        itemtype="http://schema.org/ListItem"><a
                                            href="" itemprop="item"
                                            itemscope="itemscope" itemtype="http://schema.org/Thing"><span
                                                itemprop="name"><?php echo e($barg->Category->F_Name); ?></span></a></li>
                                    <li itemprop="itemListElement" itemscope="itemscope"
                                        itemtype="http://schema.org/ListItem"><a
                                            href=""
                                            itemprop="item" itemscope="itemscope"
                                            itemtype="http://schema.org/Thing"><span itemprop="name"><?php echo e($barg->F_Title); ?></span></a>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-1"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="page-deal">
            <div class="container-fluid">
                <div class="row h-position">
                    <!-- start sticky -->

                <?php echo $__env->make('component.float_cat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                <!-- end sticky -->
                    <div class="col-lg-22 col-md-22 main-col">
                        <section class="deal relative clearfix equal dealType3 is-">
                            <div class="row">
                                <div class="col-sm-14 col-xs-24 _1 cell">
                                    <div class="nb-carousel-2">
                                        <div id="upSide" data-ride="carousel" class="carousel slide ">
                                            <ul class="deal-tag list-unstyled">
                                                <li class="orange-label"></li>
                                            </ul>

                                            <div class="carousel-inner ">
                                                <?php
$si=1;

                                                ?>



                                                <?php $__currentLoopData = $barg->Media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($si==1): ?>
                                                        <div data-thumb="<?php echo e($si); ?>" class="item active">
                                                    <img
                                                        src="<?php echo e($item->F_URL); ?>"
                                                        alt="<?php echo e($barg->F_Title); ?>"></div>
                                                        <?php else: ?>
                                                        <div data-thumb="<?php echo e($si); ?>" class="item">
                                                            <img
                                                                src="<?php echo e($item->F_URL); ?>"
                                                                alt="<?php echo e($barg->F_Title); ?>"></div>
                                                    <?php endif; ?>

                                                    <?php
                                                        $si++;

                                                    ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </div>
                                            <!-- Controls--><a href="#upSide" role="button" data-slide="next"
                                                               class="left carousel-control"><span aria-hidden="true"
                                                                                                   class="icon icon-arrow-left"></span><span
                                                    class="sr-only">Previous</span></a><a href="#upSide" role="button"
                                                                                          data-slide="prev"
                                                                                          class="right carousel-control"><span
                                                    aria-hidden="true" class="icon icon-arrow-right"></span><span
                                                    class="sr-only">Next</span></a>
                                        </div>
                                        <div id="downSide" class="clearfix">
                                            <div id="thumbCarousel" data-interval="false" class="carousel slide">
                                                <div class="carousel-inner">
                                                    <div class="place-holder"><i></i><i></i><i></i><i></i><i></i><i></i><i></i>
                                                    </div>

                                                    <div class="item active">
                                                        <?php
                                                            $si=0;

                                                        ?>


                                                        <?php $__currentLoopData = $barg->Media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($si==0): ?>
                                                                <div data-target="#upSide" data-slide-to="<?php echo e($si); ?>"
                                                                     class="thumb active">
                                                                    <img
                                                                        src="<?php echo e($item->F_URL); ?>"
                                                                        alt="<?php echo e($barg->F_Title); ?>"></div>
                                                            <?php else: ?>
                                                                <div data-target="#upSide" data-slide-to="<?php echo e($si); ?>"
                                                                     class="thumb">
                                                                    <img
                                                                        src="<?php echo e($item->F_URL); ?>"
                                                                        alt="<?php echo e($barg->F_Title); ?>"></div>
                                                            <?php endif; ?>

                                                            <?php
                                                                $si++;

                                                            ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-10 col-xs-24 _2 cell">
                                    <div class="top">
                                <span class="off ft-1">
                                %<?php echo e($barg->F_Off); ?>                                </span>
                                        <h1 class="_h2">
                                            <a href=""
                                               class="merchant-name ft-2 truncate"><?php echo e($barg->F_Title); ?></a>
                                        </h1>
                                        <h2 class="_h1">
                                            <a href=""
                                               class="title ft-2 ellipsis" style="overflow-wrap: break-word;"><?php echo e($barg->F_Text); ?></a>
                                        </h2>
                                    </div>
                                    <div class="bill clearfix">
                                        <form method="post" accept-charset="utf-8" class="add-to-basket" mj-type="form"
                                              mj-target="<?php echo e(url('baskets/add')); ?>/<?php echo e($barg->F_BargID); ?>" mj-method="post"
                                              mj-success="testLib"  mj-model="model1"
                                              action="<?php echo e(url('baskets/add')); ?>/<?php echo e($barg->F_BargID); ?>">
                                            <div style="display:none;">

                                                <?php echo csrf_field(); ?>
                                            </div>
                                            <div class="_type3">
                                                <div class="realValue"><span>کمینه ارزش:</span>
                                                    <del><?php echo e($barg->F_Fee); ?></del>
                                                    <span>تومان</span>
                                                </div>
                                                <div class="currentValue"><span>کمینه پرداخت :
</span>
                                                    <ins><?php echo e($full_price); ?></ins>
                                                    <span>تومان</span></div>
                                                <button   data-type="submit"
                                                   class="btn nb-btn nb-btn-success chooseIt <?php echo e($active); ?>">انتخاب تخفیف</button>
                                            </div>

                                        </form>
                                    </div>
                                    <div class="extra clearfix">
                                        <div class="sold">

                                                                        <span class="deal-sell pull-left">
                                        <div class="pull-left">
                                            <i class="icon icon-shopping-cart_L"></i>
                                            <p class="cart-num"><span>
                                             </span><?php echo e($count_pay); ?> خرید</p>
                                        </div>
                                    </span>
                                            <span class="address">
                                        <div class="pull-right">
                                            <i class="icon icon-location74"></i>
                                            <a href="#"><?php echo e($barg->F_Mohale); ?></a>
                                        </div>
                                    </span>

                                        </div>
                                        <div class="counter"><i class="icon icon-time-back"></i>
                                            <p>زمان باقیمانده
                                            </p>
                                            <div nb-server-time="<?php echo e($nb_server_time); ?>" nb-end-time="<?php echo e($nb_end_time); ?>"
                                                 class="pull-left countdown clearfix"><span><i
                                                        class="_d">6</i><i>روز</i></span><span><i class="_h">3</i><i>ساعت</i></span><span><i
                                                        class="_m">18</i><i>دقیقه</i></span><span><i
                                                        class="_s">19</i><i>ثانیه</i></span></div>
                                        </div>
                                        <div class="share">

                                            <i class="icon icon-share"></i>
                                            <p>اشتراک با دوستان</p>
                                            <div class="pull-left">

                                                <a class="_gPlus"
                                                   href="https://plus.google.com/share?url=<?php echo e(url()->current()); ?>">
                                                    <i class="icon icon-google-plus"></i></a>

                                                <a class="_facebook"
                                                   href="http://facebook.com/share.php?u=<?php echo e(url()->current()); ?>"><i
                                                        class="icon icon-facebook-logo"></i></a>

                                                <a class="_twitter"
                                                   href="https://twitter.com/share?url=<?php echo e(url()->current()); ?>"><i
                                                        class="icon icon-twitter"></i></a>


                                                <a class="_telegram"
                                                   href="https://telegram.me/share/url?url=<?php echo e(url()->current()); ?>">
                                                    <i class="icon icon-telegram-logo"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <section class="price-compare" style="display:none;">
                            <div class="icon-torob"><img src="/assets/site/img/torob.png"></div>
                            <div class="left-box">
                                <div class="col-lg-20 col-md-24 text-torob"><span>در صورتی که می‌خواهید از ارزان‌تر بودن قیمت ما نسبت به سرویس‌های مشابه مطمئن شوید، می‌توانید قیمت را در سایت ترب با سایرین مقایسه کنید.</span>
                                </div>
                                <div class="col-lg-4 col-md-24">
                                    <a href="" class="torob-link" target="_blank">
                                        <button class="nb-btn">مقایسه قیمت در ترب</button>
                                    </a>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </section>
                        <section class="merchant">
                            <div class="_1">
                                <a href="" class="merchant-name">
                                    <span class="ft-3"><?php echo e($barg->F_Title); ?></span>
                                    <span class="_s ft-7"></span>
                                </a>
                                <div class="_left pull-left">
                                                            <span company-id="20288"
                                                                  class="deal-like list-unstyled list-inline"
                                                                  data-toggle="modal" data-target="#signInModal">
                                                                <?php if(auth()->guard()->check()): ?>
                                                                    <?php
                                                                        $userid=Auth::user()->id;
                                                                        $like='';

                                                                        $islike=\App\Like::where('F_UserID',$userid)->where('F_BargID',$barg->F_BargID)->first();
                                                                        if($islike)
                                                                         $like='heartanimate';

                                                                    ?>
                                                                    <i
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title=""
                                                                        data-original-title="افزودن به لیست علاقمندی"
                                                                        class="icon <?php echo e($like); ?>"></i>
                                                                <?php endif; ?>
                                                                <?php if(auth()->guard()->guest()): ?>
                                                                    <i
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title=""
                                                                        data-original-title="افزودن به لیست علاقمندی"
                                                                        class="icon"></i>
                                                                <?php endif; ?>

                                    <span class="star-count"><?php echo e($star_count); ?></span>
                                </span>

                                    <div data-toggle="modal" data-target="#commentModal" class="cr-myrate pull-left">
                                        <!-- <span data-star-rate="4.6" class="star datasr" data-toggle="tooltip"
                                         data-placement="top"
                                         title=""
                                         data-original-title="امتیاز دهید">
                                            <i aria-hidden="true" class="icon icon-star"></i>
                                            <i aria-hidden="true" class="icon icon-star"></i>
                                            <i aria-hidden="true" class="icon icon-star"></i>
                                            <i aria-hidden="true" class="icon icon-star"></i>
                                            <i aria-hidden="true" class="icon icon-star"></i>
                                            </span> -->

                                    </div>
                                    <div class="star-rate-per pull-left">
                                        <ul class="star">
                                            <li style="width: <?php echo e($rate_darsad); ?>px;" class="starCur curr"></li>
                                        </ul>
                                        <div class="vote_num">
                                            <div class="text"> از <?php echo e($rate_count); ?> رای</div>
                                        </div>
                                        <i class="icon icon-arrow-down"></i>
                                        <div class="starUser user"><?php echo e($rate_score); ?></div>
                                    </div>
                                    <div class="circle-progress">
                                        <ul class="list-unstyled list-inline">
                                            <li class="item">
                                                <div data-size="50" data-thickness="3"
                                                     data-value="<?php echo e($happy_rate_darsad); ?>"
                                                     class="prog-bar prog-bar1">
                                                    <canvas width="50" height="50"></canvas>
                                                    <i class="icon icon-happy-face emoji-icon gray"></i><span
                                                        class="prog-bar-num"><?php echo e((int)$happy_rate_darsad); ?><i>%</i></span>
                                                </div>
                                            </li>
                                            <li class="item">
                                                <div data-size="50" data-thickness="3"
                                                     data-value="<?php echo e($normal_rate_darsad); ?>"
                                                     class="prog-bar prog-bar2">
                                                    <canvas width="50" height="50"></canvas>
                                                    <i class="icon icon-normal-face emoji-icon gray"></i><span
                                                        class="prog-bar-num"><?php echo e((int)$normal_rate_darsad); ?><i>%</i></span>
                                                </div>
                                            </li>
                                            <li class="item">
                                                <div data-size="50" data-thickness="3" data-value="<?php echo e($sad_rate_darsad); ?>"
                                                     class="prog-bar prog-bar3">
                                                    <canvas width="50" height="50"></canvas>
                                                    <i class="icon icon-sad-face emoji-icon gray"></i><span
                                                        class="prog-bar-num"><?php echo e((int)$sad_rate_darsad); ?><i>%</i></span>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="_2">

                            </div>
                            <div class="_3">
                                <div class="_r">
                                    <div class="_m"><i class="pic"></i>
                                        <p class="truncate"><?php echo e($barg->F_Adress); ?> - شماره تماس:<?php echo e($barg->F_Tell.','.$barg->F_Mobile); ?> </p>
                                    </div>
                                </div>





                            </div>
                        </section>
                        <!-- detials -->
                        <section class="details clearfix">
                            <div class="col-md-14 _1">
                                <div class="header">
                                    <h3>ویژگی ها</h3>
                                </div>
                                <div class="conditions">
                                    <?php echo $barg->F_Property; ?>

                                </div>
                            </div>
                            <div class="col-md-10 _2">
                                <div class="header">
                                    <h3>شرایط استفاده </h3>
                                </div>
                                <div>
                                    <?php echo $barg->F_Condition; ?>

                                </div>
                            </div>
                        </section>
                        <!-- end details -->
                        <!-- description -->
                        <section class="desc clearfix _open">
                            <div class="header">
                                <h3>توضیحات</h3>
                            </div>
                            <div>

                                <?php echo e($barg->F_Text); ?>


                                <div
                                    class="col-md-12 col-lg-offset-6 col-sm-24 col-sm-offset-0 col-xs-offset-0 iframe-wrapper"></div>
                            </div>
                        </section>
                        <!-- end description -->
                        <section class="article-comment desc _open ">
                            <div class="header">
                                <h6> امتیاز و نظر خریداران این فروشنده</h6>
                            </div>
                            <div>
                                <div class="cat-deal-color">
                                    <div class="article-comment-box">
                                        <?php $__currentLoopData = $barg->Comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="acb-row">
                                                <div class="acbr-cell pro-img"><img src="/assets/site/img/user-pic.png">
                                                </div>
                                                <div class="acbr-cell pro-box">
                                                    <div class="c-boxer">
                                                        <div class="cb-top clearfix">
                                                            <div class="pull-right">
                                                                <span><?php echo e(\App\User::find($comment->F_UserID)->name); ?>                                        </span>
                                                                <span>۷ روز
					پیش </span>
                                                                <span>
                                            <a href="<?php echo e(url()->current()); ?>"
                                               target="_blank">
                                                <?php echo e($barg->F_Title); ?>                                          </a>
                                        </span>
                                                            </div>
                                                            <div class="pull-left">
                                                                <i class="icon icon-happy-face green"></i>
                                                            </div>
                                                        </div>
                                                        <div class="cb-bottom">
                                                            <p><?php echo e($comment->F_Text); ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>










                                </div>
                            </div>
                        </section>





















































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































                    </div>
                   <?php echo $__env->make('component.support', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>

            <div id="dealProperty" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                 class="default-property modal nb-modal nb-fade">
                <div role="document" class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" data-dismiss="modal" aria-label="Close" class="close"><i
                                    aria-hidden="true" class="icon icon-close"></i>
                            </button>
                            <div class="modal-title-wrapper">
                                <h4 class="modal-title ft-3">مجموعه فکر بازیا</h4>
                            </div>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-xs-24">
                                    <div class="clearfix dealProp ">
                                        <div class="_1">
                                            <a href="/tehran/d/c:entertainment/160586/سرزمین-فکر-بازیا-مراجعه-در-روزهای-شنبه-الی-سه-شنبه">
                                                <div class="_img">
                                                    <img
                                                        src="http://static.netbarg.com/img/responsive_medium/deals/160586/21d70411.jpg"
                                                        alt="سرزمین فکر بازیا مراجعه در روزهای شنبه الی سه شنبه"></div>
                                            </a>
                                            <div class="_d">
                                                <a href="/tehran/d/c:entertainment/160586/سرزمین-فکر-بازیا-مراجعه-در-روزهای-شنبه-الی-سه-شنبه">سرزمین
                                                    فکر بازیا مراجعه در روزهای شنبه الی سه شنبه با 40% تخفیف و پرداخت
                                                    تنها 30,000 تومان</a>
                                                <div class="sold"><i class="icon icon-shopping-cart_L"></i><span>
                                                            1171                                                        </span><span>فروخته شده</span>
                                                </div>
                                                <div class="exp"><i class="icon icon-time-back"></i><span>۶ روز و ۳ ساعت مانده</span>
                                                </div>
                                            </div>
                                        </div>
                                        <form method="post" accept-charset="utf-8" mj-type="form"
                                              mj-target="/baskets/addToBasket/160586.json" mj-method="post"
                                              mj-success="addToBasket" mj-before="prepairAddToBasket" mj-model="model1"
                                              action="/tehran/d/c:entertainment/160583/%D8%B3%D8%B1%D8%B2%D9%85%DB%8C%D9%86-%D9%81%DA%A9%D8%B1-%D8%A8%D8%A7%D8%B2%DB%8C%D8%A7-%D8%AF%D8%B1-%D8%AC%D8%B4%D9%86%D9%88%D8%A7%D8%B1%D9%87-%D8%AA%D8%A7%D8%A8%D8%B3%D8%AA%D8%A7%D9%86%DB%8C/">
                                            <div style="display:none;"><input name="_method" value="POST" type="hidden">
                                            </div>
                                            <div class="_2"><span class="off ft-1">%40</span>
                                                <select name="item_quantity" class="single-select _quantity">
                                                    <option value="1" selected="selected">1</option>
                                                    <option value="2">2</option>
                                                </select>
                                                <div class="realValue">
                                                    <del>۵۰,۰۰۰</del>
                                                </div>
                                                <div class="currentValue">
                                                    <del class="hidden">500000</del>
                                                    <ins>۳۰,۰۰۰</ins>
                                                    <span>تومان</span>
                                                </div>
                                                <div role="group" aria-label="" class="sideBySideBtn btn-group">
                                                    <button type="submit" data-type="basket"
                                                            class="btn btn-default addBasket160586">اضافه
                                                        به سبد
                                                    </button>
                                                    <button type="submit" data-type="buy"
                                                            class="btn btn-default goBasket160586">خرید نت
                                                        برگ
                                                    </button>
                                                </div>
                                            </div>

                                        </form>
                                    </div>
                                </div>
                                <div class="col-xs-24">
                                    <div class="clearfix dealProp ">
                                        <div class="_1">
                                            <a href="/tehran/d/c:entertainment/160588/سرزمین-فکر-بازیا-مراجعه-در-روزهای-چهارشنبه-تا-جمعه">
                                                <div class="_img">
                                                    <img
                                                        src="http://static.netbarg.com/img/responsive_medium/deals/160588/21d70411.jpg"
                                                        alt="سرزمین فکر بازیا مراجعه در روزهای چهارشنبه تا جمعه"></div>
                                            </a>
                                            <div class="_d">
                                                <a href="/tehran/d/c:entertainment/160588/سرزمین-فکر-بازیا-مراجعه-در-روزهای-چهارشنبه-تا-جمعه">سرزمین
                                                    فکر بازیا مراجعه در روزهای چهارشنبه الی جمعه با 30% تخفیف و پرداخت
                                                    تنها 35,000 تومان</a>
                                                <div class="sold"><i class="icon icon-shopping-cart_L"></i><span>
                                                            883                                                        </span><span>فروخته شده</span>
                                                </div>
                                                <div class="exp"><i class="icon icon-time-back"></i><span>۶ روز و ۳ ساعت مانده</span>
                                                </div>
                                            </div>
                                        </div>
                                        <form method="post" accept-charset="utf-8" mj-type="form"
                                              mj-target="/baskets/addToBasket/160588.json" mj-method="post"
                                              mj-success="addToBasket" mj-before="prepairAddToBasket" mj-model="model1"
                                              action="/tehran/d/c:entertainment/160583/%D8%B3%D8%B1%D8%B2%D9%85%DB%8C%D9%86-%D9%81%DA%A9%D8%B1-%D8%A8%D8%A7%D8%B2%DB%8C%D8%A7-%D8%AF%D8%B1-%D8%AC%D8%B4%D9%86%D9%88%D8%A7%D8%B1%D9%87-%D8%AA%D8%A7%D8%A8%D8%B3%D8%AA%D8%A7%D9%86%DB%8C/">
                                            <div style="display:none;"><input name="_method" value="POST" type="hidden">
                                            </div>
                                            <div class="_2"><span class="off ft-1">%30</span>
                                                <select name="item_quantity" class="single-select _quantity">
                                                    <option value="1" selected="selected">1</option>
                                                    <option value="2">2</option>
                                                </select>
                                                <div class="realValue">
                                                    <del>۵۰,۰۰۰</del>
                                                </div>
                                                <div class="currentValue">
                                                    <del class="hidden">500000</del>
                                                    <ins>۳۵,۰۰۰</ins>
                                                    <span>تومان</span>
                                                </div>
                                                <div role="group" aria-label="" class="sideBySideBtn btn-group">
                                                    <button type="submit" data-type="basket"
                                                            class="btn btn-default addBasket160588">اضافه
                                                        به سبد
                                                    </button>
                                                    <button type="submit" data-type="buy"
                                                            class="btn btn-default goBasket160588">خرید نت
                                                        برگ
                                                    </button>
                                                </div>
                                            </div>

                                        </form>
                                    </div>
                                </div>
                                <div class="col-xs-24">
                                    <div class="clearfix dealProp done">
                                        <div class="_1">
                                            <a href="/tehran/d/c:entertainment/158783/جشنواره-تابستانی-سرزمین-فکر-بازیا">
                                                <div class="_img">
                                                    <img
                                                        src="http://static.netbarg.com/img/responsive_medium/deals/158783/21d70411.jpg"
                                                        alt="جشنواره تابستانی سرزمین فکر بازیا"></div>
                                            </a>
                                            <div class="_d">
                                                <a href="/tehran/d/c:entertainment/158783/جشنواره-تابستانی-سرزمین-فکر-بازیا">جشنواره
                                                    تابستانی سرزمین فکر بازیا در باغ کتاب با 60% تخفیف و پرداخت تنها
                                                    24,000 تومان به جای 60,000 تومان</a>
                                                <div class="sold"><i class="icon icon-shopping-cart_L"></i><span>
                                                            2237                                                        </span><span>فروخته شده</span>
                                                </div>
                                                <div class="exp"><i class="icon icon-time-back"></i><span>0</span>
                                                </div>
                                            </div>
                                        </div>
                                        <form method="post" accept-charset="utf-8" mj-type="form"
                                              mj-target="/baskets/addToBasket/158783.json" mj-method="post"
                                              mj-success="addToBasket" mj-before="prepairAddToBasket" mj-model="model1"
                                              action="/tehran/d/c:entertainment/160583/%D8%B3%D8%B1%D8%B2%D9%85%DB%8C%D9%86-%D9%81%DA%A9%D8%B1-%D8%A8%D8%A7%D8%B2%DB%8C%D8%A7-%D8%AF%D8%B1-%D8%AC%D8%B4%D9%86%D9%88%D8%A7%D8%B1%D9%87-%D8%AA%D8%A7%D8%A8%D8%B3%D8%AA%D8%A7%D9%86%DB%8C/">
                                            <div style="display:none;"><input name="_method" value="POST" type="hidden">
                                            </div>
                                            <div class="_2"><span class="off ft-1">%60</span>
                                                <select disabled="" class="single-select _quantity">
                                                    <option>تعداد</option>
                                                </select>

                                                <div class="realValue">
                                                    <del>۶۰,۰۰۰</del>
                                                </div>
                                                <div class="currentValue">
                                                    <del class="hidden">600000</del>
                                                    <ins>۲۴,۰۰۰</ins>
                                                    <span>تومان</span>
                                                </div>
                                                <button class="btn btn-default nb-btn-disabled">تمام شد</button>
                                            </div>

                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- map modal -->
            <div id="editQ" tabindex="-1" role="dialog" class="modal fade">
                <div role="document" class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title title-admin">ارسال پاسخ به سوال</h4>
                        </div>
                        <form method="post" accept-charset="utf-8" class="comment-form" mj-type="form"
                              mj-target="/comment/admin/comments/replyFromClient/160583.json" mj-method="post"
                              mj-success="responseDataCommentAdmin"
                              action="/tehran/d/c:entertainment/160583/%D8%B3%D8%B1%D8%B2%D9%85%DB%8C%D9%86-%D9%81%DA%A9%D8%B1-%D8%A8%D8%A7%D8%B2%DB%8C%D8%A7-%D8%AF%D8%B1-%D8%AC%D8%B4%D9%86%D9%88%D8%A7%D8%B1%D9%87-%D8%AA%D8%A7%D8%A8%D8%B3%D8%AA%D8%A7%D9%86%DB%8C/">
                            <div style="display:none;"><input name="_method" value="POST" type="hidden"></div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-xs-24 m-b">
                                        <div class="input textarea"><textarea name="mainQBody" id="mainQBody"
                                                                              placeholder="سوال کاربر"
                                                                              class="single-input" rows="5"></textarea>
                                        </div>
                                        <input name="mainQId" id="mainQId" type="hidden"><input name="deal_id"
                                                                                                id="deal_id"
                                                                                                type="hidden"><input
                                            name="admin_reply_id" id="admin_reply_id" type="hidden"><input name="typeQ"
                                                                                                           id="typeQ"
                                                                                                           type="hidden">
                                    </div>
                                    <div class="col-xs-24 m-b">
                                        <select name="defaultAnswers" type="select" id="defaultAnswers"
                                                class="form-control" onchange="prepareReplyAdminComment(this)"></select>
                                    </div>
                                    <div class="col-xs-24 m-b">
                                        <div class="input textarea"><textarea name="adminReply"
                                                                              placeholder="پاسخ خود را تایپ کنید ..."
                                                                              class="single-input" id="adminreply"
                                                                              rows="5"></textarea></div>
                                    </div>
                                    <div class="col-xs-24">
                                        <div class="checkbox checkbox-success checked">

                                            <input name="status" value="1" class="styled" id="status" type="checkbox">
                                            <label for="status">فعال شدن نظر و پاسخ</label>
                                        </div>
                                    </div>
                                    <div class="col-xs-24">
                                        <div class="checkbox checkbox-success  checked">
                                            <input name="notify" value="1" class="styled" checked="checked" id="notify"
                                                   type="checkbox"> <label for="notify">ارسال پاسخ به کاربر از طریق
                                                ایمیل</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer clearfix">
                                <button type="submit" class="btn btn-success pull-left" mj-for="model1">ثبت</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div id="reply" tabindex="-1" role="dialog" class="InDealPage modal nb-modal fade">
                <div role="document" class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" data-dismiss="modal" aria-label="Close" class="close"><i
                                    aria-hidden="true" class="icon icon-close"></i>
                            </button>
                            <div class="modal-title-wrapper">
                                <h4 class="modal-title ft-3">پاسخ شما به این دیدگاه</h4>
                            </div>
                        </div>
                        <div class="modal-body clearfix">
                            <iframe src="" class="embded-iframe" data-test=""></iframe>
                        </div>

                    </div>
                </div>
            </div>
            <div id="mainModal" tabindex="-1" role="dialog" class="modal nb-modal nb-fade">
                <div role="document" class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" data-dismiss="modal" aria-label="Close" class="close"><i
                                    aria-hidden="true" class="icon icon-close"></i>
                            </button>
                            <div class="modal-title-wrapper">
                                <h4 class="modal-title ft-3"></h4>
                            </div>
                        </div>
                        <div class="modal-body"></div>
                        <div class="modal-footer"></div>
                    </div>
                </div>
            </div>
        </div>


        <div id="giftCardModal" tabindex="-1" role="dialog" class="modal nb-modal nb-fade">
            <div role="document" class="modal-dialog modal-md">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" data-dismiss="modal" aria-label="Close" class="close"><i
                                aria-hidden="true" class="icon icon-close"></i>
                        </button>
                    </div>
                    <div class="modal-body modal-body-gift">

                    </div>
                </div>
            </div>
        </div>

        <button id="giftCardModalTrigger" data-toggle="modal" data-target="#giftCardModal"
                class="btn nb-btn nb-btn-danger hidden"></button>

        <div id="quickview-package" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
             class="modal nb-modal fade">
            <div role="document" class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" data-dismiss="modal" aria-label="Close" class="close"><i
                                aria-hidden="true" class="icon icon-close"></i></button>
                    </div>
                    <div class="modal-body clearfix subdeal-description"></div>
                </div>
            </div>
        </div>




    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/page/off_page.blade.php ENDPATH**/ ?>